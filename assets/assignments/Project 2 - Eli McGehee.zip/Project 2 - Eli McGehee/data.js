let dataObj = {
        "type": "FeatureCollection",
        "features": [
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97371465,40.7643971 ]
         },
         "properties": {
         "capacity":66,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db5fae-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Grand Army Plaza & Central Park S",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=281",
         "short_name":"6839.1",
         "station_id":281
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01361706,40.70463334 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db6da2-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & Battery Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=304",
         "short_name":"4962.01",
         "station_id":304
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97498696,40.75510267 ]
         },
         "properties": {
         "capacity":64,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbc982-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 47 St & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=359",
         "short_name":"6584.12",
         "station_id":359
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00566443,40.72243797 ]
         },
         "properties": {
         "capacity":45,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbe441-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"6 Ave & Canal St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=377",
         "short_name":"5500.07",
         "station_id":377
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99200509,40.73492695 ]
         },
         "properties": {
         "capacity":36,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbe601-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"University Pl & E 14 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=382",
         "short_name":"5905.11",
         "station_id":382
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98955109,40.7403432 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbf0d0-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & E 22 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=402",
         "short_name":"6098.07",
         "station_id":402
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01322069,40.71754834 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc0e99-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"West St & Chambers St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=426",
         "short_name":"5329.03",
         "station_id":426
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.005226,40.751396 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc22a7-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"11 Ave & W 27 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=458",
         "short_name":"6425.04",
         "station_id":458
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98014437,40.75500254 ]
         },
         "properties": {
         "capacity":46,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc48ef-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 44 St & 5 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=484",
         "short_name":"6551.02",
         "station_id":484
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98602213,40.74096374 ]
         },
         "properties": {
         "capacity":51,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc6a86-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 24 St & Park Ave S",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=491",
         "short_name":"6131.1",
         "station_id":491
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97648516,40.75992262 ]
         },
         "properties": {
         "capacity":41,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc80b4-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 52 St & 5 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=520",
         "short_name":"6700.01",
         "station_id":520
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98316936,40.75527307 ]
         },
         "properties": {
         "capacity":57,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc82ef-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 43 St & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=524",
         "short_name":"6593.14",
         "station_id":524
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95818491,40.76500525 ]
         },
         "properties": {
         "capacity":59,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd42eb-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"1 Ave & E 68 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3141",
         "short_name":"6822.09",
         "station_id":3141
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96865398,40.75899656 ]
         },
         "properties": {
         "capacity":53,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd8f1a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 55 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3223",
         "short_name":"6691.12",
         "station_id":3223
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97805914,40.75724568 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd9fa6-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 48 St & 5 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3233",
         "short_name":"6626.01",
         "station_id":3233
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99468482,40.75058535 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddbd20-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"8 Ave & W 31 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3255",
         "short_name":"6450.05",
         "station_id":3255
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.971888,40.7937704 ]
         },
         "properties": {
         "capacity":32,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddede1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 95 St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3314",
         "short_name":"7541.01",
         "station_id":3314
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97982001,40.76132983 ]
         },
         "properties": {
         "capacity":41,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de8a86-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 52 St & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3443",
         "short_name":"6740.01",
         "station_id":3443
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99392888,40.76727216 ]
         },
         "properties": {
         "capacity":55,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db237e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 52 St & 11 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=72",
         "short_name":"6926.01",
         "station_id":72
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00666661,40.71911552 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db269c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Franklin St & W Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=79",
         "short_name":"5430.08",
         "station_id":79
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00016545,40.71117416 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db277a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"St James Pl & Pearl St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=82",
         "short_name":"5167.06",
         "station_id":82
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97632328,40.68382604 ]
         },
         "properties": {
         "capacity":62,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db281e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Atlantic Ave & Fort Greene Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=83",
         "short_name":"4354.07",
         "station_id":83
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97803415,40.69608941 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db2953-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Park Ave & St Edwards St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=119",
         "short_name":"4700.06",
         "station_id":119
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95928168,40.68676793 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db29e6-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lexington Ave & Classon Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=120",
         "short_name":"4452.03",
         "station_id":120
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00674436,40.73172428 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db2a71-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Barrow St & Hudson St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=127",
         "short_name":"5805.05",
         "station_id":127
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00297088,40.72710258 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db2afe-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"MacDougal St & Prince St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=128",
         "short_name":"5687.04",
         "station_id":128
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99337909,40.69239502 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db2d2b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Clinton St & Joralemon St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=143",
         "short_name":"4605.04",
         "station_id":143
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98068914,40.69839895 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db2db5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Nassau St & Navy St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=144",
         "short_name":"4812.02",
         "station_id":144
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0091059,40.71625008 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db2e3a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Hudson St & Reade St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=146",
         "short_name":"5359.1",
         "station_id":146
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98085795,40.7208736 ]
         },
         "properties": {
         "capacity":54,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db2f4c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 2 St & Avenue C",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=150",
         "short_name":"5476.03",
         "station_id":150
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99724901,40.72210379 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db2fd0-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Cleveland Pl & Spring St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=151",
         "short_name":"5492.05",
         "station_id":151
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99612349,40.69089272 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db316a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Henry St & Atlantic Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=157",
         "short_name":"4531.05",
         "station_id":157
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99810231,40.72917025 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3273-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"LaGuardia Pl & W 3 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=161",
         "short_name":"5721.14",
         "station_id":161
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97032517,40.75323098 ]
         },
         "properties": {
         "capacity":47,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db32fb-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 47 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=164",
         "short_name":"6498.1",
         "station_id":164
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97604882,40.7489006 ]
         },
         "properties": {
         "capacity":45,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db337f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 39 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=167",
         "short_name":"6389.03",
         "station_id":167
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99456405,40.73971301 ]
         },
         "properties": {
         "capacity":47,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db33fc-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 18 St & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=168",
         "short_name":"6064.08",
         "station_id":168
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98452729,40.76068327 ]
         },
         "properties": {
         "capacity":51,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db347b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & W 49 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=173",
         "short_name":"6708.02",
         "station_id":173
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97738662,40.7381765 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db34fc-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 25 St & 1 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=174",
         "short_name":"6004.07",
         "station_id":174
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01043382,40.70905623 ]
         },
         "properties": {
         "capacity":45,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3583-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Liberty St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=195",
         "short_name":"5105.01",
         "station_id":195
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00681753,40.74334935 ]
         },
         "properties": {
         "capacity":60,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3606-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 16 St & The High Line",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=212",
         "short_name":"6233.05",
         "station_id":212
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99548059,40.70037867 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3687-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Columbia Heights & Cranberry St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=216",
         "short_name":"4829.01",
         "station_id":216
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99383605,40.70277159 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3708-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Old Fulton St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=217",
         "short_name":"4903.08",
         "station_id":217
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99994661,40.73781509 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3816-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 13 St & 7 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=223",
         "short_name":"6030.04",
         "station_id":223
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00552427,40.71146364 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3898-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Spruce St & Nassau St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=224",
         "short_name":"5137.1",
         "station_id":224
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97187886,40.7546011 ]
         },
         "properties": {
         "capacity":55,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3997-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 48 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=228",
         "short_name":"6541.03",
         "station_id":228
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99379025,40.72743423 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3a1e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Great Jones St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=229",
         "short_name":"5636.11",
         "station_id":229
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98713956,40.7284186 ]
         },
         "properties": {
         "capacity":47,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3ba0-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"St Marks Pl & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=236",
         "short_name":"5669.1",
         "station_id":236
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98672378,40.73047309 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3c29-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 11 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=237",
         "short_name":"5746.04",
         "station_id":237
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00859207,40.7361967 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3cab-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Bank St & Washington St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=238",
         "short_name":"5964.01",
         "station_id":238
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9813018,40.69196566 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3d2a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Willoughby St & Fleet St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=239",
         "short_name":"4628.05",
         "station_id":239
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97493121,40.68981035 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3da9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"DeKalb Ave & S Portland Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=241",
         "short_name":"4546.04",
         "station_id":241
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.973736,40.697787 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3e32-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Carlton Ave & Flushing Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=242",
         "short_name":"4732.08",
         "station_id":242
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.979382,40.688226 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3e9d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Fulton St & Rockwell Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=243",
         "short_name":"4513.03",
         "station_id":243
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96536851,40.69196035 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3f01-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Willoughby Ave & Hall St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=244",
         "short_name":"4611.03",
         "station_id":244
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97703874,40.69327018 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3f62-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Myrtle Ave & St Edwards St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=245",
         "short_name":"4659.02",
         "station_id":245
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00483091,40.73535398 ]
         },
         "properties": {
         "capacity":0,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db3fc9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Perry St & Bleecker St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=247",
         "short_name":"5922.07",
         "station_id":247
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00771779,40.72185379 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db402c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Laight St & Hudson St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=248",
         "short_name":"5539.06",
         "station_id":248
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0090009,40.71870987 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db408f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Harrison St & Hudson St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=249",
         "short_name":"5400.05",
         "station_id":249
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99480012,40.72317958 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db4158-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Mott St & Prince St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=251",
         "short_name":"5561.04",
         "station_id":251
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99852205,40.73226398 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db41bf-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"MacDougal St & Washington Sq",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=252",
         "short_name":"5797.01",
         "station_id":252
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99800419,40.73532427 ]
         },
         "properties": {
         "capacity":59,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db4282-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 11 St & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=254",
         "short_name":"5914.03",
         "station_id":254
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00247214,40.71939226 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db4351-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lispenard St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=257",
         "short_name":"5391.06",
         "station_id":257
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96885458,40.68940747 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db43b5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"DeKalb Ave & Vanderbilt Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=258",
         "short_name":"4461.04",
         "station_id":258
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01234218,40.70122128 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db4417-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"South St & Whitehall St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=259",
         "short_name":"4846.01",
         "station_id":259
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01167797,40.70365182 ]
         },
         "properties": {
         "capacity":3,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db447a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broad St & Bridge St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=260",
         "short_name":"4962.08",
         "station_id":260
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98362464,40.69474881 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db44e5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Johnson St & Gold St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=261",
         "short_name":"4668.08",
         "station_id":261
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9737299,40.6917823 ]
         },
         "properties": {
         "capacity":7,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db4549-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Washington Park",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=262",
         "short_name":"4546.05",
         "station_id":262
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00731853,40.70706456 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db460d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Maiden Ln & Pearl St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=264",
         "short_name":"5065.1",
         "station_id":264
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99147535,40.72229346 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db4671-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Stanton St & Chrystie St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=265",
         "short_name":"5523.02",
         "station_id":265
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97574813,40.72368361 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db46d7-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Avenue D & E 8 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=266",
         "short_name":"5506.1",
         "station_id":266
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98765428,40.75097711 ]
         },
         "properties": {
         "capacity":57,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db473c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & W 36 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=267",
         "short_name":"6441.01",
         "station_id":267
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99973337,40.71910537 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db479e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Howard St & Centre St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=268",
         "short_name":"5422.04",
         "station_id":268
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97178913,40.69308257 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db5c14-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Adelphi St & Myrtle Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=270",
         "short_name":"4620.02",
         "station_id":270
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.976682,40.68691865 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db5d28-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lafayette Ave & Fort Greene Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=274",
         "short_name":"4395.04",
         "station_id":274
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96563307,40.68650065 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db5d92-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Washington Ave & Greene Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=275",
         "short_name":"4419.03",
         "station_id":275
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0104554,40.71748752 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db5dfb-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Duane St & Greenwich St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=276",
         "short_name":"5400.08",
         "station_id":276
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98476437,40.69766564 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db5e6a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Concord St & Bridge St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=278",
         "short_name":"4781.03",
         "station_id":278
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00167,40.707873 ]
         },
         "properties": {
         "capacity":36,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db5ed3-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Peck Slip & Front St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=279",
         "short_name":"5098.1",
         "station_id":279
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99510132,40.73331967 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db5f40-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 10 St & 5 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=280",
         "short_name":"5872.08",
         "station_id":280
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96841526,40.70764494 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db6299-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Kent Ave & S 11 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=282",
         "short_name":"5062.01",
         "station_id":282
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99074142,40.73454567 ]
         },
         "properties": {
         "capacity":53,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db6387-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & E 14 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=285",
         "short_name":"5905.12",
         "station_id":285
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95881081,40.6845683 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db63f4-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Monroe St & Classon Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=289",
         "short_name":"4336.01",
         "station_id":289
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.984844,40.713126 ]
         },
         "properties": {
         "capacity":20,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db64d1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Madison St & Montgomery St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=291",
         "short_name":"5262.09",
         "station_id":291
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99102628,40.73020661 ]
         },
         "properties": {
         "capacity":55,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db65aa-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lafayette St & E 8 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=293",
         "short_name":"5788.13",
         "station_id":293
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99293911,40.71406667 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db6889-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Pike St & E Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=295",
         "short_name":"5270.05",
         "station_id":295
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9970468,40.71413089 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db68fc-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Division St & Bowery",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=296",
         "short_name":"5238.04",
         "station_id":296
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.986923,40.734232 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db6963-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 15 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=297",
         "short_name":"5863.07",
         "station_id":297
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9796772,40.68683208 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db69d0-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"3 Ave & Schermerhorn St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=298",
         "short_name":"4437.01",
         "station_id":298
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98368779,40.72217444 ]
         },
         "properties": {
         "capacity":58,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db6aae-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 2 St & Avenue B",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=301",
         "short_name":"5515.02",
         "station_id":301
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97793172,40.72082834 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db6cd4-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Avenue D & E 3 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=302",
         "short_name":"5436.09",
         "station_id":302
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99949601,40.72362738 ]
         },
         "properties": {
         "capacity":67,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db6d40-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Mercer St & Spring St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=303",
         "short_name":"5532.01",
         "station_id":303
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96724467,40.76095756 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db6e49-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 58 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=305",
         "short_name":"6762.02",
         "station_id":305
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98990025,40.71427487 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db6f2e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Canal St & Rutgers St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=307",
         "short_name":"5303.08",
         "station_id":307
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99851193,40.71307916 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db7152-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"St James Pl & Oliver St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=308",
         "short_name":"5238.05",
         "station_id":308
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.013012,40.7149787 ]
         },
         "properties": {
         "capacity":41,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db71be-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Murray St & West St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=309",
         "short_name":"5329.06",
         "station_id":309
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98912867,40.68926942 ]
         },
         "properties": {
         "capacity":36,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db7221-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"State St & Smith St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=310",
         "short_name":"4565.06",
         "station_id":310
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98802084,40.7172274 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db728c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Norfolk St & Broome St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=311",
         "short_name":"5374.01",
         "station_id":311
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.989111,40.722055 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db72f1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Allen St & Stanton St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=312",
         "short_name":"5484.09",
         "station_id":312
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96751037,40.69610226 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db74a5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Washington Ave & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=313",
         "short_name":"4724.03",
         "station_id":313
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.990539,40.69383 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db7551-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Cadman Plaza West & Montague St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=314",
         "short_name":"4677.07",
         "station_id":314
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00670227,40.70355377 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db75cc-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"South St & Gouverneur Ln",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=315",
         "short_name":"4953.04",
         "station_id":315
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00653609,40.70955958 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db7637-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Fulton St & William St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=316",
         "short_name":"5137.11",
         "station_id":316
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98185424,40.72453734 ]
         },
         "properties": {
         "capacity":54,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db76a1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 6 St & Avenue B",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=317",
         "short_name":"5584.04",
         "station_id":317
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.009447,40.711066 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db79a3-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Fulton St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=319",
         "short_name":"5175.08",
         "station_id":319
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.005549,40.717571 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db7a0d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Leonard St & Church St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=320",
         "short_name":"5359.11",
         "station_id":320
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98971773,40.69991755 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db7a71-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Cadman Plaza E & Red Cross Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=321",
         "short_name":"4821.06",
         "station_id":321
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.991218,40.696192 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db87e3-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"FALSE",
         "name":"Clinton St & Tillary St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=322",
         "short_name":"4748.04",
         "station_id":322
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98631746,40.69236178 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db88f5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lawrence St & Willoughby St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=323",
         "short_name":"4596.09",
         "station_id":323
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.981013,40.689888 ]
         },
         "properties": {
         "capacity":51,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db89a3-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"DeKalb Ave & Hudson Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=324",
         "short_name":"4513.06",
         "station_id":324
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98473765,40.73624527 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db8c10-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 19 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=325",
         "short_name":"5938.01",
         "station_id":325
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98426726,40.72953837 ]
         },
         "properties": {
         "capacity":41,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db8ca4-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 11 St & 1 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=326",
         "short_name":"5746.14",
         "station_id":326
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01658354,40.7153379 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db8d89-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Vesey Pl & River Terrace",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=327",
         "short_name":"5297.02",
         "station_id":327
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00965965,40.72405549 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db8fde-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Watts St & Greenwich St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=328",
         "short_name":"5578.02",
         "station_id":328
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00562789,40.71450451 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db90f1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Reade St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=330",
         "short_name":"5247.1",
         "station_id":330
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99193043,40.71173107 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db930d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Pike St & Monroe St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=331",
         "short_name":"5159.04",
         "station_id":331
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97948148,40.71219906 ]
         },
         "properties": {
         "capacity":36,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db93a1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Cherry St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=332",
         "short_name":"5181.04",
         "station_id":332
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99726235,40.74238787 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db95e5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 20 St & 7 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=334",
         "short_name":"6182.02",
         "station_id":334
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99404649,40.72903917 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db9675-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Washington Pl & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=335",
         "short_name":"5755.01",
         "station_id":335
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99906065,40.73047747 ]
         },
         "properties": {
         "capacity":36,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db9845-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Sullivan St & Washington Sq",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=336",
         "short_name":"5721.01",
         "station_id":336
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00838676,40.7037992 ]
         },
         "properties": {
         "capacity":37,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db9925-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Old Slip & Front St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=337",
         "short_name":"4993.12",
         "station_id":337
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97422494,40.72580614 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db9c2e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Avenue D & E 12 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=339",
         "short_name":"5575.08",
         "station_id":339
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98776323,40.71269042 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db9cc4-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Madison St & Clinton St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=340",
         "short_name":"5190.07",
         "station_id":340
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97628939,40.71782143 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66db9e99-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Stanton St & Mangin St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=341",
         "short_name":"5326.06",
         "station_id":341
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98016555,40.71739973 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dba0ba-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Columbia St & Rivington St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=342",
         "short_name":"5365.02",
         "station_id":342
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96986848,40.69794 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dba303-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Clinton Ave & Flushing Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=343",
         "short_name":"4762.04",
         "station_id":343
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95380904,40.6851443 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbb869-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Monroe St & Bedford Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=344",
         "short_name":"4368.05",
         "station_id":344
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00618026,40.73652889 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbbc4a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Bank St & Hudson St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=346",
         "short_name":"5922.08",
         "station_id":346
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.008591,40.728846 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbbeda-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Greenwich St & W Houston St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=347",
         "short_name":"5730.08",
         "station_id":347
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98329859,40.71850211 ]
         },
         "properties": {
         "capacity":61,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbc37a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Rivington St & Ridge St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=349",
         "short_name":"5406.02",
         "station_id":349
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9870295,40.71559509 ]
         },
         "properties": {
         "capacity":28,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbc420-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Clinton St & Grand St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=350",
         "short_name":"5303.06",
         "station_id":350
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00612572,40.70530954 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbc4c2-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Front St & Maiden Ln",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=351",
         "short_name":"5024.08",
         "station_id":351
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97431458,40.68539567 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbc60f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"S Portland Ave & Hanson Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=353",
         "short_name":"4354.05",
         "station_id":353
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96223558,40.69363137 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbc6ae-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Emerson Pl & Myrtle Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=354",
         "short_name":"4683.02",
         "station_id":354
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99974372,40.71602118 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbc745-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Bayard St & Baxter St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=355",
         "short_name":"5351.03",
         "station_id":355
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98261206,40.71622644 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbc7d2-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Bialystoker Pl & Delancey St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=356",
         "short_name":"5335.03",
         "station_id":356
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99158043,40.73261787 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbc860-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 11 St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=357",
         "short_name":"5829.12",
         "station_id":357
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00711384,40.73291553 ]
         },
         "properties": {
         "capacity":50,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbc8f5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Christopher St & Greenwich St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=358",
         "short_name":"5847.01",
         "station_id":358
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00887308,40.70717936 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbca0f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"William St & Pine St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=360",
         "short_name":"5065.12",
         "station_id":360
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99190759,40.71605866 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbca9c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Allen St & Hester St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=361",
         "short_name":"5342.1",
         "station_id":361
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98753523,40.75172632 ]
         },
         "properties": {
         "capacity":57,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbcb2f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & W 37 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=362",
         "short_name":"6441.02",
         "station_id":362
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01713445,40.70834698 ]
         },
         "properties": {
         "capacity":49,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbcbbc-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"West Thames St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=363",
         "short_name":"5114.06",
         "station_id":363
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96023854,40.68900443 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbcc49-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lafayette Ave & Classon Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=364",
         "short_name":"4452.01",
         "station_id":364
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9614583,40.68223166 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbccd7-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Fulton St & Grand Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=365",
         "short_name":"4263.1",
         "station_id":365
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.968896,40.693261 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbcd6c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Clinton Ave & Myrtle Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=366",
         "short_name":"4651.02",
         "station_id":366
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00214988,40.73038599 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbce8a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Carmine St & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=368",
         "short_name":"5763.03",
         "station_id":368
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00026394,40.73224119 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbcf18-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Washington Pl & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=369",
         "short_name":"5838.09",
         "station_id":369
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95801365,40.69454609 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbe15d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Franklin Ave & Myrtle Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=372",
         "short_name":"4715.01",
         "station_id":372
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95381995,40.69331716 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbe250-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Willoughby Ave & Walworth St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=373",
         "short_name":"4634.02",
         "station_id":373
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00722156,40.70862144 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbe3a2-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"John St & William St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=376",
         "short_name":"5065.04",
         "station_id":376
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9916,40.749156 ]
         },
         "properties": {
         "capacity":42,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbe4db-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 31 St & 7 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=379",
         "short_name":"6331.01",
         "station_id":379
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00293877,40.73401143 ]
         },
         "properties": {
         "capacity":42,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbe571-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 4 St & 7 Ave S",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=380",
         "short_name":"5880.02",
         "station_id":380
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.000271,40.735238 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbe68e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Greenwich Ave & Charles St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=383",
         "short_name":"5914.08",
         "station_id":383
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96603308,40.75797322 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbe7b6-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 55 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=385",
         "short_name":"6650.07",
         "station_id":385
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00234482,40.71494807 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbe848-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Centre St & Worth St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=386",
         "short_name":"5279.03",
         "station_id":386
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0046073,40.71273266 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbe8d6-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Centre St & Chambers St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=387",
         "short_name":"5207.01",
         "station_id":387
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00295035,40.74971775 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbe96d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 26 St & 10 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=388",
         "short_name":"6382.05",
         "station_id":388
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96525063,40.71044554 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbe9fc-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & Berry St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=389",
         "short_name":"5164.04",
         "station_id":389
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9842844,40.69221589 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbea8d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Duffield St & Willoughby St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=390",
         "short_name":"4596.05",
         "station_id":390
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99344559,40.69760127 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbeb1b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Clark St & Henry St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=391",
         "short_name":"4789.03",
         "station_id":391
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.987167,40.695065 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbebad-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Jay St & Tech Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=392",
         "short_name":"4710.06",
         "station_id":392
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97995466,40.72299208 ]
         },
         "properties": {
         "capacity":37,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbec40-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 5 St & Avenue C",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=393",
         "short_name":"5545.04",
         "station_id":393
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97768752,40.72521311 ]
         },
         "properties": {
         "capacity":34,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbecd0-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 9 St & Avenue C",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=394",
         "short_name":"5616.01",
         "station_id":394
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95576894,40.68034242 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbeded-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lefferts Pl & Franklin Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=396",
         "short_name":"4222.02",
         "station_id":396
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96922273,40.68415748 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbee85-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Fulton St & Clermont Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=397",
         "short_name":"4386.05",
         "station_id":397
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9999786,40.69165183 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbef15-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Atlantic Ave & Furman St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=398",
         "short_name":"4614.04",
         "station_id":398
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9647628,40.68851534 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbef85-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lafayette Ave & St James Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=399",
         "short_name":"4494.04",
         "station_id":399
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98178024,40.71926081 ]
         },
         "properties": {
         "capacity":15,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbefee-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Pitt St & Stanton St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=400",
         "short_name":"5406.04",
         "station_id":400
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98997825,40.72019576 ]
         },
         "properties": {
         "capacity":42,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbf062-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Allen St & Rivington St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=401",
         "short_name":"5414.06",
         "station_id":401
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99069656,40.72502876 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbf140-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 2 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=403",
         "short_name":"5593.02",
         "station_id":403
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.008119,40.739323 ]
         },
         "properties": {
         "capacity":51,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbf215-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Washington St & Gansevoort St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=405",
         "short_name":"6039.06",
         "station_id":405
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99595065,40.69512845 ]
         },
         "properties": {
         "capacity":34,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbf288-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Hicks St & Montague St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=406",
         "short_name":"4645.09",
         "station_id":406
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.991454,40.700469 ]
         },
         "properties": {
         "capacity":37,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbf2f8-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Henry St & Poplar St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=407",
         "short_name":"4861.04",
         "station_id":407
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99400398,40.71076228 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbf362-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Market St & Cherry St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=408",
         "short_name":"5198.04",
         "station_id":408
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95643107,40.6906495 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbf3cf-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"DeKalb Ave & Skillman St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=409",
         "short_name":"4528.05",
         "station_id":409
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98517977,40.72066442 ]
         },
         "properties": {
         "capacity":45,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbf442-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Suffolk St & Stanton St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=410",
         "short_name":"5445.02",
         "station_id":410
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97668709,40.72228087 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbf4ac-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 6 St & Avenue D",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=411",
         "short_name":"5506.14",
         "station_id":411
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99422366,40.7158155 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbf518-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Forsyth St & Canal St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=412",
         "short_name":"5270.07",
         "station_id":412
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98765762,40.70281858 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbf5f6-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Pearl St & Anchorage Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=414",
         "short_name":"4936.12",
         "station_id":414
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00926027,40.7047177 ]
         },
         "properties": {
         "capacity":42,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbf667-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Pearl St & Hanover Square",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=415",
         "short_name":"4993.02",
         "station_id":415
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97265183,40.68753406 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbf6d2-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Cumberland St & Lafayette Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=416",
         "short_name":"4428.02",
         "station_id":416
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01020234,40.71291224 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dbf73d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Barclay St & Church St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=417",
         "short_name":"5216.04",
         "station_id":417
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.982578,40.70224 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc0bbd-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Front St & Gold St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=418",
         "short_name":"4927.04",
         "station_id":418
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97355569,40.69580705 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc0c53-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Carlton Ave & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=419",
         "short_name":"4732.04",
         "station_id":419
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96968902,40.68764484 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc0cc7-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Clermont Ave & Lafayette Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=420",
         "short_name":"4461.01",
         "station_id":420
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97129668,40.69573398 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc0d3a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Clermont Ave & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=421",
         "short_name":"4692.01",
         "station_id":421
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.988038,40.770513 ]
         },
         "properties": {
         "capacity":79,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc0dab-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 59 St & 10 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=422",
         "short_name":"7023.04",
         "station_id":422
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98690506,40.76584941 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc0e24-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 54 St & 9 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=423",
         "short_name":"6920.03",
         "station_id":423
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.013942,40.701907 ]
         },
         "properties": {
         "capacity":47,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc0f1b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Bus Slip & State St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=427",
         "short_name":"4889.06",
         "station_id":427
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98379855,40.72621788 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc10d1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 7 St & Avenue A",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=432",
         "short_name":"5626.07",
         "station_id":432
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99415556,40.74173969 ]
         },
         "properties": {
         "capacity":50,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc120f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 21 St & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=435",
         "short_name":"6140.05",
         "station_id":435
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95399026,40.68216564 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc1545-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Hancock St & Bedford Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=436",
         "short_name":"4255.05",
         "station_id":436
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95004798,40.68098339 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc1687-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Macon St & Nostrand Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=437",
         "short_name":"4214.03",
         "station_id":437
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98564945,40.72779126 ]
         },
         "properties": {
         "capacity":47,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc1702-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"St Marks Pl & 1 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=438",
         "short_name":"5626.13",
         "station_id":438
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98978041,40.7262807 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc176f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 4 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=439",
         "short_name":"5593.04",
         "station_id":439
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97282625,40.75255434 ]
         },
         "properties": {
         "capacity":32,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc17df-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 45 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=440",
         "short_name":"6464.08",
         "station_id":440
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.967416,40.756014 ]
         },
         "properties": {
         "capacity":40,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc1855-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 52 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=441",
         "short_name":"6575.06",
         "station_id":441
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.993915,40.746647 ]
         },
         "properties": {
         "capacity":51,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc18c2-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 27 St & 7 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=442",
         "short_name":"6247.06",
         "station_id":442
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96408963,40.70853074 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc192f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Bedford Ave & S 9 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=443",
         "short_name":"5093.01",
         "station_id":443
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98142006,40.72740794 ]
         },
         "properties": {
         "capacity":79,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc1beb-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 10 St & Avenue A",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=445",
         "short_name":"5659.05",
         "station_id":445
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99529885,40.74487634 ]
         },
         "properties": {
         "capacity":47,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc1c5c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 24 St & 7 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=446",
         "short_name":"6257.03",
         "station_id":446
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9851615,40.76370739 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc1d0c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"8 Ave & W 52 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=447",
         "short_name":"6816.07",
         "station_id":447
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9979009,40.75660359 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc1d80-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 37 St & 10 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=448",
         "short_name":"6611.02",
         "station_id":448
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98788205,40.76227205 ]
         },
         "properties": {
         "capacity":67,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc1e55-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 49 St & 8 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=450",
         "short_name":"6747.06",
         "station_id":450
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99915362,40.74475148 ]
         },
         "properties": {
         "capacity":66,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc209c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 22 St & 8 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=453",
         "short_name":"6224.03",
         "station_id":453
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96592976,40.75455731 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc210e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 51 St & 1 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=454",
         "short_name":"6532.06",
         "station_id":454
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96905301,40.75001986 ]
         },
         "properties": {
         "capacity":59,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc2172-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"1 Ave & E 44 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=455",
         "short_name":"6379.03",
         "station_id":455
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97402311,40.7597108 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc21d4-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 53 St & Madison Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=456",
         "short_name":"6659.03",
         "station_id":456
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.007756,40.746745 ]
         },
         "properties": {
         "capacity":49,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc24b8-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 20 St & 11 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=459",
         "short_name":"6306.07",
         "station_id":459
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96590294,40.71285887 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc252e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"S 4 St & Wythe Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=460",
         "short_name":"5204.05",
         "station_id":460
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98205027,40.73587678 ]
         },
         "properties": {
         "capacity":56,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc259a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 20 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=461",
         "short_name":"5971.08",
         "station_id":461
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00451887,40.74691959 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc2606-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 22 St & 10 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=462",
         "short_name":"6306.06",
         "station_id":462
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98658032,40.75513557 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc292c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & W 41 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=465",
         "short_name":"6560.01",
         "station_id":465
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99144871,40.74395411 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc2995-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 25 St & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=466",
         "short_name":"6215.04",
         "station_id":466
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97895137,40.68312489 ]
         },
         "properties": {
         "capacity":34,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc29f8-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Dean St & 4 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=467",
         "short_name":"4322.02",
         "station_id":467
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98192338,40.7652654 ]
         },
         "properties": {
         "capacity":65,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc2bc5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & W 56 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=468",
         "short_name":"6847.02",
         "station_id":468
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98268129,40.76344058 ]
         },
         "properties": {
         "capacity":57,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc2c78-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & W 53 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=469",
         "short_name":"6779.05",
         "station_id":469
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00004031,40.74345335 ]
         },
         "properties": {
         "capacity":72,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc36c3-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 20 St & 8 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=470",
         "short_name":"6224.05",
         "station_id":470
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95698119,40.71286844 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc3782-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Grand St & Havemeyer St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=471",
         "short_name":"5267.08",
         "station_id":471
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98194829,40.7457121 ]
         },
         "properties": {
         "capacity":55,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc3a1a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 32 St & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=472",
         "short_name":"6280.12",
         "station_id":472
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9919254,40.72110063 ]
         },
         "properties": {
         "capacity":38,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc3ab9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Rivington St & Chrystie St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=473",
         "short_name":"5453.01",
         "station_id":473
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98683077,40.7451677 ]
         },
         "properties": {
         "capacity":56,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc3b97-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"5 Ave & E 29 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=474",
         "short_name":"6248.06",
         "station_id":474
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97966069,40.74394314 ]
         },
         "properties": {
         "capacity":47,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc3e89-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 31 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=476",
         "short_name":"6239.08",
         "station_id":476
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9900262,40.75640548 ]
         },
         "properties": {
         "capacity":59,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc3f08-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 41 St & 8 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=477",
         "short_name":"6602.03",
         "station_id":477
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99884222,40.76030096 ]
         },
         "properties": {
         "capacity":37,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc41bb-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"11 Ave & W 41 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=478",
         "short_name":"6726.01",
         "station_id":478
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9912551,40.76019252 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc42a0-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"9 Ave & W 45 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=479",
         "short_name":"6717.06",
         "station_id":479
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99061728,40.76669671 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc4334-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 53 St & 10 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=480",
         "short_name":"6890.01",
         "station_id":480
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96264403,40.71260486 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc4599-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"S 3 St & Bedford Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=481",
         "short_name":"5235.05",
         "station_id":481
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99931783,40.73935542 ]
         },
         "properties": {
         "capacity":77,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc462a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 15 St & 7 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=482",
         "short_name":"6030.06",
         "station_id":482
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98889957,40.73223272 ]
         },
         "properties": {
         "capacity":34,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc481a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 12 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=483",
         "short_name":"5788.12",
         "station_id":483
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98338988,40.75038009 ]
         },
         "properties": {
         "capacity":40,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc4b4c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 37 St & 5 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=485",
         "short_name":"6398.06",
         "station_id":485
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98855723,40.7462009 ]
         },
         "properties": {
         "capacity":41,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc4bd9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & W 29 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=486",
         "short_name":"6289.06",
         "station_id":486
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97573881,40.73314259 ]
         },
         "properties": {
         "capacity":34,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc4dc3-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 20 St & FDR Drive",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=487",
         "short_name":"5886.02",
         "station_id":487
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.993934,40.751551 ]
         },
         "properties": {
         "capacity":66,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc686c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"8 Ave & W 33 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=490",
         "short_name":"6450.12",
         "station_id":490
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99093085,40.75019995 ]
         },
         "properties": {
         "capacity":68,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc6c79-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 33 St & 7 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=492",
         "short_name":"6407.07",
         "station_id":492
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99723551,40.74734825 ]
         },
         "properties": {
         "capacity":66,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc7323-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 26 St & 8 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=494",
         "short_name":"6297.02",
         "station_id":494
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99301222,40.76269882 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc73b0-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 47 St & 10 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=495",
         "short_name":"6824.07",
         "station_id":495
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99238967,40.73726186 ]
         },
         "properties": {
         "capacity":47,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc741f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 16 St & 5 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=496",
         "short_name":"6022.04",
         "station_id":496
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99009296,40.73704984 ]
         },
         "properties": {
         "capacity":66,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc748f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 17 St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=497",
         "short_name":"5980.07",
         "station_id":497
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98808416,40.74854862 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc7511-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & W 32 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=498",
         "short_name":"6364.09",
         "station_id":498
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98191841,40.76915505 ]
         },
         "properties": {
         "capacity":36,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc7580-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & W 60 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=499",
         "short_name":"6948.11",
         "station_id":499
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98336183,40.76228826 ]
         },
         "properties": {
         "capacity":52,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc75ec-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & W 51 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=500",
         "short_name":"6779.04",
         "station_id":500
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97121214,40.744219 ]
         },
         "properties": {
         "capacity":79,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc7659-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"FDR Drive & E 35 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=501",
         "short_name":"6230.04",
         "station_id":501
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.981346,40.714215 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc76cd-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Henry St & Grand St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=502",
         "short_name":"5294.04",
         "station_id":502
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98751968,40.73827428 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc7773-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 20 St & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=503",
         "short_name":"6055.08",
         "station_id":503
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98165557,40.73221853 ]
         },
         "properties": {
         "capacity":53,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc7802-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"1 Ave & E 16 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=504",
         "short_name":"5779.08",
         "station_id":504
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98848395,40.74901271 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc78c4-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"6 Ave & W 33 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=505",
         "short_name":"6364.07",
         "station_id":505
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97973776,40.73912601 ]
         },
         "properties": {
         "capacity":45,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc7957-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 25 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=507",
         "short_name":"6046.02",
         "station_id":507
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99667444,40.76341379 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc79e6-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 46 St & 11 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=508",
         "short_name":"6795.01",
         "station_id":508
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00197139,40.7454973 ]
         },
         "properties": {
         "capacity":63,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc7a7d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"9 Ave & W 22 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=509",
         "short_name":"6266.06",
         "station_id":509
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.988639,40.768254 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc7cc3-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 56 St & 10 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=513",
         "short_name":"6955.01",
         "station_id":513
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00277668,40.76087502 ]
         },
         "properties": {
         "capacity":52,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc7d58-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"12 Ave & W 40 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=514",
         "short_name":"6765.01",
         "station_id":514
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99461843,40.76009437 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc7de9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 43 St & 10 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=515",
         "short_name":"6756.01",
         "station_id":515
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96784384,40.75206862 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc7e75-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 47 St & 1 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=516",
         "short_name":"6498.09",
         "station_id":516
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97791,40.751581 ]
         },
         "properties": {
         "capacity":69,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc7f02-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Pershing Square South",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=517",
         "short_name":"6432.08",
         "station_id":517
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9734419,40.74780373 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc7f8f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 39 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=518",
         "short_name":"6345.01",
         "station_id":518
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.977706,40.751873 ]
         },
         "properties": {
         "capacity":69,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc8025-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Pershing Square North",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=519",
         "short_name":"6432.09",
         "station_id":519
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97207836,40.75714758 ]
         },
         "properties": {
         "capacity":51,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc81ce-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 51 St & Lexington Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=522",
         "short_name":"6659.01",
         "station_id":522
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99138152,40.75466591 ]
         },
         "properties": {
         "capacity":51,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc825c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 38 St & 8 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=523",
         "short_name":"6526.03",
         "station_id":523
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0021163,40.75594159 ]
         },
         "properties": {
         "capacity":56,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc8382-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 34 St & 11 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=525",
         "short_name":"6578.01",
         "station_id":525
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98490707,40.74765947 ]
         },
         "properties": {
         "capacity":40,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc840f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 33 St & 5 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=526",
         "short_name":"6322.01",
         "station_id":526
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97706058,40.74290902 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc8527-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"2 Ave & E 31 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=528",
         "short_name":"6197.02",
         "station_id":528
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99098507,40.7575699 ]
         },
         "properties": {
         "capacity":41,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc85bb-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 42 St & 8 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=529",
         "short_name":"6602.05",
         "station_id":529
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99046034,40.77149671 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc864c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"11 Ave & W 59 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=530",
         "short_name":"7059.01",
         "station_id":530
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99266288,40.71893904 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc86d9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Forsyth St & Broome St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=531",
         "short_name":"5453.05",
         "station_id":531
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.960876,40.710451 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc8768-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"S 5 Pl & S 5 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=532",
         "short_name":"5125.03",
         "station_id":532
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98721619,40.75299641 ]
         },
         "properties": {
         "capacity":46,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc87f1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & W 38 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=533",
         "short_name":"6441.05",
         "station_id":533
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0127234,40.70255065 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc8886-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Water - Whitehall Plaza",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=534",
         "short_name":"4962.04",
         "station_id":534
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97536082,40.74144387 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc89ae-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"1 Ave & E 30 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=536",
         "short_name":"6079.03",
         "station_id":536
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96024116,40.71534825 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc8b6a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Metropolitan Ave & Bedford Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=539",
         "short_name":"5308.04",
         "station_id":539
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98215353,40.74311555 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc8bfd-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lexington Ave & E 29 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=540",
         "short_name":"6164.09",
         "station_id":540
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97809472,40.736502 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc8c90-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 23 St & 1 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=545",
         "short_name":"5929.01",
         "station_id":545
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98303529,40.74444921 ]
         },
         "properties": {
         "capacity":45,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc8d1d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 30 St & Park Ave S",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=546",
         "short_name":"6206.08",
         "station_id":546
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98940236,40.70255088 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc8db1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Front St & Washington St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=2000",
         "short_name":"4936.01",
         "station_id":2000
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.963198,40.716887 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc8eb1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Wythe Ave & Metropolitan Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=2002",
         "short_name":"5348.02",
         "station_id":2002
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98054421,40.73381219 ]
         },
         "properties": {
         "capacity":54,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc8f1f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"1 Ave & E 18 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=2003",
         "short_name":"5854.09",
         "station_id":2003
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97100056,40.70531194 ]
         },
         "properties": {
         "capacity":12,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc9000-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Railroad Ave & Kay Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=2005",
         "short_name":"4990.01",
         "station_id":2005
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97634151,40.76590936 ]
         },
         "properties": {
         "capacity":49,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc9068-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Central Park S & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=2006",
         "short_name":"6876.04",
         "station_id":2006
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01677685,40.70569254 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc90d5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Little West St & 1 Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=2008",
         "short_name":"5001.08",
         "station_id":2008
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99682619,40.71117444 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc9143-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Catherine St & Monroe St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=2009",
         "short_name":"5128.04",
         "station_id":2009
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00234737,40.72165481 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc91b5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Grand St & Greene St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=2010",
         "short_name":"5500.02",
         "station_id":2010
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.976806,40.739445 ]
         },
         "properties": {
         "capacity":36,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dc9223-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 27 St & 1 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=2012",
         "short_name":"6004.06",
         "station_id":2012
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97121414,40.75022392 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dca5f3-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 43 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=2017",
         "short_name":"6422.08",
         "station_id":2017
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98859651,40.75929124 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dca682-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 45 St & 8 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=2021",
         "short_name":"6676.02",
         "station_id":2021
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.959223,40.759107 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dca6f4-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 60 St & York Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=2022",
         "short_name":"6682.08",
         "station_id":2022
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97031366,40.75968085 ]
         },
         "properties": {
         "capacity":36,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dca76a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 55 St & Lexington Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=2023",
         "short_name":"6732.07",
         "station_id":2023
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.015756,40.711512 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dca92d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"South End Ave & Liberty St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3002",
         "short_name":"5184.07",
         "station_id":3002
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96165073,40.72036775 ]
         },
         "properties": {
         "capacity":54,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcac42-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Kent Ave & N 7 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3016",
         "short_name":"5489.03",
         "station_id":3016
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94142771,40.67890679 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcb9f7-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Kingston Ave & Herkimer St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3041",
         "short_name":"4205.06",
         "station_id":3041
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9298911,40.6794268 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcba5e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Fulton St & Utica Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3042",
         "short_name":"4228.02",
         "station_id":3042
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.934903,40.6814598 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcbac5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lewis Ave & Decatur St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3043",
         "short_name":"4237.01",
         "station_id":3043
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.938475,40.6800105 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcbb2c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Albany Ave & Fulton St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3044",
         "short_name":"4237.02",
         "station_id":3044
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.938037,40.682601 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcbbfe-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Marcus Garvey Blvd & Macon St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3046",
         "short_name":"4278.03",
         "station_id":3046
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.944118,40.6823687 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcbdc2-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Halsey St & Tompkins Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3047",
         "short_name":"4319.07",
         "station_id":3047
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94977,40.68402 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcbe7c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Putnam Ave & Nostrand Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3048",
         "short_name":"4327.09",
         "station_id":3048
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96304,40.68488 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcbefb-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Cambridge Pl & Gates Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3049",
         "short_name":"4377.04",
         "station_id":3049
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94111,40.6851532 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcbf69-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Putnam Ave & Throop Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3050",
         "short_name":"4392.04",
         "station_id":3050
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.935775,40.686312 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcc047-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lewis Ave & Madison St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3052",
         "short_name":"4425.02",
         "station_id":3052
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.947915,40.6900815 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcc0b2-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Marcy Ave & Lafayette Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3053",
         "short_name":"4476.03",
         "station_id":3053
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.942061,40.6894932 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcc30b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Greene Ave & Throop Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3054",
         "short_name":"4510.04",
         "station_id":3054
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.950916,40.6883337 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcc37f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Greene Ave & Nostrand Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3055",
         "short_name":"4519.02",
         "station_id":3055
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95133465,40.69072549 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcc3e5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Kosciuszko St & Nostrand Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3056",
         "short_name":"4519.04",
         "station_id":3056
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9452416,40.69128258 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcc44a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Kosciuszko St & Tompkins Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3057",
         "short_name":"4553.04",
         "station_id":3057
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.93705428,40.69237074 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcc5ca-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lewis Ave & Kosciuszko St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3058",
         "short_name":"4617.01",
         "station_id":3058
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.939877,40.6933982 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcc65c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Pulaski St & Marcus Garvey Blvd",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3059",
         "short_name":"4656.03",
         "station_id":3059
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94626915,40.69425403 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcc8b3-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Willoughby Ave & Tompkins Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3060",
         "short_name":"4665.02",
         "station_id":3060
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94371094,40.69622937 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcc920-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Throop Ave & Myrtle Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3061",
         "short_name":"4697.01",
         "station_id":3061
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94954908,40.69539817 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcca0d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Myrtle Ave & Marcy Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3062",
         "short_name":"4707.03",
         "station_id":3062
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95238108,40.69527008 ]
         },
         "properties": {
         "capacity":20,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcca76-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Nostrand Ave & Myrtle Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3063",
         "short_name":"4707.04",
         "station_id":3063
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.93756926,40.69681963 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dccad8-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Myrtle Ave & Lewis Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3064",
         "short_name":"4729.01",
         "station_id":3064
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95032283,40.70029511 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dccc99-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Union Ave & Wallabout St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3065",
         "short_name":"4818.03",
         "station_id":3065
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94708417,40.69957608 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcccfe-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Tompkins Ave & Hopkins St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3066",
         "short_name":"4850.04",
         "station_id":3066
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9437303,40.7016657 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dccd65-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & Whipple St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3067",
         "short_name":"4883.03",
         "station_id":3067
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.940636,40.7031724 ]
         },
         "properties": {
         "capacity":42,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dce2a4-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Humboldt St & Varet St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3068",
         "short_name":"4956.02",
         "station_id":3068
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94818595,40.70411791 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dce4fc-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lorimer St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3069",
         "short_name":"4965.01",
         "station_id":3069
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94407279,40.70510918 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dce567-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"McKibbin St & Manhattan Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3070",
         "short_name":"4996.08",
         "station_id":3070
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94976519,40.70538077 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dce5c9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Boerum St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3071",
         "short_name":"5004.02",
         "station_id":3071
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94644578,40.70583339 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dce660-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Leonard St & Boerum St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3072",
         "short_name":"5036.06",
         "station_id":3072
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94016171,40.70767788 ]
         },
         "properties": {
         "capacity":42,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dce8db-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Montrose Ave & Bushwick Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3074",
         "short_name":"5068.02",
         "station_id":3074
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95796783,40.70708701 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dce9b5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Division Ave & Marcy Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3075",
         "short_name":"5084.03",
         "station_id":3075
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9448625,40.70870368 ]
         },
         "properties": {
         "capacity":36,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcec6b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Scholes St & Manhattan Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3076",
         "short_name":"5108.01",
         "station_id":3076
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95095259,40.70877084 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcecfa-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Stagg St & Union Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3077",
         "short_name":"5117.05",
         "station_id":3077
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96063149,40.70924826 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dced76-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Broadway & Roebling St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3078",
         "short_name":"5125.07",
         "station_id":3078
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95608,40.70934 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcf023-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"S 4 St & Rodney St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3080",
         "short_name":"5156.05",
         "station_id":3080
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.944024,40.711863 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcf0b3-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Graham Ave & Grand St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3081",
         "short_name":"5178.06",
         "station_id":3081
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95141312,40.71167351 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcf30d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Hope St & Union Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3082",
         "short_name":"5187.03",
         "station_id":3082
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94100005,40.71247661 ]
         },
         "properties": {
         "capacity":32,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcf394-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Bushwick Ave & Powers St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3083",
         "short_name":"5250.05",
         "station_id":3083
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95739,40.71469 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcf640-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Roebling St & N 4 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3085",
         "short_name":"5267.09",
         "station_id":3085
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.944507,40.715143 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcf897-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Graham Ave & Conselyea St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3086",
         "short_name":"5291.05",
         "station_id":3086
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95234386,40.71413311 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcf922-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Metropolitan Ave & Meeker Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3087",
         "short_name":"5300.05",
         "station_id":3087
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.952029,40.7160751 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dcfaf6-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Union Ave & Jackson St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3088",
         "short_name":"5300.06",
         "station_id":3088
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95852515,40.7190095 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd01c5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Berry St & N 8 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3092",
         "short_name":"5379.09",
         "station_id":3092
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95850939,40.71745169 ]
         },
         "properties": {
         "capacity":28,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd039b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"N 6 St & Bedford Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3093",
         "short_name":"5379.1",
         "station_id":3093
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94485918,40.7169811 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd056e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Graham Ave & Withers St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3094",
         "short_name":"5403.04",
         "station_id":3094
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94500379,40.71929301 ]
         },
         "properties": {
         "capacity":26,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd0808-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Graham Ave & Herbert St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3095",
         "short_name":"5403.05",
         "station_id":3095
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95242,40.71924 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd1585-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Union Ave & N 12 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3096",
         "short_name":"5411.07",
         "station_id":3096
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94752622,40.72481256 ]
         },
         "properties": {
         "capacity":51,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd17a5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Nassau Ave & Newell St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3100",
         "short_name":"5623.03",
         "station_id":3100
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95484712,40.72079821 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd1846-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"N 12 St & Bedford Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3101",
         "short_name":"5450.04",
         "station_id":3101
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9504154,40.72179134 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd18dd-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Driggs Ave & Lorimer St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3102",
         "short_name":"5481.04",
         "station_id":3102
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.955736,40.724055 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd1ad8-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"N 15 St & Wythe Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3105",
         "short_name":"5520.09",
         "station_id":3105
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94308,40.72325 ]
         },
         "properties": {
         "capacity":22,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd1b65-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Driggs Ave & N Henry St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3106",
         "short_name":"5542.04",
         "station_id":3106
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95212324,40.72311651 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd1bf3-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Bedford Ave & Nassau Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3107",
         "short_name":"5550.05",
         "station_id":3107
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94434,40.72557 ]
         },
         "properties": {
         "capacity":51,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd1c7f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Nassau Ave & Russell St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3108",
         "short_name":"5581.01",
         "station_id":3108
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95621,40.72606 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd1d0f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Banker St & Meserole Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3109",
         "short_name":"5633.04",
         "station_id":3109
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95299117,40.72708584 ]
         },
         "properties": {
         "capacity":28,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd1d9c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Meserole Ave & Manhattan Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3110",
         "short_name":"5666.04",
         "station_id":3110
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95779,40.72906 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd1eb2-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Milton St & Franklin St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3112",
         "short_name":"5752.07",
         "station_id":3112
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95394,40.73026 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd1f44-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Greenpoint Ave & Manhattan Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3113",
         "short_name":"5785.05",
         "station_id":3113
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9550858,40.73232194 ]
         },
         "properties": {
         "capacity":50,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd2060-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"India St & Manhattan Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3115",
         "short_name":"5826.02",
         "station_id":3115
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95826,40.73266 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd20eb-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Huron St & Franklin St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3116",
         "short_name":"5869.04",
         "station_id":3116
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95866,40.73564 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd217d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Franklin St & Dupont St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3117",
         "short_name":"5944.01",
         "station_id":3117
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95284,40.73555 ]
         },
         "properties": {
         "capacity":42,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd2208-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"McGuinness Blvd & Eagle St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3118",
         "short_name":"5977.01",
         "station_id":3118
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95411749,40.74232744 ]
         },
         "properties": {
         "capacity":45,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd2292-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Vernon Blvd & 50 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3119",
         "short_name":"6170.02",
         "station_id":3119
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94733276,40.74524768 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd23a9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Jackson Ave & 46 Rd",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3121",
         "short_name":"6203.02",
         "station_id":3121
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95587325,40.74436329 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd243c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"48 Ave & 5 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3122",
         "short_name":"6212.04",
         "station_id":3122
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.93540375,40.74469738 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd24ca-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"31 St & Thomson Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3123",
         "short_name":"6227.02",
         "station_id":3123
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95451,40.74731 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd2556-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"46 Ave & 5 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3124",
         "short_name":"6286.02",
         "station_id":3124
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94977234,40.74708586 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd25e0-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"45 Rd & 11 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3125",
         "short_name":"6319.01",
         "station_id":3125
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9432635,40.74718234 ]
         },
         "properties": {
         "capacity":34,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd266a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"44 Dr & Jackson Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3126",
         "short_name":"6352.01",
         "station_id":3126
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9521,40.74966 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd26f9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"9 St & 44 Rd",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3127",
         "short_name":"6361.03",
         "station_id":3127
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94594845,40.75052534 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd2786-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"21 St & 43 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3128",
         "short_name":"6395.01",
         "station_id":3128
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94073717,40.75110165 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd2811-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Queens Plaza North & Crescent St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3129",
         "short_name":"6429.01",
         "station_id":3129
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94335788,40.75325964 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd3cb4-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"21 St & Queens Plaza North",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3130",
         "short_name":"6471.02",
         "station_id":3130
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96224618,40.7671284 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd3d7f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 68 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3131",
         "short_name":"6896.16",
         "station_id":3131
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97109243,40.76350532 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd3e14-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 59 St & Madison Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3132",
         "short_name":"6801.01",
         "station_id":3132
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96526895,40.76312584 ]
         },
         "properties": {
         "capacity":51,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd3f33-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"3 Ave & E 62 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3134",
         "short_name":"6762.04",
         "station_id":3134
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95772297,40.77112927 ]
         },
         "properties": {
         "capacity":41,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd3fc3-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 75 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3135",
         "short_name":"6991.12",
         "station_id":3135
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.971518,40.766368 ]
         },
         "properties": {
         "capacity":47,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4051-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"5 Ave & E 63 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3136",
         "short_name":"6904.06",
         "station_id":3136
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96685276,40.77282817 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd40dd-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"5 Ave & E 73 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3137",
         "short_name":"7100.07",
         "station_id":3137
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96409422,40.77118288 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd41ef-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 72 St & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3139",
         "short_name":"6998.08",
         "station_id":3139
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9535166,40.77140426 ]
         },
         "properties": {
         "capacity":55,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd427e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"1 Ave & E 78 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3140",
         "short_name":"7020.09",
         "station_id":3140
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96094022,40.7612274 ]
         },
         "properties": {
         "capacity":41,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4356-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"1 Ave & E 62 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3142",
         "short_name":"6753.08",
         "station_id":3142
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96427393,40.77632142 ]
         },
         "properties": {
         "capacity":47,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd43bd-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"5 Ave & E 78 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3143",
         "short_name":"7161.08",
         "station_id":3143
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9590097,40.77677702 ]
         },
         "properties": {
         "capacity":46,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4423-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 81 St & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3144",
         "short_name":"7188.1",
         "station_id":3144
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95772073,40.77862688 ]
         },
         "properties": {
         "capacity":45,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd448f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 84 St & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3145",
         "short_name":"7243.04",
         "station_id":3145
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9567526,40.77573034 ]
         },
         "properties": {
         "capacity":47,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd44f7-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 81 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3146",
         "short_name":"7154.07",
         "station_id":3146
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95068615,40.77565541 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd45c7-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 84 St & 1 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3148",
         "short_name":"7180.02",
         "station_id":3148
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94803392,40.77536905 ]
         },
         "properties": {
         "capacity":47,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd46a2-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 85 St & York Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3150",
         "short_name":"7146.04",
         "station_id":3150
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94989233,40.7728384 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd470b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 81 St & York Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3151",
         "short_name":"7084.12",
         "station_id":3151
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96119945,40.76873687 ]
         },
         "properties": {
         "capacity":42,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4772-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"3 Ave & E 71 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3152",
         "short_name":"6960.1",
         "station_id":3152
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95856158,40.77314236 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4841-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 77 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3154",
         "short_name":"7092.06",
         "station_id":3154
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96648977,40.76440023 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd48b0-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lexington Ave & E 63 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3155",
         "short_name":"6830.08",
         "station_id":3155
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95348296,40.76663814 ]
         },
         "properties": {
         "capacity":37,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd491c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 72 St & York Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3156",
         "short_name":"6889.12",
         "station_id":3156
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94446054,40.77518615 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4981-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"East End Ave & E 86 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3157",
         "short_name":"7113.08",
         "station_id":3157
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98261428,40.77163851 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd49eb-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 63 St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3158",
         "short_name":"7052.01",
         "station_id":3158
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98266566,40.77492513 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4a52-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 67 St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3159",
         "short_name":"7116.04",
         "station_id":3159
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97374737,40.77896784 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4ac1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Central Park West & W 76 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3160",
         "short_name":"7253.04",
         "station_id":3160
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97728533,40.78018397 ]
         },
         "properties": {
         "capacity":59,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4b2b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 76 St & Columbus Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3161",
         "short_name":"7281.09",
         "station_id":3161
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98093133,40.78339981 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4b91-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 78 St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3162",
         "short_name":"7311.07",
         "station_id":3162
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97782542,40.7734066 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4bf7-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Central Park West & W 68 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3163",
         "short_name":"7079.06",
         "station_id":3163
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97898475,40.7770575 ]
         },
         "properties": {
         "capacity":67,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4c5f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Columbus Ave & W 72 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3164",
         "short_name":"7175.05",
         "station_id":3164
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97620574,40.77579377 ]
         },
         "properties": {
         "capacity":51,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4ccc-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Central Park West & W 72 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3165",
         "short_name":"7141.07",
         "station_id":3165
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98562431,40.78057799 ]
         },
         "properties": {
         "capacity":41,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4d70-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Riverside Dr & W 72 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3166",
         "short_name":"7288.04",
         "station_id":3166
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98093045,40.77966809 ]
         },
         "properties": {
         "capacity":55,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4de9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Amsterdam Ave & W 73 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3167",
         "short_name":"7260.09",
         "station_id":3167
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96961715,40.78472675 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4e54-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Central Park West & W 85 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3168",
         "short_name":"7354.02",
         "station_id":3168
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98128127,40.78720869 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4ec7-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Riverside Dr & W 82 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3169",
         "short_name":"7388.1",
         "station_id":3169
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97283406,40.78499979 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4f31-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 84 St & Columbus Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3170",
         "short_name":"7382.04",
         "station_id":3170
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97667321,40.78524672 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd4f9b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Amsterdam Ave & W 82 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3171",
         "short_name":"7360.1",
         "station_id":3171
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97754961,40.7785669 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd515d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 74 St & Columbus Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3172",
         "short_name":"7230.1",
         "station_id":3172
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98888588,40.77750703 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd51e6-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Riverside Blvd & W 67 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3173",
         "short_name":"7183.03",
         "station_id":3173
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98288594,40.77748046 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd52c8-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 70 St & Amsterdam Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3175",
         "short_name":"7207.08",
         "station_id":3175
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.977112,40.7867947 ]
         },
         "properties": {
         "capacity":63,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd539f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 84 St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3177",
         "short_name":"7409.08",
         "station_id":3177
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98362492,40.78414472 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd5407-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Riverside Dr & W 78 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3178",
         "short_name":"7340.06",
         "station_id":3178
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.941342,40.698617 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd546c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Park Ave & Marcus Garvey Blvd",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3179",
         "short_name":"4768.02",
         "station_id":3179
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99712,40.69878 ]
         },
         "properties": {
         "capacity":0,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd54d1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"FALSE",
         "name":"Brooklyn Bridge Park - Pier 2",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3180",
         "short_name":"4829.05",
         "station_id":3180
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0334588,40.7162469 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd588c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Exchange Place",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3183",
         "short_name":"JC001",
         "station_id":3183
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0335519,40.7141454 ]
         },
         "properties": {
         "capacity":14,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd58f2-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Paulus Hook",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3184",
         "short_name":"JC002",
         "station_id":3184
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.043845,40.7177325 ]
         },
         "properties": {
         "capacity":22,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd5960-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"City Hall",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3185",
         "short_name":"JC003",
         "station_id":3185
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.04311746,40.71958612 ]
         },
         "properties": {
         "capacity":42,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd59d5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Grove St PATH",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3186",
         "short_name":"JC005",
         "station_id":3186
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.03805095,40.7211236 ]
         },
         "properties": {
         "capacity":22,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd5a42-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Warren St",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3187",
         "short_name":"JC006",
         "station_id":3187
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0836394,40.7182113 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd5e69-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Union St",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3191",
         "short_name":"JC051",
         "station_id":3191
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0557013,40.7112423 ]
         },
         "properties": {
         "capacity":22,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd5f24-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Liberty Light Rail",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3192",
         "short_name":"JC052",
         "station_id":3192
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.07840595,40.7246051 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd5f99-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lincoln Park",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3193",
         "short_name":"JC053",
         "station_id":3193
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.06762213,40.72533993 ]
         },
         "properties": {
         "capacity":22,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd6000-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"McGinley Square",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3194",
         "short_name":"JC055",
         "station_id":3194
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.06391263,40.7308971 ]
         },
         "properties": {
         "capacity":34,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd606c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Sip Ave",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3195",
         "short_name":"JC056",
         "station_id":3195
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0439909,40.7443187 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd630c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Riverview Park",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3196",
         "short_name":"JC057",
         "station_id":3196
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0404433,40.74871595 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd63de-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Heights Elevator",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3198",
         "short_name":"JC059",
         "station_id":3198
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0321082,40.7287448 ]
         },
         "properties": {
         "capacity":14,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd6441-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Newport Pkwy",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3199",
         "short_name":"JC008",
         "station_id":3199
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.066921,40.737711 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd650d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Dey St",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3201",
         "short_name":"JC065",
         "station_id":3201
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0337589,40.7272235 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd6721-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Newport PATH",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3202",
         "short_name":"JC066",
         "station_id":3202
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.04424731,40.72759597 ]
         },
         "properties": {
         "capacity":26,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd7b37-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Hamilton Park",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3203",
         "short_name":"JC009",
         "station_id":3203
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.04963791,40.71653978 ]
         },
         "properties": {
         "capacity":22,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd7c33-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"JC Medical Center",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3205",
         "short_name":"JC011",
         "station_id":3205
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0575736,40.7311689 ]
         },
         "properties": {
         "capacity":26,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd7cab-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Hilltop",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3206",
         "short_name":"JC019",
         "station_id":3206
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0524783,40.7376037 ]
         },
         "properties": {
         "capacity":26,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd7f10-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Oakland Ave",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3207",
         "short_name":"JC022",
         "station_id":3207
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0506564,40.7241765 ]
         },
         "properties": {
         "capacity":22,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd7fe2-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Brunswick St",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3209",
         "short_name":"JC023",
         "station_id":3209
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.05178863,40.74267714 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd8043-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Pershing Field",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3210",
         "short_name":"JC024",
         "station_id":3210
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.04630454,40.72152515 ]
         },
         "properties": {
         "capacity":22,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd80ac-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Newark Ave",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3211",
         "short_name":"JC032",
         "station_id":3211
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.05044364,40.73478582 ]
         },
         "properties": {
         "capacity":22,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd836d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Christ Hospital",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3212",
         "short_name":"JC034",
         "station_id":3212
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.04772663,40.71848892 ]
         },
         "properties": {
         "capacity":22,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd83fc-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Van Vorst Park",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3213",
         "short_name":"JC035",
         "station_id":3213
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0364857,40.7127742 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd8479-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Essex Light Rail",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3214",
         "short_name":"JC038",
         "station_id":3214
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.05950308,40.73496102 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd8b48-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"5 Corners Library",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3220",
         "short_name":"JC018",
         "station_id":3220
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.93561,40.743 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd8bd9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"47 Ave & 31 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3221",
         "short_name":"6151.03",
         "station_id":3221
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0641943,40.7236589 ]
         },
         "properties": {
         "capacity":14,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd9183-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Baldwin at Montgomery",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3225",
         "short_name":"JC020",
         "station_id":3225
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97137,40.78275 ]
         },
         "properties": {
         "capacity":45,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd9213-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 82 St & Central Park West",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3226",
         "short_name":"7304.08",
         "station_id":3226
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96592081,40.7678008 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd9b0f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 67 St & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3231",
         "short_name":"6932.14",
         "station_id":3231
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98304269,40.68962189 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dd9dba-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Bond St & Fulton St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3232",
         "short_name":"4479.06",
         "station_id":3232
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97992194,40.75216528 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dda376-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 41 St & Madison Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3235",
         "short_name":"6474.12",
         "station_id":3235
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99379969,40.75898481 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dda55f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 42 St & Dyer Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3236",
         "short_name":"6644.07",
         "station_id":3236
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.944694,40.686203 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddb595-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Monroe St & Tompkins Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3241",
         "short_name":"4434.06",
         "station_id":3241
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99183363,40.69102926 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddb605-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Schermerhorn St & Court St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3242",
         "short_name":"4565.04",
         "station_id":3242
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96226227,40.75892386 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddb66e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 58 St & 1 Ave (NE Corner)",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3243",
         "short_name":"6682.03",
         "station_id":3243
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99490342,40.73143724 ]
         },
         "properties": {
         "capacity":0,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddb6d9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"University Pl & E 8 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3244",
         "short_name":"5755.14",
         "station_id":3244
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9476791,40.68035608 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddb95a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Verona Pl & Fulton St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3249",
         "short_name":"4124.04",
         "station_id":3249
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01129574,40.72771408 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddbdb1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Pier 40 - Hudson River Park",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3256",
         "short_name":"5696.03",
         "station_id":3256
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00218427,40.75018156 ]
         },
         "properties": {
         "capacity":37,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddbecd-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 27 St & 10 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3258",
         "short_name":"6382.08",
         "station_id":3258
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99923384,40.74937024 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddbf5a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"9 Ave & W 28 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3259",
         "short_name":"6416.08",
         "station_id":3259
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99662137,40.72706363 ]
         },
         "properties": {
         "capacity":45,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddd369-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Mercer St & Bleecker St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3260",
         "short_name":"5679.05",
         "station_id":3260
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9907527,40.72951496 ]
         },
         "properties": {
         "capacity":59,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddd545-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Cooper Square & Astor Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3263",
         "short_name":"5712.03",
         "station_id":3263
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.03852552,40.71241882 ]
         },
         "properties": {
         "capacity":14,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddd78e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Morris Canal",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3267",
         "short_name":"JC072",
         "station_id":3267
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.06285852,40.71346383 ]
         },
         "properties": {
         "capacity":14,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddd81a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lafayette Park",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3268",
         "short_name":"JC078",
         "station_id":3268
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.05038893,40.72601173 ]
         },
         "properties": {
         "capacity":14,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddd8a8-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Brunswick & 6th",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3269",
         "short_name":"JC081",
         "station_id":3269
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.04557168,40.72528911 ]
         },
         "properties": {
         "capacity":14,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddd93e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Jersey & 6th St",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3270",
         "short_name":"JC027",
         "station_id":3270
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.04595256,40.72333159 ]
         },
         "properties": {
         "capacity":14,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddda59-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Jersey & 3rd",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3272",
         "short_name":"JC074",
         "station_id":3272
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.04288411,40.72165072 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dddae7-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Manila & 1st",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3273",
         "short_name":"JC082",
         "station_id":3273
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.03891444,40.7183552 ]
         },
         "properties": {
         "capacity":14,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dddc08-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Columbus Drive",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3275",
         "short_name":"JC014",
         "station_id":3275
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.04281706,40.71458404 ]
         },
         "properties": {
         "capacity":26,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dddc98-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Marin Light Rail",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3276",
         "short_name":"JC013",
         "station_id":3276
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.06661093,40.71435837 ]
         },
         "properties": {
         "capacity":14,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dddd28-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Communipaw & Berry Lane",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3277",
         "short_name":"JC084",
         "station_id":3277
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.04879034,40.72568548 ]
         },
         "properties": {
         "capacity":14,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddddb4-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Monmouth and 6th",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3278",
         "short_name":"JC075",
         "station_id":3278
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.04996783,40.72163014 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddde40-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Dixon Mills",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3279",
         "short_name":"JC076",
         "station_id":3279
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.07126188,40.7192822 ]
         },
         "properties": {
         "capacity":14,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddded0-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Astor Place",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3280",
         "short_name":"JC077",
         "station_id":3280
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.05727148,40.74590997 ]
         },
         "properties": {
         "capacity":14,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dddf5f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Leonard Gordon Park",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3281",
         "short_name":"JC080",
         "station_id":3281
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95939,40.78307 ]
         },
         "properties": {
         "capacity":38,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dddfed-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"5 Ave & E 88 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3282",
         "short_name":"7323.1",
         "station_id":3282
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97041561,40.7882213 ]
         },
         "properties": {
         "capacity":47,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde079-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 89 St & Columbus Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3283",
         "short_name":"7432.09",
         "station_id":3283
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95595908,40.7814107 ]
         },
         "properties": {
         "capacity":38,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde103-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 88 St & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3284",
         "short_name":"7293.1",
         "station_id":3284
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9747,40.78839 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde197-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 87 St & Amsterdam Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3285",
         "short_name":"7458.03",
         "station_id":3285
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9521667,40.7806284 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde208-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 89 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3286",
         "short_name":"7265.1",
         "station_id":3286
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9488134,40.778301 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde2d9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 88 St & 1 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3288",
         "short_name":"7235.13",
         "station_id":3288
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97288918,40.79017948 ]
         },
         "properties": {
         "capacity":32,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde343-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 90 St & Amsterdam Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3289",
         "short_name":"7432.04",
         "station_id":3289
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.946041,40.7779453 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde3b1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 89 St & York Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3290",
         "short_name":"7204.08",
         "station_id":3290
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.957481,40.7857851 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde484-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"5 Ave & E 93 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3292",
         "short_name":"7372.1",
         "station_id":3292
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9739,40.7921 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde4ef-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 92 St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3293",
         "short_name":"7502.01",
         "station_id":3293
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.955327,40.7835016 ]
         },
         "properties": {
         "capacity":38,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde559-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 91 St & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3294",
         "short_name":"7344.05",
         "station_id":3294
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.964839,40.79127 ]
         },
         "properties": {
         "capacity":59,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde5c6-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Central Park W & W 96 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3295",
         "short_name":"7499.05",
         "station_id":3295
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94891962,40.78245418 ]
         },
         "properties": {
         "capacity":42,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde630-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 93 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3296",
         "short_name":"7286.02",
         "station_id":3296
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97988067,40.6686627 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde69c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"6 St & 7 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3297",
         "short_name":"3834.1",
         "station_id":3297
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99383324,40.686371 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde703-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Warren St & Court St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3298",
         "short_name":"4413.08",
         "station_id":3298
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95206,40.78813 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde76a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 98 St & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3299",
         "short_name":"7443.17",
         "station_id":3299
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97637606,40.66514682 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde7dc-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Prospect Park West & 8 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3300",
         "short_name":"3722.04",
         "station_id":3300
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.968087,40.7919557 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde845-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Columbus Ave & W 95 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3301",
         "short_name":"7520.07",
         "station_id":3301
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96434123,40.7969347 ]
         },
         "properties": {
         "capacity":22,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde8ac-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Columbus Ave & W 103 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3302",
         "short_name":"7595.17",
         "station_id":3302
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99440329,40.6849894 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde914-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Butler St & Court St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3303",
         "short_name":"4339.01",
         "station_id":3303
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98377641,40.668127 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dde9af-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"6 Ave & 9 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3304",
         "short_name":"3803.09",
         "station_id":3304
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94965589,40.7811223 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddea2a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 91 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3305",
         "short_name":"7286.01",
         "station_id":3305
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98199886,40.6662078 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddea99-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"10 St & 7 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3306",
         "short_name":"3762.08",
         "station_id":3306
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.974124,40.7941654 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddeaff-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"West End Ave & W 94 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3307",
         "short_name":"7524.09",
         "station_id":3307
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99645295,40.6861758 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddeb67-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Kane St & Clinton St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3308",
         "short_name":"4455.11",
         "station_id":3308
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94860294,40.7859201 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddebce-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 97 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3309",
         "short_name":"7365.08",
         "station_id":3309
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98396846,40.663779 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddec3e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"14 St & 7 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3310",
         "short_name":"3731.11",
         "station_id":3310
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0016256,40.68763155 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddeca9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Columbia St & Kane St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3311",
         "short_name":"4422.05",
         "station_id":3311
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94594,40.7817212 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dded11-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"1 Ave & E 94 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3312",
         "short_name":"7286.05",
         "station_id":3312
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9854617,40.6663181 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dded7a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"6 Ave & 12 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3313",
         "short_name":"3803.05",
         "station_id":3313
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99917254,40.6847514 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddee56-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Henry St & Degraw St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3315",
         "short_name":"4380.08",
         "station_id":3315
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98700053,40.6686273 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddef2d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"10 St & 5 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3317",
         "short_name":"3842.08",
         "station_id":3317
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9471673,40.7839636 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddef96-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"2 Ave & E 96 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3318",
         "short_name":"7338.02",
         "station_id":3318
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98895053,40.666287 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddeffd-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"14 St & 5 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3319",
         "short_name":"3771.06",
         "station_id":3319
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96286845,40.79406661 ]
         },
         "properties": {
         "capacity":49,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddf06e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Central Park West & W 100 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3320",
         "short_name":"7538.12",
         "station_id":3320
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99785267,40.6831164 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66ddf310-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Clinton St & Union St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3321",
         "short_name":"4266.03",
         "station_id":3321
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9904394,40.668603 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de06ef-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"12 St & 4 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3322",
         "short_name":"3882.01",
         "station_id":3322
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9605909,40.7981856 ]
         },
         "properties": {
         "capacity":59,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de077f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 106 St & Central Park West",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3323",
         "short_name":"7606.01",
         "station_id":3323
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99333264,40.6685455 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de07ec-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"3 Ave & 14 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3324",
         "short_name":"3850.03",
         "station_id":3324
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00194698,40.67434 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de08c9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Clinton St & Centre St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3326",
         "short_name":"4045.01",
         "station_id":3326
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94728331,40.7877214 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de0933-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"3 Ave & E 100 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3327",
         "short_name":"7414.17",
         "station_id":3327
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9645,40.795 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de099d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 100 St & Manhattan Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3328",
         "short_name":"7538.14",
         "station_id":3328
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99318208,40.6829151 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de0a0a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Degraw St & Smith St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3329",
         "short_name":"4298.05",
         "station_id":3329
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00494695,40.6725058 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de0a78-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Henry St & Bay St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3330",
         "short_name":"3972.08",
         "station_id":3330
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97114574,40.8013434 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de0bcb-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Riverside Dr & W 104 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3331",
         "short_name":"7623.13",
         "station_id":3331
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99079025,40.68199044 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de0c43-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Degraw St & Hoyt St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3332",
         "short_name":"4258.07",
         "station_id":3332
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0075572,40.6747055 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de0cab-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Columbia St & Lorraine St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3333",
         "short_name":"4103.08",
         "station_id":3333
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98282002,40.6772744 ]
         },
         "properties": {
         "capacity":28,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de0d91-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Union St & 4 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3335",
         "short_name":"4175.15",
         "station_id":3335
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.953559,40.787801 ]
         },
         "properties": {
         "capacity":41,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de0dfd-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 97 St & Madison Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3336",
         "short_name":"7393.09",
         "station_id":3336
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01195556,40.67363551 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de103b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Dwight St & Van Dyke St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3337",
         "short_name":"3981.1",
         "station_id":3337
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94552579,40.7862586 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de10a8-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"2 Ave & E 99 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3338",
         "short_name":"7386.1",
         "station_id":3338
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97846879,40.6765304 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de110b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Berkeley Pl & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3339",
         "short_name":"4134.06",
         "station_id":3339
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0100698,40.6753274 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de11bc-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Wolcott St & Dwight St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3340",
         "short_name":"4054.02",
         "station_id":3340
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96186,40.795346 ]
         },
         "properties": {
         "capacity":41,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de122e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Central Park West & W 102 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3341",
         "short_name":"7577.24",
         "station_id":3341
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0094613,40.6777748 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de1295-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Pioneer St & Richards St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3342",
         "short_name":"4128.08",
         "station_id":3342
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96211287,40.7997568 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de12ff-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 107 St & Columbus Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3343",
         "short_name":"7619.05",
         "station_id":3343
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.011169,40.679043 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de1368-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Pioneer St & Van Brunt St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3344",
         "short_name":"4169.04",
         "station_id":3344
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95242929,40.78948542 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de13dc-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Madison Ave & E 99 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3345",
         "short_name":"7443.01",
         "station_id":3345
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97523209,40.67514684 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de1448-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Berkeley Pl & 7 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3346",
         "short_name":"4051.01",
         "station_id":3346
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01275056,40.6773429 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de14af-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Van Brunt St & Wolcott St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3347",
         "short_name":"4095.03",
         "station_id":3347
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.015665,40.677236 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de1516-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Coffey St & Conover St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3348",
         "short_name":"4137.1",
         "station_id":3348
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97087984,40.6729679 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de1580-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Grand Army Plaza & Plaza St West",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3349",
         "short_name":"4010.15",
         "station_id":3349
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97041192,40.7973721 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de17f7-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 100 St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3350",
         "short_name":"7580.01",
         "station_id":3350
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94164802,40.7869946 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de186f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 102 St & 1 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3351",
         "short_name":"7407.13",
         "station_id":3351
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00879525,40.67267243 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de18d7-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Sigourney St & Columbia St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3352",
         "short_name":"3940.04",
         "station_id":3352
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97363831,40.668132 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de19ab-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"3 St & Prospect Park West",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3354",
         "short_name":"3865.05",
         "station_id":3354
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96845281,40.76800889 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de1a1f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 66 St & Madison Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3355",
         "short_name":"6969.08",
         "station_id":3355
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98470567,40.7746671 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de1a8a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Amsterdam Ave & W 66 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3356",
         "short_name":"7149.05",
         "station_id":3356
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96644925,40.8008363 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de1af4-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 106 St & Amsterdam Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3357",
         "short_name":"7634.01",
         "station_id":3357
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97484126,40.6711978 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de1b5b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Garfield Pl & 8 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3358",
         "short_name":"3978.13",
         "station_id":3358
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96703464,40.7691572 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de1bc3-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 68 St & Madison Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3359",
         "short_name":"6932.15",
         "station_id":3359
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9786517,40.7829391 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de1c33-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Amsterdam Ave & W 79 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3360",
         "short_name":"7311.02",
         "station_id":3360
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9787282,40.6740886 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de1ea2-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Carroll St & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3361",
         "short_name":"4019.06",
         "station_id":3361
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96069399,40.7781314 ]
         },
         "properties": {
         "capacity":34,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de1f17-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Madison Ave & E 82 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3362",
         "short_name":"7188.13",
         "station_id":3362
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95033068,40.7904828 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de1f7f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 102 St & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3363",
         "short_name":"7488.24",
         "station_id":3363
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9814832,40.6751622 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de1fe7-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Carroll St & 5 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3364",
         "short_name":"4060.09",
         "station_id":3364
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97839676,40.6703837 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de205d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"3 St & 7 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3365",
         "short_name":"3905.15",
         "station_id":3365
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96818053,40.8021174 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de20c8-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"West End Ave & W 107 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3366",
         "short_name":"7650.05",
         "station_id":3366
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95249933,40.7922553 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de2131-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"5 Ave & E 103 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3367",
         "short_name":"7511.19",
         "station_id":3367
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98352355,40.6728155 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de2199-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"5 Ave & 3 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3368",
         "short_name":"3987.06",
         "station_id":3368
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9468208,40.7724607 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de2201-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 82 St & East End Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3369",
         "short_name":"7049.04",
         "station_id":3369
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95577801,40.7727966 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de2274-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 78 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3370",
         "short_name":"7057.07",
         "station_id":3370
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98501143,40.67461342 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de24e2-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"4 Ave & 2 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3371",
         "short_name":"4028.05",
         "station_id":3371
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95482273,40.7689738 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de2556-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 74 St & 1 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3372",
         "short_name":"6953.08",
         "station_id":3372
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98775226,40.6750705 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de25bd-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"3 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3373",
         "short_name":"4028.03",
         "station_id":3373
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.955613,40.799484 ]
         },
         "properties": {
         "capacity":36,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de2625-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Central Park North & Adam Clayton Powell Blvd",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3374",
         "short_name":"7617.07",
         "station_id":3374
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96060712,40.7699426 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de269c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"3 Ave & E 72 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3375",
         "short_name":"7028.04",
         "station_id":3375
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9622207,40.76471852 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de2707-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 65 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3376",
         "short_name":"6860.12",
         "station_id":3376
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99037292,40.6786115 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de2771-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Carroll St & Bond St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3377",
         "short_name":"4184.07",
         "station_id":3377
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96222088,40.773763 ]
         },
         "properties": {
         "capacity":28,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de27da-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 76 St & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3378",
         "short_name":"7128.08",
         "station_id":3378
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94755757,40.7903051 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de2a00-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 103 St & Lexington Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3379",
         "short_name":"7463.09",
         "station_id":3379
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99364123,40.6777287 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de2b2f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"3 St & Hoyt St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3381",
         "short_name":"4110.1",
         "station_id":3381
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99475825,40.680611 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de2b97-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Carroll St & Smith St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3382",
         "short_name":"4225.14",
         "station_id":3382
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96699104,40.804213 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de3fde-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Cathedral Pkwy & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3383",
         "short_name":"7680.03",
         "station_id":3383
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99599099,40.6787242 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de4078-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Smith St & 3 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3384",
         "short_name":"4151.01",
         "station_id":3384
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99905709,40.6809591 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de4336-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"1 Pl & Clinton St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3386",
         "short_name":"4193.14",
         "station_id":3386
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94945003,40.7934337 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de43a5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 106 St & Madison Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3387",
         "short_name":"7528.31",
         "station_id":3387
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99990419,40.6828003 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de4408-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"President St & Henry St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3388",
         "short_name":"4307.13",
         "station_id":3388
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00348559,40.6830456 ]
         },
         "properties": {
         "capacity":28,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de44ba-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Carroll St & Columbia St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3389",
         "short_name":"4348.07",
         "station_id":3389
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9432083,40.79329668 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de452c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 109 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3390",
         "short_name":"7504.12",
         "station_id":3390
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.93956237,40.7892529 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de4594-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 106 St & 1 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3391",
         "short_name":"7456.03",
         "station_id":3391
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00860912,40.6812117 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de47bf-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Commerce St & Van Brunt St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3392",
         "short_name":"4243.01",
         "station_id":3392
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00785041,40.6794327 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de482a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Richards St & Delavan St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3393",
         "short_name":"4202.04",
         "station_id":3393
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00647134,40.6769993 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de4897-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Columbia St & W 9 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3394",
         "short_name":"4086.05",
         "station_id":3394
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00324957,40.6763744 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de48f9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Henry St & W 9 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3395",
         "short_name":"4086.06",
         "station_id":3395
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00014502,40.6783563 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de4959-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Clinton St & 4 Place",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3396",
         "short_name":"4119.04",
         "station_id":3396
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99869893,40.6763947 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de4b0b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Court St & Nelson St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3397",
         "short_name":"4077.07",
         "station_id":3397
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99785768,40.6746957 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de4bbb-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Smith St & 9 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3398",
         "short_name":"4077.04",
         "station_id":3398
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98983002,40.67260298 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de4c32-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"7 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3399",
         "short_name":"3996.01",
         "station_id":3399
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94782145,40.7961535 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de4c9c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 110 St & Madison Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3400",
         "short_name":"7587.14",
         "station_id":3400
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99331394,40.6724811 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de4d05-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"2 Ave & 9 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3401",
         "short_name":"3996.04",
         "station_id":3401
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99203074,40.6902375 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de4f30-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Court St & State St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3402",
         "short_name":"4488.08",
         "station_id":3402
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98876585,40.6705135 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de4f9c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"4 Ave & 9 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3403",
         "short_name":"3955.05",
         "station_id":3403
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98541675,40.6704922 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de5005-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"7 St & 5 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3404",
         "short_name":"3914.02",
         "station_id":3404
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98208968,40.6704836 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de5095-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"5 St & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3405",
         "short_name":"3874.01",
         "station_id":3405
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98765475,40.679098 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de5320-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Union St & Nevins St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3407",
         "short_name":"4143.03",
         "station_id":3407
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99520919,40.6881529 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de53aa-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Congress St & Clinton St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3408",
         "short_name":"4455.07",
         "station_id":3408
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99063168,40.6867443 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de542a-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Bergen St & Smith St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3409",
         "short_name":"4446.01",
         "station_id":3409
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98759104,40.6864442 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de5613-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Dean St & Hoyt St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3410",
         "short_name":"4446.05",
         "station_id":3410
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98620772,40.6849668 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de56e5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Bond St & Bergen St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3411",
         "short_name":"4404.1",
         "station_id":3411
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98302136,40.6853761 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de5773-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Pacific St & Nevins St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3412",
         "short_name":"4362.04",
         "station_id":3412
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98258555,40.6827549 ]
         },
         "properties": {
         "capacity":22,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de59bd-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Wyckoff St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3413",
         "short_name":"4290.06",
         "station_id":3413
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97567332,40.68094472 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de5a47-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Bergen St & Flatbush Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3414",
         "short_name":"4281.08",
         "station_id":3414
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97519523,40.6793307 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de5ace-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Prospect Pl & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3415",
         "short_name":"4166.08",
         "station_id":3415
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97324283,40.6776147 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de5d57-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"7 Ave & Park Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3416",
         "short_name":"4125.07",
         "station_id":3416
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97854971,40.6795766 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de5dde-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Baltic St & 5 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3417",
         "short_name":"4208.11",
         "station_id":3417
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97111473,40.6750207 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de5e5b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Plaza St West & Flatbush Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3418",
         "short_name":"4010.13",
         "station_id":3418
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98154004,40.6792788 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de602e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Douglass St & 4 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3419",
         "short_name":"4175.14",
         "station_id":3419
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98432695,40.6802133 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de6100-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Douglass St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3420",
         "short_name":"4217.02",
         "station_id":3420
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00242364,40.6859296 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de63cd-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Columbia St & Degraw St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3422",
         "short_name":"4422.04",
         "station_id":3422
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97945255,40.66106337 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de65a4-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"West Drive & Prospect Park West",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3423",
         "short_name":"3651.04",
         "station_id":3423
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.945993,40.791976 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de677e-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 106 St & Lexington Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3424",
         "short_name":"7504.18",
         "station_id":3424
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94370784,40.7892105 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de6a0f-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"2 Ave & E 104 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3425",
         "short_name":"7436.11",
         "station_id":3425
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99600983,40.72430527 ]
         },
         "properties": {
         "capacity":40,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de6dc1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Lafayette St & Jersey St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3427",
         "short_name":"5561.08",
         "station_id":3427
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9779076,40.68506807 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de71af-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Hanson Pl & Ashland Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3429",
         "short_name":"4395.07",
         "station_id":3429
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9422369,40.71907891 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de73fd-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Richardson St & N Henry St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3430",
         "short_name":"5433.03",
         "station_id":3430
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9771834,40.79025417 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de8505-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 88 St & West End Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3434",
         "short_name":"7484.07",
         "station_id":3434
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99596,40.718822 ]
         },
         "properties": {
         "capacity":45,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de85d2-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Grand St & Elizabeth St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3435",
         "short_name":"5382.06",
         "station_id":3435
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97700369,40.79313481 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de871c-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Riverside Dr & W 91 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3437",
         "short_name":"7524.16",
         "station_id":3437
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98949474,40.69241829 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66de88d7-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Fulton St & Adams St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3440",
         "short_name":"4637.06",
         "station_id":3440
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94800901,40.72146256 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dea1d9-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Eckford St & Engert Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3449",
         "short_name":"5512.05",
         "station_id":3449
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94885391,40.71915572 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dea4bf-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Bayard St & Leonard St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3452",
         "short_name":"5442.05",
         "station_id":3452
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94910336,40.71335226 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dea52b-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Devoe St & Lorimer St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3453",
         "short_name":"5259.06",
         "station_id":3453
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94705951,40.71036854 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dea596-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Leonard St & Maujer St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3454",
         "short_name":"5148.03",
         "station_id":3454
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94821286,40.71638032 ]
         },
         "properties": {
         "capacity":22,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dea674-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Jackson St & Leonard St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3456",
         "short_name":"5332.1",
         "station_id":3456
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97209525,40.76302594 ]
         },
         "properties": {
         "capacity":46,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dea6e1-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 58 St & Madison Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3457",
         "short_name":"6839.04",
         "station_id":3457
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97835016,40.76309387 ]
         },
         "properties": {
         "capacity":40,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dea74d-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"W 55 St & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3458",
         "short_name":"6809.08",
         "station_id":3458
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96930575,40.75763228 ]
         },
         "properties": {
         "capacity":34,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dea7b5-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"E 53 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3459",
         "short_name":"6617.02",
         "station_id":3459
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01122332,40.71485151 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66dea894-0aca-11e7-82f6-3863bb44ef7c",
         "has_kiosk":"TRUE",
         "name":"Murray St & Greenwich St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3461",
         "short_name":"5288.12",
         "station_id":3461
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98797393,40.73536706 ]
         },
         "properties": {
         "capacity":37,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"647a2a80-9630-41b0-9b91-1f464b0bf3cc",
         "has_kiosk":"TRUE",
         "name":"E 16 St & Irving Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3463",
         "short_name":"5938.11",
         "station_id":3463
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98257732,40.75668721 ]
         },
         "properties": {
         "capacity":34,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"0dedba6c-6e46-4fa1-af7b-b6114897b65e",
         "has_kiosk":"TRUE",
         "name":"W 45 St & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3466",
         "short_name":"6593.03",
         "station_id":3466
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00165856,40.72494672 ]
         },
         "properties": {
         "capacity":42,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"bde94a25-6089-4490-af3a-8cc5702230b8",
         "has_kiosk":"TRUE",
         "name":"W Broadway & Spring Street",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3467",
         "short_name":"5569.06",
         "station_id":3467
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95995021,40.73181402 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"a75ba4d2-b8e6-482d-844a-df20fe8cf97a",
         "has_kiosk":"TRUE",
         "name":"India St & West St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3469",
         "short_name":"5794.03",
         "station_id":3469
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00747359,40.74275383 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"2527619f-ef89-425c-bf3b-60cc0ec519bf",
         "has_kiosk":"TRUE",
         "name":"W 15 St & 10 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3472",
         "short_name":"6115.09",
         "station_id":3472
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01062787,40.65539977 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"5a5a38d1-f28d-4e51-bf85-27bb384135c7",
         "has_kiosk":"TRUE",
         "name":"39 St & 2 Ave - Citi Bike HQ at Industry City",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3477",
         "short_name":"3501.01",
         "station_id":3477
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00870204,40.65708867 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"dd482585-3028-453f-a98d-55019db9b26c",
         "has_kiosk":"TRUE",
         "name":"2 Ave & 36 St - Citi Bike HQ at Industry City",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3478",
         "short_name":"3460.01",
         "station_id":3478
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.04105,40.71649 ]
         },
         "properties": {
         "capacity":22,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"4b0a681b-465e-4aca-8fe5-1342c06dbba9",
         "has_kiosk":"TRUE",
         "name":"York St",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3481",
         "short_name":"JC096",
         "station_id":3481
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.05099,40.71942 ]
         },
         "properties": {
         "capacity":14,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"6107e75a-2493-4e3d-a3e0-d4886d3416e5",
         "has_kiosk":"TRUE",
         "name":"Montgomery St",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3483",
         "short_name":"JC099",
         "station_id":3483
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98451656,40.68841743 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"b3cab614-16ad-459b-abeb-4d5109a2d84e",
         "has_kiosk":"TRUE",
         "name":"Schermerhorn St & Bond St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3486",
         "short_name":"4479.08",
         "station_id":3486
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.937261,40.796879 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"9b7e3b8b-97ef-4038-820c-7cd1c1a34fc7",
         "has_kiosk":"TRUE",
         "name":"E 116 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3490",
         "short_name":"7563.06",
         "station_id":3490
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.93504,40.79747 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"dee309e7-b7f8-4ee7-8999-e9f4e63ecc3b",
         "has_kiosk":"TRUE",
         "name":"E 118 St & 1 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3491",
         "short_name":"7596.1",
         "station_id":3491
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9419949,40.8005385 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"7a15d81b-357e-42e0-b208-93ffd562fd63",
         "has_kiosk":"TRUE",
         "name":"E 118 St & Park Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3492",
         "short_name":"7625.18",
         "station_id":3492
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9389152,40.799139 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"e73cf71b-db05-44f9-b57a-689d65320d68",
         "has_kiosk":"TRUE",
         "name":"E 118 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3493",
         "short_name":"7611.02",
         "station_id":3493
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9423,40.797911 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"bf317efc-13f1-42be-8243-373a29354033",
         "has_kiosk":"TRUE",
         "name":"E 115 St & Lexington Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3494",
         "short_name":"7599.09",
         "station_id":3494
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9362541,40.7945663 ]
         },
         "properties": {
         "capacity":26,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"566935d6-4d66-4b42-9822-f2a816e357b9",
         "has_kiosk":"TRUE",
         "name":"E 114 St & 1 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3495",
         "short_name":"7540.02",
         "station_id":3495
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9383,40.7923272 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"0b613329-b8c8-4b8c-ad40-79952aa41157",
         "has_kiosk":"TRUE",
         "name":"1 Ave & E 110 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3496",
         "short_name":"7522.02",
         "station_id":3496
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9333349,40.7949879 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"1aa5c287-0f0d-4697-ba4b-4f2daa6b2adf",
         "has_kiosk":"TRUE",
         "name":"Pleasant Ave & E 116 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3497",
         "short_name":"7450.05",
         "station_id":3497
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9311847,40.7974772 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"20ff5447-eac3-43b7-820f-f6fa3a2e12a8",
         "has_kiosk":"TRUE",
         "name":"Pleasant Ave & E 120 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3498",
         "short_name":"7579.01",
         "station_id":3498
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9349,40.8006721 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"625711ba-3b5d-46a7-a8f9-7f4eb17ec1be",
         "has_kiosk":"TRUE",
         "name":"2 Ave & E 122 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3499",
         "short_name":"7622.12",
         "station_id":3499
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.944846,40.7989445 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"b976906e-81c4-44c5-a160-e17815c0d47b",
         "has_kiosk":"TRUE",
         "name":"E 115 St & Madison Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3500",
         "short_name":"7599.02",
         "station_id":3500
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9442507,40.8014866 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"d3f51f51-7e51-4c75-8600-d76916608707",
         "has_kiosk":"TRUE",
         "name":"E 118 St & Madison Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3501",
         "short_name":"7640.04",
         "station_id":3501
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9441232,40.7954121 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"c05cd2e2-74e8-4526-a62b-d631e005fdd8",
         "has_kiosk":"TRUE",
         "name":"Lexington Ave & E 111 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3502",
         "short_name":"7567.06",
         "station_id":3502
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.942954,40.80295 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"bacfe3c2-7946-45ed-91f9-f5b91791de75",
         "has_kiosk":"TRUE",
         "name":"Madison Ave & E 120 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3503",
         "short_name":"7667.04",
         "station_id":3503
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9379,40.8029263 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"16a4effc-282e-4053-b47b-31f734d50c08",
         "has_kiosk":"TRUE",
         "name":"E 123 St & Lexington Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3504",
         "short_name":"7636.05",
         "station_id":3504
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.936322,40.805726 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"5f63411c-91ce-4788-a567-d388cc812a15",
         "has_kiosk":"TRUE",
         "name":"Lexington Ave & E 127 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3505",
         "short_name":"7662.13",
         "station_id":3505
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9398167,40.8013066 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"d9bc0b3e-1af8-4cb6-a082-8ef1245ef329",
         "has_kiosk":"TRUE",
         "name":"Lexington Ave & E 120 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3506",
         "short_name":"7652.04",
         "station_id":3506
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9396861,40.8045555 ]
         },
         "properties": {
         "capacity":36,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66880044-5411-4143-af39-eaa0a0fd0528",
         "has_kiosk":"TRUE",
         "name":"Park Ave & E 124 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3507",
         "short_name":"7682.01",
         "station_id":3507
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.953149,40.809725 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"dccaeeb5-c53a-4f48-80e6-05675b71a8c8",
         "has_kiosk":"TRUE",
         "name":"St Nicholas Ave & Manhattan Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3508",
         "short_name":"7723.01",
         "station_id":3508
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9500739,40.8011939 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"897e8739-ee1d-4b2e-b151-ad7e64e87697",
         "has_kiosk":"TRUE",
         "name":"Lenox Ave & W 115 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3509",
         "short_name":"7627.1",
         "station_id":3509
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.949373,40.8078316 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"b55f9b55-7fa7-4f0f-9732-78cbe07452e1",
         "has_kiosk":"TRUE",
         "name":"Adam Clayton Powell Blvd & W 123 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3510",
         "short_name":"7704.04",
         "station_id":3510
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9532423,40.802535 ]
         },
         "properties": {
         "capacity":22,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"760ebaea-f7c7-45ad-aa3b-395d97adcf8f",
         "has_kiosk":"TRUE",
         "name":"Adam Clayton Powell Blvd & W 115 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3511",
         "short_name":"7643.18",
         "station_id":3511
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9337894,40.7747175 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"0dfbf0ea-5ca2-4b7b-b667-0a6b1548a4fc",
         "has_kiosk":"TRUE",
         "name":"27 Ave & 4 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3512",
         "short_name":"7132.01",
         "station_id":3512
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.923706,40.774645 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"ff9581d3-3e1a-463a-bdab-d8150c468be2",
         "has_kiosk":"TRUE",
         "name":"21 St & Hoyt Ave S",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3513",
         "short_name":"7126.01",
         "station_id":3513
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.927631,40.7767 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"fc774664-3c9b-4a8f-a79e-f6907db00a1d",
         "has_kiosk":"TRUE",
         "name":"Astoria Park S & Shore Blvd",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3514",
         "short_name":"7159.08",
         "station_id":3514
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.918544,40.774591 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"387e2863-83ad-4589-8004-794a7b624801",
         "has_kiosk":"TRUE",
         "name":"24 Ave & 26 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3515",
         "short_name":"7152.1",
         "station_id":3515
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9184057,40.7699176 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"b506be9e-45d3-43d1-a262-27d8fa91e974",
         "has_kiosk":"TRUE",
         "name":"31 St & Astoria Blvd",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3516",
         "short_name":"6989.07",
         "station_id":3516
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9170074,40.7711528 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"6cd10426-b4e9-40e1-9b35-61f609190ac0",
         "has_kiosk":"TRUE",
         "name":"31 St & Hoyt Ave N",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3517",
         "short_name":"7018.01",
         "station_id":3517
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9452087,40.808442 ]
         },
         "properties": {
         "capacity":34,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"7e36cd9b-b271-42e5-b344-b7a3771c795e",
         "has_kiosk":"TRUE",
         "name":"Lenox Ave & W 126 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3518",
         "short_name":"7720.03",
         "station_id":3518
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.951475,40.804372 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"138094a0-cd7d-4014-9b21-4fb2afd3980e",
         "has_kiosk":"TRUE",
         "name":"Adam Clayton Powell Blvd & W 118 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3520",
         "short_name":"7670.09",
         "station_id":3520
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9523,40.7987859 ]
         },
         "properties": {
         "capacity":36,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"0e003543-3656-448f-8a93-029d265f2e26",
         "has_kiosk":"TRUE",
         "name":"Lenox Ave & W 111 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3521",
         "short_name":"7602.05",
         "station_id":3521
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9120938,40.7701477 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"0630217a-3913-47d9-9540-cf85688296a5",
         "has_kiosk":"TRUE",
         "name":"37 St & 24 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3522",
         "short_name":"6981.16",
         "station_id":3522
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.916142,40.7729 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"3299ff79-36aa-42ef-b7f1-c40e95c8f570",
         "has_kiosk":"TRUE",
         "name":"24 Ave & 29 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3523",
         "short_name":"7119.04",
         "station_id":3523
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9225403,40.7774552 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"3e1bdcec-e762-4e83-b447-007f05923cce",
         "has_kiosk":"TRUE",
         "name":"19 St & 24 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3524",
         "short_name":"7186.15",
         "station_id":3524
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9153175,40.776165 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"a04bf523-3c76-4fad-88bf-e99037f9b796",
         "has_kiosk":"TRUE",
         "name":"23 Ave & 27 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3525",
         "short_name":"7178.02",
         "station_id":3525
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9125551,40.7747878 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"5671825f-3eef-46c4-9e56-86add83d3a30",
         "has_kiosk":"TRUE",
         "name":"31 St & 23 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3526",
         "short_name":"7144.01",
         "station_id":3526
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.941747,40.80698 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"553ada94-8679-403c-ae41-6e679ee4812a",
         "has_kiosk":"TRUE",
         "name":"5 Ave & E 126 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3527",
         "short_name":"7701.19",
         "station_id":3527
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9077436,40.7713937 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"cc758f1a-8b28-4ff5-bc75-fbe62c453378",
         "has_kiosk":"TRUE",
         "name":"Steinway St & 23 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3528",
         "short_name":"7009.02",
         "station_id":3528
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9430681,40.8107922 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"14f928c6-9a51-40a2-b7e6-a74e8b351dbf",
         "has_kiosk":"TRUE",
         "name":"Lenox Ave & W 130 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3529",
         "short_name":"7753.13",
         "station_id":3529
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9145645,40.7787185 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"9e99abca-c679-4788-9a4e-39066660bd6a",
         "has_kiosk":"TRUE",
         "name":"Crescent St & Ditmars Blvd",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3530",
         "short_name":"7233.05",
         "station_id":3530
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9492286,40.8125511 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"bfea6c5b-2e1a-42c5-8199-2ded6042d57b",
         "has_kiosk":"TRUE",
         "name":"Frederick Douglass Blvd & W 129 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3531",
         "short_name":"7795.09",
         "station_id":3531
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9183302,40.78145 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"550153a5-2ea1-4c76-b1cd-77667005f55d",
         "has_kiosk":"TRUE",
         "name":"Ditmars Blvd & 19 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3532",
         "short_name":"7291.06",
         "station_id":3532
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9518776,40.8114323 ]
         },
         "properties": {
         "capacity":34,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"dd8627c8-4190-4a30-8758-e77a7b010437",
         "has_kiosk":"TRUE",
         "name":"St. Nicholas Ave & W 126 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3533",
         "short_name":"7756.1",
         "station_id":3533
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.954692,40.805159 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"0f6fd186-656a-41b3-ba4a-456d22da177c",
         "has_kiosk":"TRUE",
         "name":"Frederick Douglass Blvd & W 117 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3534",
         "short_name":"7688.12",
         "station_id":3534
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.945925,40.804038 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"668ef22c-4665-4f42-bf6a-ab9e8a2899b1",
         "has_kiosk":"TRUE",
         "name":"Mt Morris Park W & W 120 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3535",
         "short_name":"7685.14",
         "station_id":3535
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9641,40.8082 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"8e631be4-1e0c-4627-a261-18f0003d0ba2",
         "has_kiosk":"TRUE",
         "name":"W 116 St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3536",
         "short_name":"7713.11",
         "station_id":3536
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9710097,40.6809741 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"c3189056-8eda-4278-891f-e8e15c2d759a",
         "has_kiosk":"TRUE",
         "name":"Carlton Ave & Dean St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3537",
         "short_name":"4199.12",
         "station_id":3537
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96295,40.802692 ]
         },
         "properties": {
         "capacity":45,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"4d79bdb9-7c35-4d35-9f6e-3c1b849c453a",
         "has_kiosk":"TRUE",
         "name":"W 110 St & Amsterdam Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3538",
         "short_name":"7646.04",
         "station_id":3538
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9607082,40.8067581 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"7efcb97f-6c8f-4445-86a9-3f758a822f17",
         "has_kiosk":"TRUE",
         "name":"W 116 St & Amsterdam Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3539",
         "short_name":"7692.11",
         "station_id":3539
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9551508,40.81 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"23539f3b-fb83-4f34-b8b8-9f1f37b5e646",
         "has_kiosk":"TRUE",
         "name":"Morningside Ave & W 123 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3540",
         "short_name":"7741.01",
         "station_id":3540
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.956461,40.813358 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"7f8cb36a-2bf4-4d57-afbd-331310f25355",
         "has_kiosk":"TRUE",
         "name":"Amsterdam Ave & W 125 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3541",
         "short_name":"7800.03",
         "station_id":3541
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9596214,40.8086249 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"1b00fb53-da32-4b14-9a9a-84a391c8951c",
         "has_kiosk":"TRUE",
         "name":"Amsterdam Ave & W 119 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3542",
         "short_name":"7727.07",
         "station_id":3542
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95736456,40.81028506 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"d80c274e-d17d-4a00-9b76-274c9fe4d0e1",
         "has_kiosk":"TRUE",
         "name":"Morningside Dr & Amsterdam Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3543",
         "short_name":"7741.04",
         "station_id":3543
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9646795,40.6804836 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"284b08f2-3d26-4f52-9463-25e4a07c16f7",
         "has_kiosk":"TRUE",
         "name":"Underhill Ave & Pacific St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3544",
         "short_name":"4231.04",
         "station_id":3544
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9612547,40.8120562 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"32d3adc3-c3dd-4a97-a4db-95d467f3c3aa",
         "has_kiosk":"TRUE",
         "name":"Broadway & W 122 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3545",
         "short_name":"7783.18",
         "station_id":3545
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9587903,40.6791944 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"292ad4f3-9fb0-44ec-9e61-613c711f73c1",
         "has_kiosk":"TRUE",
         "name":"Pacific St & Classon Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3546",
         "short_name":"4148.07",
         "station_id":3546
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9590255,40.8143256 ]
         },
         "properties": {
         "capacity":41,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"bc5235a5-7f10-4a27-806e-9c25fa700959",
         "has_kiosk":"TRUE",
         "name":"Broadway & Moylan Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3547",
         "short_name":"7823.03",
         "station_id":3547
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.962408,40.678045 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"1d32e684-602b-46b6-8c96-ab47b57a03f3",
         "has_kiosk":"TRUE",
         "name":"Grand Ave & Bergen St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3549",
         "short_name":"4190.06",
         "station_id":3549
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.941606,40.795508 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"594b4656-9d83-4301-8967-3b92c126531c",
         "has_kiosk":"TRUE",
         "name":"3 Ave & E 112 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3551",
         "short_name":"7543.15",
         "station_id":3551
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.964928,40.805973 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"5b4a90b8-426d-4a40-a7ca-87e51d690883",
         "has_kiosk":"TRUE",
         "name":"W 113 St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3552",
         "short_name":"7713.01",
         "station_id":3552
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.957145,40.801694 ]
         },
         "properties": {
         "capacity":37,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"46bdd925-fb6c-4654-85d8-e0db4da62abf",
         "has_kiosk":"TRUE",
         "name":"Frederick Douglass Blvd & W 112 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3553",
         "short_name":"7631.23",
         "station_id":3553
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9485678,40.7552433 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"0687075b-cf2d-4130-a859-fe841aafbd3f",
         "has_kiosk":"TRUE",
         "name":"Vernon Blvd & 41 Rd",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3554",
         "short_name":"6514.08",
         "station_id":3554
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.93797,40.751047 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"9a40cb60-6ede-4c9e-9d64-dc55cae57f31",
         "has_kiosk":"TRUE",
         "name":"28 St & 41 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3555",
         "short_name":"6462.19",
         "station_id":3555
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9397405,40.7527085 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"3bfc859b-5c5f-43bc-b2e7-b64ed8ea9ede",
         "has_kiosk":"TRUE",
         "name":"24 St & 41 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3556",
         "short_name":"6505.01",
         "station_id":3556
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.945133,40.75742 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"5db1fefa-0f10-4c58-a7ce-113f3164ced8",
         "has_kiosk":"TRUE",
         "name":"40 Ave & 9 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3557",
         "short_name":"6664.05",
         "station_id":3557
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9680438,40.6794388 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"8caf71df-76c3-43fb-be98-d555d2291460",
         "has_kiosk":"TRUE",
         "name":"Bergen St & Vanderbilt Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3558",
         "short_name":"4157.1",
         "station_id":3558
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9391224,40.7576314 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"49d2cd03-f508-483f-a7c9-7fd450e5e6db",
         "has_kiosk":"TRUE",
         "name":"21 St & 38 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3559",
         "short_name":"6656.05",
         "station_id":3559
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.934326,40.754876 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"e3cc182c-dda2-469e-8599-6ee9d12842c3",
         "has_kiosk":"TRUE",
         "name":"28 St & 38 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3560",
         "short_name":"6538.03",
         "station_id":3560
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9279917,40.7531106 ]
         },
         "properties": {
         "capacity":26,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"12279d2b-29f6-4e02-a7f0-244970f7edd5",
         "has_kiosk":"TRUE",
         "name":"37 Ave & 35 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3561",
         "short_name":"6529.02",
         "station_id":3561
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9596082,40.6765198 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"ab1dd03c-7669-4280-a533-47c369a8ca4d",
         "has_kiosk":"TRUE",
         "name":"Classon Ave & St Marks Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3562",
         "short_name":"4074.03",
         "station_id":3562
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.932719,40.757186 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"35b8b636-18d3-4860-b0a9-39c0bce96a10",
         "has_kiosk":"TRUE",
         "name":"28 St & 36 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3563",
         "short_name":"6614.01",
         "station_id":3563
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9362726,40.7601853 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"b94d0241-bce7-44a9-ab1c-ece0740a4134",
         "has_kiosk":"TRUE",
         "name":"21 St & 36 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3564",
         "short_name":"6729.02",
         "station_id":3564
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9411265,40.7614376 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"822d96e8-fb6c-463a-b866-aec9e408ad5e",
         "has_kiosk":"TRUE",
         "name":"36 Ave & 10 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3565",
         "short_name":"6737.03",
         "station_id":3565
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9321455,40.7596276 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"d265dbc7-ef55-4f5b-8a2b-f2015dc71fb8",
         "has_kiosk":"TRUE",
         "name":"Crescent St & 35 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3566",
         "short_name":"6688.01",
         "station_id":3566
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9391141,40.7627442 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"a1dccb78-9993-4363-a7a9-20aa59df39e2",
         "has_kiosk":"TRUE",
         "name":"11 St & 35 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3567",
         "short_name":"6768.04",
         "station_id":3567
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9262231,40.7569332 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"f6143531-4a16-4aac-9b55-573ef7ef162e",
         "has_kiosk":"TRUE",
         "name":"34 St & 35 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3568",
         "short_name":"6605.08",
         "station_id":3568
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9561677,40.6758324 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"66f68197-4897-4576-896a-48e0312104c5",
         "has_kiosk":"TRUE",
         "name":"Franklin Ave & St Marks Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3569",
         "short_name":"4107.05",
         "station_id":3569
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9236611,40.7557327 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"60c5a043-1367-4a27-96ee-394ba60e2154",
         "has_kiosk":"TRUE",
         "name":"35 Ave & 37 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3570",
         "short_name":"6563.12",
         "station_id":3570
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.952918,40.676368 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"a2f71eea-05a2-4fe7-99ab-f74535c880ae",
         "has_kiosk":"TRUE",
         "name":"Bedford Ave & Bergen St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3571",
         "short_name":"4066.15",
         "station_id":3571
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.921631,40.756913 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"548cb08c-4ec1-46d9-8978-1a8d3bf42454",
         "has_kiosk":"TRUE",
         "name":"34 Ave & 38 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3572",
         "short_name":"6638.01",
         "station_id":3572
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9242751,40.7580583 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"d5788cfa-817e-4b65-b43f-edda222a3c3c",
         "has_kiosk":"TRUE",
         "name":"35 St & 34 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3573",
         "short_name":"6679.11",
         "station_id":3573
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96579,40.6769694 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"69f84045-48f9-4c6c-90d3-0503e5ed39e9",
         "has_kiosk":"TRUE",
         "name":"Prospect Pl & Underhill Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3574",
         "short_name":"4116.08",
         "station_id":3574
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.930562,40.76108 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"91ca68bd-5ac1-470b-a26d-1ec98ea9cca4",
         "has_kiosk":"TRUE",
         "name":"Crescent St & 34 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3575",
         "short_name":"6759.15",
         "station_id":3575
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.969024,40.6767 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"699d3378-6ea8-465f-888b-c49c60089ce8",
         "has_kiosk":"TRUE",
         "name":"Park Pl & Vanderbilt Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3576",
         "short_name":"4083.13",
         "station_id":3576
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9342862,40.7628138 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"0fa27bd7-b182-4e7a-b5bb-90f4249cb368",
         "has_kiosk":"TRUE",
         "name":"34 Ave & 21 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3577",
         "short_name":"6798.01",
         "station_id":3577
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9564947,40.6741806 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"8d5c4ef9-e18c-4216-ac46-c64dde8015be",
         "has_kiosk":"TRUE",
         "name":"Park Pl & Franklin Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3578",
         "short_name":"4033.06",
         "station_id":3578
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.954131,40.672695 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"dd351a72-4241-4275-843d-0fffa8a1f414",
         "has_kiosk":"TRUE",
         "name":"Sterling Pl & Bedford Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3579",
         "short_name":"3993.03",
         "station_id":3579
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9631611,40.6737236 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"add829db-2feb-4e81-af61-056791a6e53b",
         "has_kiosk":"TRUE",
         "name":"St Johns Pl & Washington Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3580",
         "short_name":"4001.09",
         "station_id":3580
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9671457,40.6740123 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"c83e1ef5-776e-417e-8ee2-d08ca121f884",
         "has_kiosk":"TRUE",
         "name":"Underhill Ave & Lincoln Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3581",
         "short_name":"4042.08",
         "station_id":3581
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9609,40.6721683 ]
         },
         "properties": {
         "capacity":28,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"2b54cb2c-31be-4620-a13c-0fa72b58c90a",
         "has_kiosk":"TRUE",
         "name":"Lincoln Pl & Classon Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3582",
         "short_name":"3960.01",
         "station_id":3582
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9631145,40.6716493 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"e63c8dac-ab44-48c8-83a0-92c53a00f12e",
         "has_kiosk":"TRUE",
         "name":"Eastern Pkwy & Washington Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3583",
         "short_name":"3928.08",
         "station_id":3583
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9576801,40.6707767 ]
         },
         "properties": {
         "capacity":42,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"1dacb0f6-29f5-4d1b-b910-92ffa5b4ca5d",
         "has_kiosk":"TRUE",
         "name":"Eastern Pkwy & Franklin Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3584",
         "short_name":"3919.07",
         "station_id":3584
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9554162,40.6691783 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"17aeb1e3-fd18-4cf9-9473-17dfa5b0a312",
         "has_kiosk":"TRUE",
         "name":"Union St & Bedford Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3585",
         "short_name":"3879.04",
         "station_id":3585
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9364848,40.7638753 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"ec42fb3a-af54-46aa-a8b3-b17d72ed4475",
         "has_kiosk":"TRUE",
         "name":"34 Ave & 13 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3586",
         "short_name":"6836.07",
         "station_id":3586
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9618148,40.6686744 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"74a1dc19-f894-4246-99f1-476a92452995",
         "has_kiosk":"TRUE",
         "name":"Carroll St & Washington Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3587",
         "short_name":"3887.03",
         "station_id":3587
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9373554,40.7671863 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"32c60668-a192-4d06-aa7c-6d6f7aed6b45",
         "has_kiosk":"TRUE",
         "name":"Vernon Blvd & 10 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3588",
         "short_name":"6937.07",
         "station_id":3588
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9347774,40.7668 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"9bd28b11-cf11-4938-abb2-dfa5ec800e32",
         "has_kiosk":"TRUE",
         "name":"Broadway & 12 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3589",
         "short_name":"6901.01",
         "station_id":3589
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9588,40.6679411 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"b90574d1-e9e7-45be-8adb-e38cb285fea5",
         "has_kiosk":"TRUE",
         "name":"Carroll St & Franklin Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3590",
         "short_name":"3847.04",
         "station_id":3590
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.930819,40.7659 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"2ec1235f-a043-4e3a-9ba1-56f7dd4624b7",
         "has_kiosk":"TRUE",
         "name":"21 St & 31 Dr",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3591",
         "short_name":"6865.03",
         "station_id":3591
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9286471,40.7633589 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"9d95a4a9-bcfe-4189-bb7d-abd9992ecbaf",
         "has_kiosk":"TRUE",
         "name":"Crescent St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3592",
         "short_name":"6827.11",
         "station_id":3592
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.925921,40.761584 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"3f36c26d-c57f-47cc-9672-20f19babb36a",
         "has_kiosk":"TRUE",
         "name":"31 St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3593",
         "short_name":"6789.04",
         "station_id":3593
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9222427,40.760339 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"8c2ed08f-1660-4db8-9168-4709427c23ed",
         "has_kiosk":"TRUE",
         "name":"35 St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3595",
         "short_name":"6750.16",
         "station_id":3595
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9574686,40.6642406 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"1208a3c2-8f70-4af9-8362-648e5845fe9e",
         "has_kiosk":"TRUE",
         "name":"Sullivan Pl & Bedford Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3596",
         "short_name":"3736.04",
         "station_id":3596
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9166368,40.7577284 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"e4645d0d-8b76-4c46-b2b9-be25592e0659",
         "has_kiosk":"TRUE",
         "name":"43 St & Broadway",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3597",
         "short_name":"6670.03",
         "station_id":3597
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9142678,40.7595701 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"305c221f-4e0b-4a5a-902c-3d1043dfe606",
         "has_kiosk":"TRUE",
         "name":"Newton Rd & 44 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3598",
         "short_name":"6743.06",
         "station_id":3598
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9605695,40.66314 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"56b3ca32-104a-4920-a879-a97a820858c4",
         "has_kiosk":"TRUE",
         "name":"Franklin Ave & Empire Blvd",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3599",
         "short_name":"3704.01",
         "station_id":3599
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9569115,40.6627059 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"981f1311-004f-41c3-ba5b-3679f78aeb70",
         "has_kiosk":"TRUE",
         "name":"Sterling St & Bedford Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3601",
         "short_name":"3665.06",
         "station_id":3601
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.920827,40.763154 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"0e5be726-2452-42a0-9be8-ea85c8408e4c",
         "has_kiosk":"TRUE",
         "name":"31 Ave & 34 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3602",
         "short_name":"6819.15",
         "station_id":3602
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9240312,40.7647 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"42032bf9-4599-4035-bc01-c80bec1a7122",
         "has_kiosk":"TRUE",
         "name":"31 Ave & 30 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3603",
         "short_name":"6857.09",
         "station_id":3603
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9538746,40.6630619 ]
         },
         "properties": {
         "capacity":17,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"6dec8948-44c7-4085-9682-446a891feb42",
         "has_kiosk":"TRUE",
         "name":"Rogers Ave & Sterling St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3604",
         "short_name":"3696.05",
         "station_id":3604
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9265474,40.7658346 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"a6287af0-9a9e-4708-b61f-8e758be4b914",
         "has_kiosk":"TRUE",
         "name":"31 Ave & Crescent St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3605",
         "short_name":"6893.1",
         "station_id":3605
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.948852,40.74252 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"9e0b3452-ef6d-4e94-8c05-7bef199cdb74",
         "has_kiosk":"TRUE",
         "name":"49 Ave & 21 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3606",
         "short_name":"6128.04",
         "station_id":3606
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01030064,40.72019521 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"c1e24edf-7192-433f-8d38-be5b6b3647c5",
         "has_kiosk":"TRUE",
         "name":"North Moore St & Greenwich St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3664",
         "short_name":"5470.12",
         "station_id":3664
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9322662,40.7682 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"d7904cd0-4b1b-47d0-8103-937bcf5ff845",
         "has_kiosk":"TRUE",
         "name":"31 Ave & 14 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3607",
         "short_name":"6966.04",
         "station_id":3607
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9566,40.7423737 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"40eaa69a-d3ab-48fc-b395-b5bdc6a1aa85",
         "has_kiosk":"TRUE",
         "name":"5 St & 51 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3608",
         "short_name":"6137.04",
         "station_id":3608
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9354504,40.7692475 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"4d4a3e7b-1005-4bfd-8680-340a20cacbee",
         "has_kiosk":"TRUE",
         "name":"Vernon Blvd & 31 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3609",
         "short_name":"7003.06",
         "station_id":3609
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.934171,40.770845 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"73ee0bab-fb54-4e9a-880e-ac6b946f804f",
         "has_kiosk":"TRUE",
         "name":"Vernon Blvd & 30 Rd",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3610",
         "short_name":"7003.03",
         "station_id":3610
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9534573,40.7449067 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"4753c1ba-a86e-431e-94fb-06403cdee4d7",
         "has_kiosk":"TRUE",
         "name":"Vernon Blvd & 47 Rd",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3611",
         "short_name":"6212.08",
         "station_id":3611
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9286078,40.7703743 ]
         },
         "properties": {
         "capacity":15,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"914e3e7c-87da-4f52-aa03-5449c6361fa2",
         "has_kiosk":"TRUE",
         "name":"30 Ave & 21 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3612",
         "short_name":"6996.01",
         "station_id":3612
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.957539,40.745038 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"c3d5f47f-cfc3-4c1f-86bb-bcf770d2949b",
         "has_kiosk":"TRUE",
         "name":"Center Blvd & 48 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3613",
         "short_name":"6254.06",
         "station_id":3613
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9249574,40.768692 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"fe93b3ae-1d86-4ee9-9eb6-9e11808966aa",
         "has_kiosk":"TRUE",
         "name":"Crescent St & 30 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3614",
         "short_name":"6958.06",
         "station_id":3614
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9460927,40.748 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"0eae62b5-0de3-4d69-9872-2cd53c509d0e",
         "has_kiosk":"TRUE",
         "name":"44 Dr & 21 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3615",
         "short_name":"6278.04",
         "station_id":3615
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9136695,40.7656251 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"08bf2fe0-219d-48cd-87c5-6163b3a2eafd",
         "has_kiosk":"TRUE",
         "name":"Steinway St & 28 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3616",
         "short_name":"6915.02",
         "station_id":3616
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9169858,40.7671 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"3575749f-123a-4a80-870d-7ca7c7f9c8a9",
         "has_kiosk":"TRUE",
         "name":"28 Ave & 35 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3617",
         "short_name":"6951.03",
         "station_id":3617
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.941275,40.7485 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"72796825-88b1-43a0-bb6d-2b41d337b1fc",
         "has_kiosk":"TRUE",
         "name":"27 St & Hunter St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3618",
         "short_name":"6310.06",
         "station_id":3618
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9246145,40.7713615 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"d56a8542-048a-4aca-ac7f-f27a9e6c908b",
         "has_kiosk":"TRUE",
         "name":"Newtown Ave & 23 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3619",
         "short_name":"7026.08",
         "station_id":3619
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9479119,40.7519071 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"a617924a-31b7-45ed-8793-099b7274f34c",
         "has_kiosk":"TRUE",
         "name":"11 St & 43 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3620",
         "short_name":"6438.04",
         "station_id":3620
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9309134,40.7739825 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"0927e331-866f-4d99-99b4-04edde99117a",
         "has_kiosk":"TRUE",
         "name":"27 Ave & 9 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3621",
         "short_name":"7098.05",
         "station_id":3621
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.939182,40.80756 ]
         },
         "properties": {
         "capacity":15,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"c63a83a0-bda1-40a6-835b-f82c363543b9",
         "has_kiosk":"TRUE",
         "name":"E 128 St & Madison Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3622",
         "short_name":"7735.23",
         "station_id":3622
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9634,40.8109494 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"bb32aad7-8308-4ff8-b073-d5b518ffdd09",
         "has_kiosk":"TRUE",
         "name":"W 120 St & Claremont Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3623",
         "short_name":"7745.07",
         "station_id":3623
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9490782,40.8025566 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"dc8223ad-4108-40a8-9ff5-35e8490b4077",
         "has_kiosk":"TRUE",
         "name":"Lenox Ave & W 117 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3628",
         "short_name":"7655.22",
         "station_id":3628
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94776493,40.80949535 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"18eccc71-66be-4e4c-8335-095a9bf0df94",
         "has_kiosk":"TRUE",
         "name":"Adam Clayton Powell Blvd & W 126 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3629",
         "short_name":"7738.04",
         "station_id":3629
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9559308,40.8038654 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"ca4e4962-2169-4559-8f60-b05ab7809750",
         "has_kiosk":"TRUE",
         "name":"Frederick Douglass Blvd & W 115 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3630",
         "short_name":"7658.13",
         "station_id":3630
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.956741,40.666563 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"164935fa-1e0e-49fb-9e20-f1566099987f",
         "has_kiosk":"TRUE",
         "name":"Crown St & Bedford Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3631",
         "short_name":"3808.06",
         "station_id":3631
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96599591,40.68323865 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"2a47ef14-1cbe-4ec6-841d-cc277627fe20",
         "has_kiosk":"TRUE",
         "name":"Fulton St & Waverly Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3637",
         "short_name":"4345.11",
         "station_id":3637
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0354826,40.7242941 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"f841ae52-0bbb-49db-b6eb-f898fbce6108",
         "has_kiosk":"TRUE",
         "name":"Washington St",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3638",
         "short_name":"JC098",
         "station_id":3638
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.034234,40.7192517 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"2de92329-48d0-4cf7-85df-172f91bbb320",
         "has_kiosk":"TRUE",
         "name":"Harborside",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3639",
         "short_name":"JC104",
         "station_id":3639
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0625,40.73367 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"dd8b2f53-8b94-4082-9576-994a4962f9d5",
         "has_kiosk":"TRUE",
         "name":"Journal Square",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3640",
         "short_name":"JC103",
         "station_id":3640
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98918629,40.74286877 ]
         },
         "properties": {
         "capacity":54,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"daefc84c-1b16-4220-8e1f-10ea4866fdc7",
         "has_kiosk":"TRUE",
         "name":"Broadway & W 25 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3641",
         "short_name":"6173.08",
         "station_id":3641
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9398551,40.76315482 ]
         },
         "properties": {
         "capacity":26,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"43f3d3c7-46b0-4812-879d-15afe8804c5f",
         "has_kiosk":"TRUE",
         "name":"35 Ave & 10 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3646",
         "short_name":"6806.06",
         "station_id":3646
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.93725872,40.74128309 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"b2caefee-e912-4783-971e-fff21dc170a5",
         "has_kiosk":"TRUE",
         "name":"48 Ave & 30 Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3647",
         "short_name":"6076.01",
         "station_id":3647
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9707756,40.69795032 ]
         },
         "properties": {
         "capacity":25,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"999865d2-0735-4e85-a9d4-00810231530e",
         "has_kiosk":"TRUE",
         "name":"Flushing Ave & Vanderbilt Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3648",
         "short_name":"4762.05",
         "station_id":3648
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95324737,40.81439444 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"f15ccc6e-5a7c-46e7-b505-0bfc9cae3d83",
         "has_kiosk":"TRUE",
         "name":"W 129 St & Convent Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3649",
         "short_name":"7818.17",
         "station_id":3649
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9334929,40.75186951 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"1e83ffdc-8e72-45c0-8210-4f37e60505c9",
         "has_kiosk":"TRUE",
         "name":"31 St & Northern Blvd",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3654",
         "short_name":"6495.17",
         "station_id":3654
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98583621,40.72307749 ]
         },
         "properties": {
         "capacity":46,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"93e2e1a5-49c5-41f8-a6bf-b399b6a5140d",
         "has_kiosk":"TRUE",
         "name":"E 2 St & Avenue A",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3656",
         "short_name":"5553.1",
         "station_id":3656
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00367558,40.74353373 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"73b403cf-86fd-4f93-a484-5cb06a2abeea",
         "has_kiosk":"TRUE",
         "name":"W 18 St & 9 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3658",
         "short_name":"6190.03",
         "station_id":3658
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00413692,40.74294892 ]
         },
         "properties": {
         "capacity":0,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"49d0bd30-aeb6-4cf2-bd8d-d36ac5829483",
         "has_kiosk":"TRUE",
         "name":"W 17 St & 9 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3659",
         "short_name":"6190.06",
         "station_id":3659
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00138497,40.74102151 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"3cea96f5-1f86-456d-a889-030882ec76ad",
         "has_kiosk":"TRUE",
         "name":"W 16 St & 8 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3660",
         "short_name":"6148.01",
         "station_id":3660
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.96055639,40.66643931 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"81a98b0b-cfd6-48b4-90bd-806ebbc264a0",
         "has_kiosk":"TRUE",
         "name":"Montgomery St & Franklin Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3661",
         "short_name":"3776.05",
         "station_id":3661
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.91691685,40.7612939 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"160091ea-0d19-494a-9c17-c5abdd574bcf",
         "has_kiosk":"TRUE",
         "name":"31 Ave & Steinway St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3662",
         "short_name":"6782.07",
         "station_id":3662
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94984365,40.72395678 ]
         },
         "properties": {
         "capacity":26,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"7a771842-c090-4da1-8c13-72b7f4f50a87",
         "has_kiosk":"TRUE",
         "name":"Leonard St & Nassau Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3668",
         "short_name":"5550.09",
         "station_id":3668
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95427465,40.77477945 ]
         },
         "properties": {
         "capacity":37,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"c111b8a6-9511-4842-b015-d39721f7b89c",
         "has_kiosk":"TRUE",
         "name":"E 81 St & 2 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3671",
         "short_name":"7121.05",
         "station_id":3671
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95563722,40.67759207 ]
         },
         "properties": {
         "capacity":21,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"26176e86-8362-4c91-a693-6aa3f9ce0b73",
         "has_kiosk":"TRUE",
         "name":"Dean St & Franklin Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3673",
         "short_name":"4107.13",
         "station_id":3673
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9867267,40.70140317 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"43eac213-4603-4bc2-b6d6-b45013396282",
         "has_kiosk":"TRUE",
         "name":"Jay St & York St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3674",
         "short_name":"4895.09",
         "station_id":3674
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94968539,40.7845968 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"d9f34ff3-81ea-42ae-87b7-83f77f1fb1e2",
         "has_kiosk":"TRUE",
         "name":"3 Ave & E 95 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3675",
         "short_name":"7365.15",
         "station_id":3675
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.01472628,40.67583294 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"633fbc4c-7617-47ba-a393-aad7a8d26a3e",
         "has_kiosk":"TRUE",
         "name":"Van Brunt St & Van Dyke St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3676",
         "short_name":"4095.1",
         "station_id":3676
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.07106072,40.72755147 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"915057d4-edbc-4c73-8d81-dda33d600d58",
         "has_kiosk":"TRUE",
         "name":"Glenwood Ave",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3677",
         "short_name":"JC094",
         "station_id":3677
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.07195926,40.72572614 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"5aa81a37-ea1d-4bf6-ab40-4751c6b4fb08",
         "has_kiosk":"TRUE",
         "name":"Fairmount Ave",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3678",
         "short_name":"JC093",
         "station_id":3678
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.071455,40.72210379 ]
         },
         "properties": {
         "capacity":14,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"e2c00264-9eea-446d-a1b7-27cef3aed403",
         "has_kiosk":"TRUE",
         "name":"Bergen Ave",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3679",
         "short_name":"JC095",
         "station_id":3679
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98025185,40.75412081 ]
         },
         "properties": {
         "capacity":55,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"a2030439-c91f-466d-9584-f82c99279cee",
         "has_kiosk":"TRUE",
         "name":"E 43 St & 5 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3680",
         "short_name":"6551.03",
         "station_id":3680
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.03768331,40.71517768 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"a59f4f11-5d52-43a2-8a32-ae71137a6af8",
         "has_kiosk":"TRUE",
         "name":"Grand St",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3681",
         "short_name":"JC102",
         "station_id":3681
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00398269,40.73756121 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"1416010d-b36f-49f6-b64e-38a2975e8559",
         "has_kiosk":"TRUE",
         "name":"W 12 St & W 4 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3684",
         "short_name":"5997.02",
         "station_id":3684
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00507033,40.7394482 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"dbf79506-a4ec-4ee4-8a74-5e4d697dde9e",
         "has_kiosk":"TRUE",
         "name":"Gansevoort St & Hudson St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3686",
         "short_name":"6072.14",
         "station_id":3686
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97449784,40.74322681 ]
         },
         "properties": {
         "capacity":59,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"61c82689-3f4c-495d-8f44-e71de8f04088",
         "has_kiosk":"TRUE",
         "name":"E 33 St & 1 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3687",
         "short_name":"6197.08",
         "station_id":3687
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9664948,40.79904139 ]
         },
         "properties": {
         "capacity":47,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"ab5585c8-c2cf-4bab-96cf-d02eced4f6e3",
         "has_kiosk":"TRUE",
         "name":"W 104 St & Amsterdam Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3689",
         "short_name":"7610.13",
         "station_id":3689
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00935516,40.71334184 ]
         },
         "properties": {
         "capacity":36,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"18fcd2c1-dc8b-4a52-9f18-e9b9003bbea5",
         "has_kiosk":"TRUE",
         "name":"Park Pl & Church St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3690",
         "short_name":"5288.08",
         "station_id":3690
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.91065121,40.76408932 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"00284700-9d22-42ce-8485-113fed9879c1",
         "has_kiosk":"TRUE",
         "name":"28 Ave & 44 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3691",
         "short_name":"6879.04",
         "station_id":3691
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97440128,40.69999748 ]
         },
         "properties": {
         "capacity":15,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"918af7b2-e05c-477a-a8c0-7dcff984c566",
         "has_kiosk":"TRUE",
         "name":"5 St & Market St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3692",
         "short_name":"4843.01",
         "station_id":3692
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95921931,40.72248189 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"0e3dedfb-df10-4900-a67b-95349a81bc5c",
         "has_kiosk":"TRUE",
         "name":"N 11 St & Kent Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3693",
         "short_name":"5489.04",
         "station_id":3693
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.0789,40.71113 ]
         },
         "properties": {
         "capacity":18,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"1ec24ce3-2b69-4f3a-a153-c73e583d11f3",
         "has_kiosk":"TRUE",
         "name":"Jackson Square",
         "region_id":70,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3694",
         "short_name":"JC105",
         "station_id":3694
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98918696,40.77515953 ]
         },
         "properties": {
         "capacity":43,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"b0cc08dc-e7dd-48d1-8901-ba496f3ff2f5",
         "has_kiosk":"TRUE",
         "name":"W 64 St & Thelonious Monk Circle",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3697",
         "short_name":"7123.04",
         "station_id":3697
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98917958,40.76360468 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"b442a648-e9f4-4893-951a-64d258bc0e55",
         "has_kiosk":"TRUE",
         "name":"W 50 St & 9 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3699",
         "short_name":"6854.05",
         "station_id":3699
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00504082,40.70831794 ]
         },
         "properties": {
         "capacity":37,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"80b76a71-cc5d-4bb9-93cd-913784617701",
         "has_kiosk":"TRUE",
         "name":"Cliff St & Fulton St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3701",
         "short_name":"5065.11",
         "station_id":3701
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94176483,40.74375241 ]
         },
         "properties": {
         "capacity":19,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"c72970e7-7f1a-4671-bf55-fc34be7c9413",
         "has_kiosk":"TRUE",
         "name":"47 Ave & Skillman Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3704",
         "short_name":"6237.01",
         "station_id":3704
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.983293,40.741459 ]
         },
         "properties": {
         "capacity":55,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"454b4a83-d0b1-42a2-8163-261e2a9d6ab9",
         "has_kiosk":"TRUE",
         "name":"Lexington Ave & E 26 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3707",
         "short_name":"6089.08",
         "station_id":3707
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99431,40.735445 ]
         },
         "properties": {
         "capacity":29,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"eafa19ed-88c2-4efc-bd73-3961f85b6063",
         "has_kiosk":"TRUE",
         "name":"W 13 St & 5 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3708",
         "short_name":"5947.04",
         "station_id":3708
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99642959,40.73804614 ]
         },
         "properties": {
         "capacity":51,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"09dfc0e3-a448-477c-bb3c-9467dc51ef8d",
         "has_kiosk":"TRUE",
         "name":"W 15 St & 6 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3709",
         "short_name":"5989.02",
         "station_id":3709
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98067966,40.72966729 ]
         },
         "properties": {
         "capacity":47,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"d9160982-2d9b-4f08-9469-a559a7b62809",
         "has_kiosk":"TRUE",
         "name":"E 13 St & Avenue A",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3711",
         "short_name":"5779.09",
         "station_id":3711
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99740189,40.75469175 ]
         },
         "properties": {
         "capacity":41,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"a47f77a2-9008-4652-a4f1-b95eee723a1b",
         "has_kiosk":"TRUE",
         "name":"W 35 St & Dyer Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3712",
         "short_name":"6569.08",
         "station_id":3712
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9544354,40.70684203 ]
         },
         "properties": {
         "capacity":61,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"e58234a3-5b23-427e-948f-c1e4571b2bfa",
         "has_kiosk":"TRUE",
         "name":"Division Av & Hooper St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3714",
         "short_name":"5045.05",
         "station_id":3714
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95520136,40.71816969 ]
         },
         "properties": {
         "capacity":31,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"1b28836b-29fd-47a7-9a98-44cd792918fb",
         "has_kiosk":"TRUE",
         "name":"Driggs Ave & N 9 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3715",
         "short_name":"5411.08",
         "station_id":3715
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.93795609,40.7535992 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"c36cfa58-29fe-4c0c-a14f-41c3463487fd",
         "has_kiosk":"TRUE",
         "name":"40 Ave & Crescent St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3716",
         "short_name":"6462.05",
         "station_id":3716
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97950418,40.72746421 ]
         },
         "properties": {
         "capacity":46,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"99d149f9-ad40-461e-beea-fcbf086f9b5a",
         "has_kiosk":"TRUE",
         "name":"E 11 St & Avenue B",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3718",
         "short_name":"5659.11",
         "station_id":3718
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.98721285,40.68461654 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"8ea59fa2-6f09-4dac-b27d-abfa5ee15ccf",
         "has_kiosk":"TRUE",
         "name":"Wyckoff St & Bond St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3720",
         "short_name":"4330.08",
         "station_id":3720
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.92093346,40.76754878 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"cae4f2f4-9642-474c-95cc-6cc07592f120",
         "has_kiosk":"TRUE",
         "name":"31 St & Newtown Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3721",
         "short_name":"6923.2",
         "station_id":3721
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99015725,40.69531728 ]
         },
         "properties": {
         "capacity":30,
         "eightd_has_key_dispenser":"TRUE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"25d256fe-15a7-4d97-ad27-56885e7c0491",
         "has_kiosk":"TRUE",
         "name":"Cadman Plaza E & Johnson St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3723",
         "short_name":"4677.1",
         "station_id":3723
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97906899,40.76674056 ]
         },
         "properties": {
         "capacity":39,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"b94cc90e-9ca2-4471-8371-23be051e0157",
         "has_kiosk":"TRUE",
         "name":"7 Ave & Central Park South",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3724",
         "short_name":"6912.01",
         "station_id":3724
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95840794,40.76876203 ]
         },
         "properties": {
         "capacity":41,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"e36b5913-8e46-4c2a-b9be-73bdf8ee548b",
         "has_kiosk":"TRUE",
         "name":"2 Ave & E 72 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3725",
         "short_name":"6925.09",
         "station_id":3725
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.95960689,40.74336608 ]
         },
         "properties": {
         "capacity":20,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"79399e32-a6c6-4732-8ad4-9f9140a86b21",
         "has_kiosk":"TRUE",
         "name":"Center Blvd & 51 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3726",
         "short_name":"6179.07",
         "station_id":3726
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.94880027,40.71766197 ]
         },
         "properties": {
         "capacity":38,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"3863f086-ae35-4d0e-8c91-2b6e3e5827a1",
         "has_kiosk":"TRUE",
         "name":"Frost St & Meeker Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3727",
         "short_name":"5371.07",
         "station_id":3727
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.99344027,40.69535693 ]
         },
         "properties": {
         "capacity":24,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"78e93937-53d1-4c9b-99ad-0460f908ed2d",
         "has_kiosk":"TRUE",
         "name":"Pierrepont St & Monroe Pl",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3728",
         "short_name":"4718.08",
         "station_id":3728
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.973984,40.730563 ]
         },
         "properties": {
         "capacity":46,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"346621b1-0316-4a89-a364-1364194c2c51",
         "has_kiosk":"TRUE",
         "name":"Avenue C & E 18 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3733",
         "short_name":"5769.04",
         "station_id":3733
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.962658,40.759125 ]
         },
         "properties": {
         "capacity":50,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"2bf9addc-038b-48fe-8794-dde085c5e5dc",
         "has_kiosk":"TRUE",
         "name":"E 58 St &  1 Ave (NW Corner)",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3734",
         "short_name":"6723.1",
         "station_id":3734
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.986274,40.720747 ]
         },
         "properties": {
         "capacity":35,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"9394fb49-583f-4426-8d2f-a2b0ffb584d2",
         "has_kiosk":"TRUE",
         "name":"Stanton St & Norfolk St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3737",
         "short_name":"5445.07",
         "station_id":3737
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.92957486,40.75651273 ]
         },
         "properties": {
         "capacity":27,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"59ad8f95-32a4-43de-b1c3-79c667b2d2df",
         "has_kiosk":"TRUE",
         "name":"36 Ave & 31 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3745",
         "short_name":"6572.08",
         "station_id":3745
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -74.00473036,40.72430832 ]
         },
         "properties": {
         "capacity":48,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"90c35466-db3c-4b0d-993e-6e92883773b4",
         "has_kiosk":"TRUE",
         "name":"6 Ave & Broome St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3746",
         "short_name":"5610.09",
         "station_id":3746
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.9551276,40.77755374 ]
         },
         "properties": {
         "capacity":33,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"57dee83e-5f5b-44ea-b7d0-893a9fe372e6",
         "has_kiosk":"TRUE",
         "name":"E 84 St & 3 Ave",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3747",
         "short_name":"7212.02",
         "station_id":3747
         }
       },
       {
         "type": "Feature",
         "geometry": {
            "type": "Point",
            "coordinates":  [ -73.97880077,40.74757396 ]
         },
         "properties": {
         "capacity":23,
         "eightd_has_key_dispenser":"FALSE",
         "electric_bike_surcharge_waiver":"FALSE",
         "external_id":"93c28953-7e65-436e-9c5a-9d7ca0e3729f",
         "has_kiosk":"TRUE",
         "name":"Lexington Ave & E 36 St",
         "region_id":71,
         "rental_methods":"['KEY', 'CREDITCARD']",
         "rental_url":"http://app.citibikenyc.com/S6Lr/IBV092JufD?station_id=3749",
         "short_name":"6313.1",
         "station_id":3749
         }
       }
     ]
     }
    