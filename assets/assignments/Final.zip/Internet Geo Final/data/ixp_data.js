let dataObj = {
   "type": "FeatureCollection",
   "features": [
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 69.17233,34.52813 ]
    },
    "properties": {
    "FIELD1":0,
    "country":"Afghanistan",
    "total_by_country":1,
    "city":"Kabul",
    "ixpname":"National Internet Exchange",
    "alternatenames":"['NIXA']",
    "prefixes":"{'ipv4': ['103.104.146.0/24']}",
    "sources":"['pdb']",
    "url":"http://www.nixa.af",
    "participants_pch":16,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pdb",
    "region":"South Asia",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 19.81889,41.3275 ]
    },
    "properties": {
    "FIELD1":1,
    "country":"Albania",
    "total_by_country":1,
    "city":"Tirana",
    "ixpname":"Albanian Neutral Internet eXchange",
    "alternatenames":"['ANIX', 'Albanian Neutral Internet eXchange']",
    "prefixes":"{'ipv4': ['185.1.100.0/24'], 'ipv6': ['2001:7f8:bb::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.anix.al",
    "participants_pch":8,
    "peak_pch":"90M",
    "avg_pch":"33M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 13.23432,-8.83682 ]
    },
    "properties": {
    "FIELD1":2,
    "country":"Angola",
    "total_by_country":2,
    "city":"Luanda",
    "ixpname":"ANGONIX",
    "alternatenames":"['Angola Internet Exchange Point']",
    "prefixes":"{'ipv4': ['196.11.234.0/24'], 'ipv6': ['2001:43f8:9d0::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://angonix.net/",
    "participants_pch":21,
    "peak_pch":"13.6G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2015,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 13.23432,-8.83682 ]
    },
    "properties": {
    "FIELD1":3,
    "country":"Angola",
    "total_by_country":2,
    "city":"Luanda",
    "ixpname":"Angola Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['196.223.1.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":21,
    "peak_pch":"1.6G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2006,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -62.27243,-38.71959 ]
    },
    "properties": {
    "FIELD1":4,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Bahia Blanca",
    "ixpname":"CABASE IXP Bahia Blanca",
    "alternatenames":"['CABASE IXP Bah?a Blanca']",
    "prefixes":"{'ipv4': ['200.14.37.0/24'], 'ipv6': ['2001:13c7:6009::/48', '2001:13c7:6009::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.cabase.org.ar/",
    "participants_pch":15,
    "peak_pch":"713M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -71.30822,-41.14557 ]
    },
    "properties": {
    "FIELD1":5,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Bariloche",
    "ixpname":"CABASE IXP Bariloche",
    "alternatenames":"['CABASE IXP Bariloche']",
    "prefixes":"{'ipv4': ['200.115.85.0/24'], 'ipv6': ['2001:13c7:6015::/48']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.cabase.org.ar",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -58.37723,-34.61315 ]
    },
    "properties": {
    "FIELD1":6,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Buenos Aires",
    "ixpname":"CABASE IXP Buenos Aires",
    "alternatenames":"['CABASE IXP Buenos Aires']",
    "prefixes":"{'ipv4': ['200.0.17.0/24'], 'ipv6': ['2001:13c7:6001::/48', '2001:13c7:6001::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.cabase.org.ar/",
    "participants_pch":132,
    "peak_pch":"9.19G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":1998,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -64.18105,-31.4135 ]
    },
    "properties": {
    "FIELD1":7,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Cordoba",
    "ixpname":"CABASE IXP Cordoba",
    "alternatenames":"['CABASE IXP C?rdoba']",
    "prefixes":"{'ipv4': ['200.14.75.0/24'], 'ipv6': ['2001:13c7:600e::/48', '2001:13c7:600e::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"",
    "participants_pch":30,
    "peak_pch":"175M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -56.69327,-36.61122 ]
    },
    "properties": {
    "FIELD1":8,
    "country":"Argentina",
    "total_by_country":29,
    "city":"De La Costa",
    "ixpname":"CABASE IXP De la Costa",
    "alternatenames":"['CABASE-DLC', 'CABASE IXP De La Costa']",
    "prefixes":"{'ipv4': ['200.14.39.0/24'], 'ipv6': ['2001:13c7:600c::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.cabase.org.ar/",
    "participants_pch":10,
    "peak_pch":"919M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -56.68883,-36.57531 ]
    },
    "properties": {
    "FIELD1":9,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Mar del Tuyu",
    "ixpname":"CABASE IXP De la Costa - Mar del Tuyu",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['200.14.39.0/24'], 'ipv6': ['2001:13c7:600c::/48']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":10,
    "peak_pch":"919M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -65.29712,-24.19457 ]
    },
    "properties": {
    "FIELD1":10,
    "country":"Argentina",
    "total_by_country":29,
    "city":"San Salvador de Jujuy",
    "ixpname":"CABASE IXP Jujuy",
    "alternatenames":"['CABASE IXP Jujuy', 'CABASE-JUJ']",
    "prefixes":"{'ipv4': ['138.204.250.0/24'], 'ipv6': ['2001:13c7:6022::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.cabase.org.ar",
    "participants_pch":7,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -60.94332,-34.58382 ]
    },
    "properties": {
    "FIELD1":11,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Junin",
    "ixpname":"CABASE IXP Junin",
    "alternatenames":"['CABASE IXP Junin', 'CABASE-JUN']",
    "prefixes":"{'ipv4': ['200.115.80.0/24'], 'ipv6': ['2001:13c7:6010::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.cabase.org.ar",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -57.95453,-34.92145 ]
    },
    "properties": {
    "FIELD1":12,
    "country":"Argentina",
    "total_by_country":29,
    "city":"La Plata",
    "ixpname":"CABASE IXP La Plata",
    "alternatenames":"['CABASE IXP La Plata']",
    "prefixes":"{'ipv4': ['200.115.81.0/24'], 'ipv6': ['2001:13c7:6011::/48', '2001:13c7:6011::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.cabase.org.ar",
    "participants_pch":17,
    "peak_pch":"85M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -57.5562,-38.00042 ]
    },
    "properties": {
    "FIELD1":13,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Mar del Plata",
    "ixpname":"CABASE IXP Mar del Plata",
    "alternatenames":"['CABASE IXP Mar Del Plata', 'CABASE IXP Mar del Plata']",
    "prefixes":"{'ipv4': ['200.115.82.0/24'], 'ipv6': ['2001:13c7:6012::/48', '2001:13c7:6012::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.cabase.org.ar/",
    "participants_pch":16,
    "peak_pch":"968M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -68.82717,-32.89084 ]
    },
    "properties": {
    "FIELD1":14,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Mendoza",
    "ixpname":"CABASE IXP Mendoza",
    "alternatenames":"['CABASE IXP Mendoza']",
    "prefixes":"{'ipv4': ['200.14.38.0/24'], 'ipv6': ['2001:13c7:600b::/48', '2001:13c7:600b::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.cabase.org.ar/",
    "participants_pch":21,
    "peak_pch":"2.16G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -68.0591,-38.95161 ]
    },
    "properties": {
    "FIELD1":15,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Neuquen",
    "ixpname":"CABASE IXP Neuquen",
    "alternatenames":"['CABASE IXP Neuqu?n']",
    "prefixes":"{'ipv4': ['200.0.19.0/24'], 'ipv6': ['2001:13c7:6007::/48', '2001:13c7:6007::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.cabase.org.ar/",
    "participants_pch":25,
    "peak_pch":"2.21G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -58.9142,-34.45866 ]
    },
    "properties": {
    "FIELD1":16,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Pilar",
    "ixpname":"CABASE IXP Norte de Gran Buenos Aires",
    "alternatenames":"['CABASE-NGB - IX Argentina (Pilar)', 'CABASE-NGB']",
    "prefixes":"{'ipv4': ['138.204.247.0/24'], 'ipv6': ['2001:13c7:6019::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.cabase.org.ar",
    "participants_pch":13,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -58.37723,-34.61315 ]
    },
    "properties": {
    "FIELD1":17,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Buenos Aires",
    "ixpname":"CABASE IXP Oeste de Gran Buenos Aires",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":7,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -60.57357,-33.88995 ]
    },
    "properties": {
    "FIELD1":18,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Pergamino",
    "ixpname":"CABASE IXP Pergamino",
    "alternatenames":"['CABASE IXP Pergamino', 'CABASE-PER']",
    "prefixes":"{'ipv4': ['138.204.245.0/24'], 'ipv6': ['2001:13c7:6017::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.cabase.org.ar",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -55.89608,-27.36708 ]
    },
    "properties": {
    "FIELD1":19,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Posadas",
    "ixpname":"CABASE IXP Posadas",
    "alternatenames":"['CABASE IXP Posadas']",
    "prefixes":"{'ipv4': ['200.115.83.0/24'], 'ipv6': ['2001:13c7:6013::/48', '2001:13c7:6013::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.cabase.org.ar/",
    "participants_pch":14,
    "peak_pch":"627M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -65.03851,-42.7692 ]
    },
    "properties": {
    "FIELD1":20,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Puerto Madryn",
    "ixpname":"CABASE IXP Puerto Madryn",
    "alternatenames":"['CABASE-PMY', 'CABASE IXP Puerto Madryn']",
    "prefixes":"{'ipv4': ['200.115.84.0/24'], 'ipv6': ['2001:13c7:6014::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.cabase.org.ar/",
    "participants_pch":9,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -69.21813,-51.62261 ]
    },
    "properties": {
    "FIELD1":21,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Rio Gallegos",
    "ixpname":"CABASE IXP RIO GALLEGOS",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -58.98389,-27.46056 ]
    },
    "properties": {
    "FIELD1":22,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Resistencia",
    "ixpname":"CABASE IXP Resistencia",
    "alternatenames":"['CABASE IXP Resistencia']",
    "prefixes":"{'ipv4': ['138.204.253.0/24'], 'ipv6': ['2001:13c7:601f::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.cabase.org.ar",
    "participants_pch":12,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -60.63932,-32.94682 ]
    },
    "properties": {
    "FIELD1":23,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Rosario",
    "ixpname":"CABASE IXP Rosario",
    "alternatenames":"['CABASE IXP Rosario']",
    "prefixes":"{'ipv4': ['200.13.83.0/24'], 'ipv6': ['2001:13c7:6008::/48', '2001:13c7:6008::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.cabase.org.ar/",
    "participants_pch":21,
    "peak_pch":"2.29G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -58.37723,-34.61315 ]
    },
    "properties": {
    "FIELD1":24,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Buenos Aires",
    "ixpname":"CABASE IXP Ruteo Central",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -65.41166,-24.7859 ]
    },
    "properties": {
    "FIELD1":25,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Salta",
    "ixpname":"CABASE IXP SALTA",
    "alternatenames":"['CABASE-SLA', 'CABASE IXP Salta']",
    "prefixes":"{'ipv4': ['138.204.249.0/24'], 'ipv6': ['2001:13c7:6021::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.cabase.org.ar",
    "participants_pch":10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -68.53639,-31.5375 ]
    },
    "properties": {
    "FIELD1":26,
    "country":"Argentina",
    "total_by_country":29,
    "city":"San Juan",
    "ixpname":"CABASE IXP SAN JUAN",
    "alternatenames":"['CABASE-UAQ', 'CABASE IXP San Juan']",
    "prefixes":"{'ipv4': ['138.204.255.0/24'], 'ipv6': ['2801:168:1::/48']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.cabase.org.ar/",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -60.43876,-26.78522 ]
    },
    "properties": {
    "FIELD1":27,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Saenz Pena",
    "ixpname":"CABASE IXP Saenz Pena",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":13,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"Latin America & Caribbean",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -66.33563,-33.29501 ]
    },
    "properties": {
    "FIELD1":28,
    "country":"Argentina",
    "total_by_country":29,
    "city":"San Luis",
    "ixpname":"CABASE IXP San Luis",
    "alternatenames":"['CABASE IXP San Luis', 'CABASE-SLU']",
    "prefixes":"{'ipv4': ['138.204.244.0/24'], 'ipv6': ['2001:13c7:6016::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.cabase.org.ar",
    "participants_pch":7,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -60.70868,-31.64881 ]
    },
    "properties": {
    "FIELD1":29,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Santa Fe",
    "ixpname":"CABASE IXP Santa Fe",
    "alternatenames":"['CABASE IXP Santa Fe']",
    "prefixes":"{'ipv4': ['200.14.74.0/24'], 'ipv6': ['2001:13c7:600d::/48', '2001:13c7:600d::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.cabase.org.ar/",
    "participants_pch":7,
    "peak_pch":"122M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -59.13316,-37.32167 ]
    },
    "properties": {
    "FIELD1":30,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Tandil",
    "ixpname":"CABASE IXP TANDIL",
    "alternatenames":"['CABASE IXP Tandil']",
    "prefixes":"{'ipv4': ['138.204.251.0/24'], 'ipv6': ['2001:13c7:601d::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.cabase.org.ar/",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -65.2226,-26.82414 ]
    },
    "properties": {
    "FIELD1":31,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Tucuman",
    "ixpname":"CABASE IXP Tucuman",
    "alternatenames":"['CABASE IXP Tucuman', 'CABASE-TUC']",
    "prefixes":"{'ipv4': ['138.204.246.0/24'], 'ipv6': ['2001:13c7:6018::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.cabase.org.ar",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -62.99668,-40.81345 ]
    },
    "properties": {
    "FIELD1":32,
    "country":"Argentina",
    "total_by_country":29,
    "city":"Viedma",
    "ixpname":"CABASE IXP VIEDMA",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 44.51361,40.18111 ]
    },
    "properties": {
    "FIELD1":33,
    "country":"Armenia",
    "total_by_country":1,
    "city":"Yerevan",
    "ixpname":"Armenian Internet Traffic Exchange",
    "alternatenames":"['Armenian Internet Exchange']",
    "prefixes":"{'ipv4': ['91.218.7.0/25', '91.218.4.0/22'], 'ipv6': ['2001:7f8:94::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://armix.am",
    "participants_pch":8,
    "peak_pch":"20G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 149.12807,-35.28346 ]
    },
    "properties": {
    "FIELD1":34,
    "country":"Australia",
    "total_by_country":31,
    "city":"Canberra",
    "ixpname":"ACTIX",
    "alternatenames":"['ACT Internet Exchange']",
    "prefixes":"{'ipv4': ['218.100.59.0/24'], 'ipv6': ['2001:de8:9::/64']}",
    "sources":"['pdb']",
    "url":"",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 144.96332,-37.814 ]
    },
    "properties": {
    "FIELD1":35,
    "country":"Australia",
    "total_by_country":31,
    "city":"Melbourne",
    "ixpname":"AUSIX.net",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 138.59863,-34.92866 ]
    },
    "properties": {
    "FIELD1":36,
    "country":"Australia",
    "total_by_country":31,
    "city":"Adelaide",
    "ixpname":"EdgeIX - Adelaide",
    "alternatenames":"['JIX - Adelaide']",
    "prefixes":"{'ipv4': ['103.136.101.0/25'], 'ipv6': ['2001:df0:680:2::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.edgeix.net",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 130.84185,-12.46113 ]
    },
    "properties": {
    "FIELD1":37,
    "country":"Australia",
    "total_by_country":31,
    "city":"Darwin",
    "ixpname":"EdgeIX - Darwin",
    "alternatenames":"['JIX - Darwin']",
    "prefixes":"{'ipv4': ['103.136.100.0/25'], 'ipv6': ['2001:df0:680::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.edgeix.net",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 147.32941,-42.87936 ]
    },
    "properties": {
    "FIELD1":38,
    "country":"Australia",
    "total_by_country":31,
    "city":"Hobart",
    "ixpname":"EdgeIX - Hobart",
    "alternatenames":"['JIX - Hobart']",
    "prefixes":"{'ipv4': ['103.136.100.128/25'], 'ipv6': ['2001:df0:680:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.edgeix.net",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 144.96332,-37.814 ]
    },
    "properties": {
    "FIELD1":39,
    "country":"Australia",
    "total_by_country":31,
    "city":"Melbourne",
    "ixpname":"EdgeIX - Melbourne",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 115.8614,-31.95224 ]
    },
    "properties": {
    "FIELD1":40,
    "country":"Australia",
    "total_by_country":31,
    "city":"Perth",
    "ixpname":"EdgeIX - Perth",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['103.136.102.0/24'], 'ipv6': ['2001:df0:680:3::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.edgeix.net",
    "participants_pch":13,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 151.20732,-33.86785 ]
    },
    "properties": {
    "FIELD1":41,
    "country":"Australia",
    "total_by_country":31,
    "city":"Sydney",
    "ixpname":"EdgeIX - Sydney",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 144.96332,-37.814 ]
    },
    "properties": {
    "FIELD1":42,
    "country":"Australia",
    "total_by_country":31,
    "city":"Melbourne",
    "ixpname":"Equinix Melbourne",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['183.177.61.0/24'], 'ipv6': ['2001:de8:6:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.equinix.com",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 115.8614,-31.95224 ]
    },
    "properties": {
    "FIELD1":43,
    "country":"Australia",
    "total_by_country":31,
    "city":"Perth",
    "ixpname":"Equinix Perth",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['101.97.43.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 151.20732,-33.86785 ]
    },
    "properties": {
    "FIELD1":44,
    "country":"Australia",
    "total_by_country":31,
    "city":"Sydney",
    "ixpname":"Equinix Sydney",
    "alternatenames":"['Equinix Sydney Exchange']",
    "prefixes":"{'ipv4': ['45.127.172.0/22'], 'ipv6': ['2001:de8:6::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.equinix.com",
    "participants_pch":177,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 149.12807,-35.28346 ]
    },
    "properties": {
    "FIELD1":45,
    "country":"Australia",
    "total_by_country":31,
    "city":"Canberra",
    "ixpname":"IX Australia ACT",
    "alternatenames":"['Australian Capital Territory']",
    "prefixes":"{'ipv4': ['218.100.54.128/25'], 'ipv6': ['2001:de8:9::/48', '2001:7fa:11:5::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.ix.asn.au",
    "participants_pch":7,
    "peak_pch":"1G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 153.02809,-27.46794 ]
    },
    "properties": {
    "FIELD1":46,
    "country":"Australia",
    "total_by_country":31,
    "city":"Brisbane",
    "ixpname":"IX Australia QLD",
    "alternatenames":"['Queensland Internet Exchange (QLD-IX)']",
    "prefixes":"{'ipv4': ['218.100.76.0/24'], 'ipv6': ['2001:7fa:11:2::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.ix.asn.au",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 153.02809,-27.46794 ]
    },
    "properties": {
    "FIELD1":47,
    "country":"Australia",
    "total_by_country":31,
    "city":"Brisbane",
    "ixpname":"Megaport IX Brisbane",
    "alternatenames":"['Megaport MegaIX Brisbane', 'MegaIX Brisbane']",
    "prefixes":"{'ipv4': ['103.26.70.0/24'], 'ipv6': ['2001:dea:0:20::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://megaport.com",
    "participants_pch":87,
    "peak_pch":"14G",
    "avg_pch":"8.59G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 144.96332,-37.814 ]
    },
    "properties": {
    "FIELD1":48,
    "country":"Australia",
    "total_by_country":31,
    "city":"Melbourne",
    "ixpname":"Megaport IX Melbourne",
    "alternatenames":"['MegaIX Melbourne', 'Megaport MegaIX Melbourne']",
    "prefixes":"{'ipv4': ['103.26.71.0/24'], 'ipv6': ['2001:dea:0:30::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://megaport.com",
    "participants_pch":104,
    "peak_pch":"36G",
    "avg_pch":"23.3G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 115.8614,-31.95224 ]
    },
    "properties": {
    "FIELD1":49,
    "country":"Australia",
    "total_by_country":31,
    "city":"Perth",
    "ixpname":"Megaport IX Perth",
    "alternatenames":"['Megaport MegaIX Perth', 'MegaIX Perth']",
    "prefixes":"{'ipv4': ['202.12.243.0/24'], 'ipv6': ['2001:dea:0:50::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://megaport.com",
    "participants_pch":33,
    "peak_pch":"11G",
    "avg_pch":"6G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 151.20732,-33.86785 ]
    },
    "properties": {
    "FIELD1":50,
    "country":"Australia",
    "total_by_country":31,
    "city":"Sydney",
    "ixpname":"Megaport IX Sydney",
    "alternatenames":"['Megaport MegaIX Sydney', 'MegaIX Sydney']",
    "prefixes":"{'ipv4': ['103.26.68.0/23'], 'ipv6': ['2001:dea:0:10::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://megaport.com",
    "participants_pch":217,
    "peak_pch":"148G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 151.20732,-33.86785 ]
    },
    "properties": {
    "FIELD1":51,
    "country":"Australia",
    "total_by_country":31,
    "city":"Sydney",
    "ixpname":"New South Wales IX",
    "alternatenames":"['IX Australia NSW', 'New South Wales Internet Exchange (NSW-IX)']",
    "prefixes":"{'ipv4': ['218.100.52.0/23'], 'ipv6': ['2001:7fa:11:4::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.ix.asn.au",
    "participants_pch":190,
    "peak_pch":"275G",
    "avg_pch":"70.3G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 138.59863,-34.92866 ]
    },
    "properties": {
    "FIELD1":52,
    "country":"Australia",
    "total_by_country":31,
    "city":"Adelaide",
    "ixpname":"PIPE Networks Adelaide",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['218.100.3.0/24', '210.100.3.0/24'], 'ipv6': ['2001:7fa:c::/48', '2001:7fa:c::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"",
    "participants_pch":13,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 153.02809,-27.46794 ]
    },
    "properties": {
    "FIELD1":53,
    "country":"Australia",
    "total_by_country":31,
    "city":"Brisbane",
    "ixpname":"PIPE Networks Brisbane",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['218.100.0.0/24'], 'ipv6': ['2001:7fa:9::/128', '2001:7fa:9::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.pipenetworks.com",
    "participants_pch":36,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 149.12807,-35.28346 ]
    },
    "properties": {
    "FIELD1":54,
    "country":"Australia",
    "total_by_country":31,
    "city":"Canberra",
    "ixpname":"PIPE Networks Canberra",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['218.100.19.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.pipenetworks.com",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 147.32941,-42.87936 ]
    },
    "properties": {
    "FIELD1":55,
    "country":"Australia",
    "total_by_country":31,
    "city":"Hobart",
    "ixpname":"PIPE Networks Hobart",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['218.100.12.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.pipenetworks.com",
    "participants_pch":1,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 144.96332,-37.814 ]
    },
    "properties": {
    "FIELD1":56,
    "country":"Australia",
    "total_by_country":31,
    "city":"Melbourne",
    "ixpname":"PIPE Networks Melbourne",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['218.100.13.0/24'], 'ipv6': ['2001:7fa:e::/128', '2001:7fa:e::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.pipenetworks.com",
    "participants_pch":32,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 151.20732,-33.86785 ]
    },
    "properties": {
    "FIELD1":57,
    "country":"Australia",
    "total_by_country":31,
    "city":"Sydney",
    "ixpname":"PIPE Networks Sydney",
    "alternatenames":"['Pipe Networks MLPA Sydney']",
    "prefixes":"{'ipv4': ['218.100.2.0/24'], 'ipv6': ['2001:7fa:b::/128', '2001:7fa:b::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.pipenetworks.com",
    "participants_pch":92,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 151.20732,-33.86785 ]
    },
    "properties": {
    "FIELD1":58,
    "country":"Australia",
    "total_by_country":31,
    "city":"Sydney",
    "ixpname":"Pacific-IX",
    "alternatenames":"['Pacific IX', 'PacificIX']",
    "prefixes":"{'ipv4': ['218.100.80.0/22', '218.100.81.0/24'], 'ipv6': ['2001:de8:17::/48', '2001:de8:17:0:6401::/96']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.vocus.com.au/pacificix/",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 153.02809,-27.46794 ]
    },
    "properties": {
    "FIELD1":59,
    "country":"Australia",
    "total_by_country":31,
    "city":"Brisbane",
    "ixpname":"Queensland Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['218.100.78.0/24'], 'ipv6': ['2001:7fa:11:2::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":55,
    "peak_pch":"56G",
    "avg_pch":"17.3G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 138.59863,-34.92866 ]
    },
    "properties": {
    "FIELD1":60,
    "country":"Australia",
    "total_by_country":31,
    "city":"Adelaide",
    "ixpname":"South Australia Internet Exchange",
    "alternatenames":"['IX Australia SA', 'South Australian Internet Exchange (SA-IX)']",
    "prefixes":"{'ipv4': ['218.100.54.0/25'], 'ipv6': ['2001:7fa:11:3::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.ix.asn.au",
    "participants_pch":21,
    "peak_pch":"23.5G",
    "avg_pch":"5.91G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 149.12807,-35.28346 ]
    },
    "properties": {
    "FIELD1":61,
    "country":"Australia",
    "total_by_country":31,
    "city":"Canberra",
    "ixpname":"TransACT IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['218.100.50.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.transact.com.au",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 144.96332,-37.814 ]
    },
    "properties": {
    "FIELD1":62,
    "country":"Australia",
    "total_by_country":31,
    "city":"Melbourne",
    "ixpname":"Victoria Internet Exchange",
    "alternatenames":"['IX Australia VIC', 'Victorian Internet Exchange (VIC-IX)']",
    "prefixes":"{'ipv4': ['218.100.78.0/24'], 'ipv6': ['2001:7fa:11:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.waia.asn.au",
    "participants_pch":66,
    "peak_pch":"125G",
    "avg_pch":"51.4G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 115.8614,-31.95224 ]
    },
    "properties": {
    "FIELD1":63,
    "country":"Australia",
    "total_by_country":31,
    "city":"Perth",
    "ixpname":"Western Australian Internet Association",
    "alternatenames":"['West Australian Internet Exchange (WAIX)', 'IX Australia WA']",
    "prefixes":"{'ipv4': ['198.32.212.0/24'], 'ipv6': ['2001:7fa:11::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.ix.asn.au",
    "participants_pch":81,
    "peak_pch":"58.6G",
    "avg_pch":"29.4G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 153.2773,-28.81354 ]
    },
    "properties": {
    "FIELD1":64,
    "country":"Australia",
    "total_by_country":31,
    "city":"Lismore",
    "ixpname":"lismore internet exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 14.30528,46.62472 ]
    },
    "properties": {
    "FIELD1":65,
    "country":"Austria",
    "total_by_country":6,
    "city":"Klagenfurt",
    "ixpname":"Alpes Adria Internet Exchange",
    "alternatenames":"['Alpes Adria Internet eXchange', 'AAIX']",
    "prefixes":"{'ipv4': ['193.37.144.0/24'], 'ipv6': ['2001:7f8:4a::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"",
    "participants_pch":8,
    "peak_pch":"150M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 16.37208,48.20849 ]
    },
    "properties": {
    "FIELD1":66,
    "country":"Austria",
    "total_by_country":6,
    "city":"Vienna",
    "ixpname":"Community-IX Vienna",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.147.0/24'], 'ipv6': ['2001:7f8:ca::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.community-ix.at/docs/about/",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 15.45,47.06667 ]
    },
    "properties": {
    "FIELD1":67,
    "country":"Austria",
    "total_by_country":6,
    "city":"Graz",
    "ixpname":"Grazer Internet Exchange",
    "alternatenames":"['GraX', 'Grazer Internet eXchange']",
    "prefixes":"{'ipv4': ['193.105.214.0/24'], 'ipv6': ['2001:7f8:71::/128']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.grax.at/",
    "participants_pch":14,
    "peak_pch":"36.4M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 13.04399,47.79941 ]
    },
    "properties": {
    "FIELD1":68,
    "country":"Austria",
    "total_by_country":6,
    "city":"Salzburg",
    "ixpname":"Salzburg Internet eXchange",
    "alternatenames":"['SAIX', 'Salzburg Internet eXchange - SAIX']",
    "prefixes":"{'ipv4': ['185.1.43.0/24'], 'ipv6': ['2001:7f8:11::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.saix.at/",
    "participants_pch":31,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 11.39454,47.26266 ]
    },
    "properties": {
    "FIELD1":69,
    "country":"Austria",
    "total_by_country":6,
    "city":"Innsbruck",
    "ixpname":"Tirol-IX",
    "alternatenames":"['Tirol-IX Internet Exchange']",
    "prefixes":"{'ipv4': ['185.1.31.0/24'], 'ipv6': ['2001:7f8:8d::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://tirol-ix.at/",
    "participants_pch":17,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 16.37208,48.20849 ]
    },
    "properties": {
    "FIELD1":70,
    "country":"Austria",
    "total_by_country":6,
    "city":"Vienna",
    "ixpname":"Vienna Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['193.203.0.0/24'], 'ipv6': ['2001:7f8:30::/64']}",
    "sources":"['he']",
    "url":"http://www.vix.at",
    "participants_pch":131,
    "peak_pch":"631G",
    "avg_pch":"382G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 90.40744,23.7104 ]
    },
    "properties": {
    "FIELD1":71,
    "country":"Bangladesh",
    "total_by_country":4,
    "city":"Dhaka",
    "ixpname":"AIX-BD",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"South Asia",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 90.40744,23.7104 ]
    },
    "properties": {
    "FIELD1":72,
    "country":"Bangladesh",
    "total_by_country":4,
    "city":"Dhaka",
    "ixpname":"Bangladesh Internet Exchange",
    "alternatenames":"['BDIX', 'Bangladesh Internet Exchange ( Trust )']",
    "prefixes":"{'ipv4': ['198.32.167.0/24'], 'ipv6': ['2001:de8:b:2900::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.bdix.net",
    "participants_pch":79,
    "peak_pch":"49G",
    "avg_pch":"28G",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2004,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 90.40744,23.7104 ]
    },
    "properties": {
    "FIELD1":73,
    "country":"Bangladesh",
    "total_by_country":4,
    "city":"Dhaka",
    "ixpname":"NOVOCOM NIX",
    "alternatenames":"['NOVOCOM NIX']",
    "prefixes":"{'ipv4': ['163.53.143.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.novonix.net.bd",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"South Asia",
    "year":2014,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 91.1,22.86667 ]
    },
    "properties": {
    "FIELD1":74,
    "country":"Bangladesh",
    "total_by_country":4,
    "city":"Noakhali",
    "ixpname":"Noakhali Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"South Asia",
    "year":2019,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 27.56667,53.9 ]
    },
    "properties": {
    "FIELD1":75,
    "country":"Belarus",
    "total_by_country":1,
    "city":"Minsk",
    "ixpname":"Belarus National Internet Exchange Point",
    "alternatenames":"['Belarusian Internet Exchange']",
    "prefixes":"{'ipv4': ['195.137.180.0/24'], 'ipv6': ['2001:7f8:8b::/64']}",
    "sources":"['pdb']",
    "url":"http://www.ntec.by",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2020,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 4.34878,50.85045 ]
    },
    "properties": {
    "FIELD1":76,
    "country":"Belgium",
    "total_by_country":2,
    "city":"Brussels",
    "ixpname":"Belgian National Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['194.53.172.0/24'], 'ipv6': ['2001:7f8:26::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":61,
    "peak_pch":"240G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1995,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 4.34878,50.85045 ]
    },
    "properties": {
    "FIELD1":77,
    "country":"Belgium",
    "total_by_country":2,
    "city":"Brussels",
    "ixpname":"Belgium Internet Exchange",
    "alternatenames":"['BelgiumIX']",
    "prefixes":"{'ipv4': ['185.1.127.0/24'], 'ipv6': ['2001:7f8:d2::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://belgiumix.net/",
    "participants_pch":10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -88.19756,17.49952 ]
    },
    "properties": {
    "FIELD1":78,
    "country":"Belize",
    "total_by_country":1,
    "city":"Belize City",
    "ixpname":"Belize Internet Exchange Point",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['10.31.2.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":9,
    "peak_pch":"44.4M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 2.41833,6.36536 ]
    },
    "properties": {
    "FIELD1":79,
    "country":"Benin",
    "total_by_country":1,
    "city":"Cotonou",
    "ixpname":"Benin IX",
    "alternatenames":"['Benin IX', 'BENIN-IX']",
    "prefixes":"{'ipv4': ['196.223.40.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.benin-ix.org.bj",
    "participants_pch":6,
    "peak_pch":"826M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2013,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 89.64191,27.46609 ]
    },
    "properties": {
    "FIELD1":80,
    "country":"Bhutan",
    "total_by_country":1,
    "city":"Thimphu",
    "ixpname":"Bhutan Internet Exchange",
    "alternatenames":"['btIX']",
    "prefixes":"{'ipv4': ['103.129.62.0/26'], 'ipv6': ['2001:dea:4000::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.btix.bt",
    "participants_pch":7,
    "peak_pch":"752M",
    "avg_pch":"337M",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2017,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -68.15,-16.5 ]
    },
    "properties": {
    "FIELD1":81,
    "country":"Bolivia",
    "total_by_country":2,
    "city":"La Paz",
    "ixpname":"IXP MegaLink",
    "alternatenames":"['MLIXP', 'MegaLink-IXP']",
    "prefixes":"{'ipv4': ['200.75.174.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"https://ixp.MegaLink.com",
    "participants_pch":6,
    "peak_pch":"1M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2013,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -68.15,-16.5 ]
    },
    "properties": {
    "FIELD1":82,
    "country":"Bolivia",
    "total_by_country":2,
    "city":"La Paz",
    "ixpname":"Punto de Intercambio de Trafico de Bolivia",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['179.0.30.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":6,
    "peak_pch":"4G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2013,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 25.90859,-24.65451 ]
    },
    "properties": {
    "FIELD1":83,
    "country":"Botswana",
    "total_by_country":1,
    "city":"Gaborone",
    "ixpname":"Botswana Internet Exchange",
    "alternatenames":"['BINX']",
    "prefixes":"{'ipv4': ['192.168.179.0/24'], 'ipv6': []}",
    "sources":"['pch', 'he']",
    "url":"http://www.binx.org.bw/",
    "participants_pch":14,
    "peak_pch":"1G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2005,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -46.63611,-23.5475 ]
    },
    "properties": {
    "FIELD1":84,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Sao Paulo",
    "ixpname":"Equinix Sao Paulo",
    "alternatenames":"['Equinix Sao Paulo Exchange']",
    "prefixes":"{'ipv4': ['198.32.122.0/24', '64.191.232.0/22'], 'ipv6': ['2001:478:122::/64', '2001:504:0:7::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.equinix.com.br",
    "participants_pch":50,
    "peak_pch":"140G",
    "avg_pch":"100G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":1998,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -49.06611,-26.91944 ]
    },
    "properties": {
    "FIELD1":85,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Blumenau",
    "ixpname":"FURB Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['200.135.14.128/26'], 'ipv6': ['fdef:44ad:f2b0:7f59::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":3,
    "peak_pch":"1.2G",
    "avg_pch":"700M",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -48.32766,-10.16745 ]
    },
    "properties": {
    "FIELD1":86,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Palmas",
    "ixpname":"IX Palmas",
    "alternatenames":"['IX Palmas Microtel']",
    "prefixes":"{'ipv4': ['200.33.115.128/26', '200.33.115.0/25'], 'ipv6': ['2801:80:19c0:8000::/64', '2801:80:19c0::/52']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.microtel.net.br/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Latin America & Caribbean",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -43.18223,-22.90642 ]
    },
    "properties": {
    "FIELD1":87,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Rio de Janeiro",
    "ixpname":"LNCC",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Latin America & Caribbean",
    "year":1988,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -47.89083,-22.0175 ]
    },
    "properties": {
    "FIELD1":88,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Sao Carlos",
    "ixpname":"Ponto de Troca de Trafego Metro Sao Paulo",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['187.16.200.0/24'], 'ipv6': ['2001:12f8:0:23::/64']}",
    "sources":"['he']",
    "url":"http://ptt.br/",
    "participants_pch":1724,
    "peak_pch":"7.44T",
    "avg_pch":"4.97T",
    "status_pch":"active",
    "only_in":"caida",
    "region":"Latin America & Caribbean",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -47.33139,-22.73917 ]
    },
    "properties": {
    "FIELD1":89,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Americana",
    "ixpname":"Ponto de Troca de Trafego do Americana",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Latin America & Caribbean",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -37.07167,-10.91111 ]
    },
    "properties": {
    "FIELD1":90,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Aracaju",
    "ixpname":"Ponto de Troca de Trafego do Aracaju",
    "alternatenames":"['IX.br (PTT.br) Aracaju']",
    "prefixes":"{'ipv4': ['200.219.130.0/24'], 'ipv6': ['2001:12f8:0:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br/",
    "participants_pch":27,
    "peak_pch":"260M",
    "avg_pch":"154M",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -48.50444,-1.45583 ]
    },
    "properties": {
    "FIELD1":91,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Belem",
    "ixpname":"Ponto de Troca de Trafego do Belem",
    "alternatenames":"['IX.br (PTT.br) Bel?m', 'PTT Bel?m']",
    "prefixes":"{'ipv4': ['187.16.195.0/24'], 'ipv6': ['2001:12f8:0:18::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br",
    "participants_pch":31,
    "peak_pch":"7.4G",
    "avg_pch":"5.4G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -43.93778,-19.92083 ]
    },
    "properties": {
    "FIELD1":92,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Belo Horizonte",
    "ixpname":"Ponto de Troca de Trafego do Belo Horizonte",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['he']",
    "url":"http://ix.br",
    "participants_pch":123,
    "peak_pch":"17.4G",
    "avg_pch":"11.4G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -47.92972,-15.77972 ]
    },
    "properties": {
    "FIELD1":93,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Brasilia",
    "ixpname":"Ponto de Troca de Trafego do Brasilia",
    "alternatenames":"['PTT Bras?lia', 'IX.br (PTT.br) Bras?lia']",
    "prefixes":"{'ipv4': ['200.192.110.0/24'], 'ipv6': ['2001:12f8:0:13::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br",
    "participants_pch":62,
    "peak_pch":"40G",
    "avg_pch":"21.5G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -35.88111,-7.23056 ]
    },
    "properties": {
    "FIELD1":94,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Campina Grande",
    "ixpname":"Ponto de Troca de Trafego do Campina Grande",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['he']",
    "url":"http://ix.br",
    "participants_pch":71,
    "peak_pch":"17.8G",
    "avg_pch":"11.1G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -47.06083,-22.90556 ]
    },
    "properties": {
    "FIELD1":95,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Campinas",
    "ixpname":"Ponto de Troca de Trafego do Campinas",
    "alternatenames":"['IX.br (PTT.br) Campinas']",
    "prefixes":"{'ipv4': ['200.192.108.0/24'], 'ipv6': ['2001:12f8:0:11::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://ix.br",
    "participants_pch":48,
    "peak_pch":"22.1G",
    "avg_pch":"14.2G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -51.17944,-29.16806 ]
    },
    "properties": {
    "FIELD1":96,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Caxias do Sul",
    "ixpname":"Ponto de Troca de Trafego do Caxias do Sul",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['he']",
    "url":"http://ix.br",
    "participants_pch":6,
    "peak_pch":"465M",
    "avg_pch":"276M",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -56.09667,-15.59611 ]
    },
    "properties": {
    "FIELD1":97,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Cuiaba",
    "ixpname":"Ponto de Troca de Trafego do Cuiaba",
    "alternatenames":"['PTT Cuiab?', 'IX.br (PTT.br) Cuiab?']",
    "prefixes":"{'ipv4': ['187.16.203.0/24'], 'ipv6': ['2001:12f8:0:26::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br",
    "participants_pch":17,
    "peak_pch":"500M",
    "avg_pch":"210M",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -49.27306,-25.42778 ]
    },
    "properties": {
    "FIELD1":98,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Curitiba",
    "ixpname":"Ponto de Troca de Trafego do Curitiba",
    "alternatenames":"['IX.br (PTT.br) Curitiba']",
    "prefixes":"{'ipv4': ['200.219.140.0/24'], 'ipv6': ['2001:12f8:0:4::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://ix.br",
    "participants_pch":103,
    "peak_pch":"161G",
    "avg_pch":"101G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -48.54917,-27.59667 ]
    },
    "properties": {
    "FIELD1":99,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Florianopolis",
    "ixpname":"Ponto de Troca de Trafego do Florianopolis",
    "alternatenames":"['PTT Florian?polis', 'IX.br (PTT.br) Florian?polis']",
    "prefixes":"{'ipv4': ['200.219.141.0/24'], 'ipv6': ['2001:12f8:0:5::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br",
    "participants_pch":45,
    "peak_pch":"6G",
    "avg_pch":"4.4G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -38.54306,-3.71722 ]
    },
    "properties": {
    "FIELD1":100,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Fortaleza",
    "ixpname":"Ponto de Troca de Trafego do Fortaleza",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['he']",
    "url":"http://ix.br",
    "participants_pch":181,
    "peak_pch":"560G",
    "avg_pch":"358G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -54.58806,-25.54778 ]
    },
    "properties": {
    "FIELD1":101,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Foz do Iguacu",
    "ixpname":"Ponto de Troca de Trafego do Foz do Iguacu",
    "alternatenames":"['PTT Foz do Igua?u', 'IX.br (PTT.br) Foz do Igua?u']",
    "prefixes":"{'ipv4': ['187.16.204.0/24'], 'ipv6': ['2001:12f8:0:27::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br/",
    "participants_pch":15,
    "peak_pch":"3.1G",
    "avg_pch":"1.9G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -49.25389,-16.67861 ]
    },
    "properties": {
    "FIELD1":102,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Goiania",
    "ixpname":"Ponto de Troca de Trafego do Goiania",
    "alternatenames":"['IX.br (PTT.br) Goi?nia', 'PTT Goi?nia']",
    "prefixes":"{'ipv4': ['200.192.111.0/24'], 'ipv6': ['2001:12f8:0:14::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br",
    "participants_pch":29,
    "peak_pch":"6.3G",
    "avg_pch":"3.6G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -34.86306,-7.115 ]
    },
    "properties": {
    "FIELD1":103,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Joao Pessoa",
    "ixpname":"Ponto de Troca de Trafego do Joao Pessoa",
    "alternatenames":"['IX.br (PTT.br) Jo?o Pessoa', 'PTT Jo?o Pessoa']",
    "prefixes":"{'ipv4': ['187.16.193.0/24'], 'ipv6': ['2001:12f8:0:16::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br/",
    "participants_pch":12,
    "peak_pch":"11.9G",
    "avg_pch":"7.8G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -51.96139,-29.46694 ]
    },
    "properties": {
    "FIELD1":104,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Lajeado",
    "ixpname":"Ponto de Troca de Trafego do Lajeado",
    "alternatenames":"['IX.br (PTT.br) Lajeado']",
    "prefixes":"{'ipv4': ['187.16.202.0/24'], 'ipv6': ['2001:12f8:0:25::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://ix.br/",
    "participants_pch":26,
    "peak_pch":"29G",
    "avg_pch":"17.5G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -51.16278,-23.31028 ]
    },
    "properties": {
    "FIELD1":105,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Londrina",
    "ixpname":"Ponto de Troca de Trafego do Londrina",
    "alternatenames":"['IX.br (PTT.br) Londrina']",
    "prefixes":"{'ipv4': ['200.219.144.0/24'], 'ipv6': ['2001:12f8:0:7::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://ix.br",
    "participants_pch":34,
    "peak_pch":"28.2G",
    "avg_pch":"16.7G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -60.025,-3.10194 ]
    },
    "properties": {
    "FIELD1":106,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Manaus",
    "ixpname":"Ponto de Troca de Trafego do Manaus",
    "alternatenames":"['IX.br (PTT.br) Manaus']",
    "prefixes":"{'ipv4': ['187.16.198.0/24'], 'ipv6': ['2001:12f8:0:21::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://ix.br",
    "participants_pch":30,
    "peak_pch":"1.3G",
    "avg_pch":"900M",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -51.93861,-23.42528 ]
    },
    "properties": {
    "FIELD1":107,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Maringa",
    "ixpname":"Ponto de Troca de Trafego do Maringa",
    "alternatenames":"['PTT Maring?', 'IX.br (PTT.br) Maring?']",
    "prefixes":"{'ipv4': ['187.16.201.0/24'], 'ipv6': ['2001:12f8:0:24::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"['http://ix.br/', 'http://ptt.br/']",
    "participants_pch":56,
    "peak_pch":"6.5G",
    "avg_pch":"3.8G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -35.7865855,-9.631133 ]
    },
    "properties": {
    "FIELD1":108,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Meceio",
    "ixpname":"Ponto de Troca de Trafego do Meceio",
    "alternatenames":"['IX.br (PTT.br) Macei?']",
    "prefixes":"{'ipv4': ['45.227.1.0/24'], 'ipv6': ['2001:12f8:0:31::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br/",
    "participants_pch":14,
    "peak_pch":"1.7G",
    "avg_pch":"1.1G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -35.20944,-5.795 ]
    },
    "properties": {
    "FIELD1":109,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Natal",
    "ixpname":"Ponto de Troca de Trafego do Natal",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['he']",
    "url":"http://ix.br",
    "participants_pch":36,
    "peak_pch":"15G",
    "avg_pch":"8.2G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -51.23019,-30.03283 ]
    },
    "properties": {
    "FIELD1":110,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Porto Alegre",
    "ixpname":"Ponto de Troca de Trafego do Porto Alegre",
    "alternatenames":"['IX.br (PTT.br) Porto Alegre']",
    "prefixes":"{'ipv4': ['200.219.143.0/24'], 'ipv6': ['2001:12f8:0:6::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://ix.br",
    "participants_pch":202,
    "peak_pch":"245G",
    "avg_pch":"148G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -34.88111,-8.05389 ]
    },
    "properties": {
    "FIELD1":111,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Recife",
    "ixpname":"Ponto de Troca de Trafego do Recife",
    "alternatenames":"['IX.br (PTT.br) Recife']",
    "prefixes":"{'ipv4': ['200.219.147.0/24'], 'ipv6': ['2001:12f8:0:10::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://ix.br",
    "participants_pch":82,
    "peak_pch":"11.5G",
    "avg_pch":"8.4G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -43.18223,-22.90642 ]
    },
    "properties": {
    "FIELD1":112,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Rio de janeiro",
    "ixpname":"Ponto de Troca de Trafego do Rio de Janeiro",
    "alternatenames":"['IX.br (PTT.br) Rio de Janeiro', 'PTT Rio de Janeiro']",
    "prefixes":"{'ipv4': ['45.6.52.0/22'], 'ipv6': ['2001:12f8:0:2::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br/",
    "participants_pch":319,
    "peak_pch":"1.56T",
    "avg_pch":"1.04T",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -38.51083,-12.97111 ]
    },
    "properties": {
    "FIELD1":113,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Salvador",
    "ixpname":"Ponto de Troca de Trafego do Salvador",
    "alternatenames":"['IX.br (PTT.br) Salvador']",
    "prefixes":"{'ipv4': ['200.219.145.0/24'], 'ipv6': ['2001:12f8:0:8::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://ix.br",
    "participants_pch":74,
    "peak_pch":"20.8G",
    "avg_pch":"11.4G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -48.50444,-1.45583 ]
    },
    "properties": {
    "FIELD1":114,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Santa Maria",
    "ixpname":"Ponto de Troca de Trafego do Santa Maria",
    "alternatenames":"['IX.br (PTT.br) Santa Maria']",
    "prefixes":"{'ipv4': ['187.16.205.0/24'], 'ipv6': ['2001:12f8:0:28::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br/",
    "participants_pch":17,
    "peak_pch":"4G",
    "avg_pch":"1.9G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -49.37944,-20.81972 ]
    },
    "properties": {
    "FIELD1":115,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Sao Jose do Rio Preto",
    "ixpname":"Ponto de Troca de Trafego do Sao Jose do Rio Preto",
    "alternatenames":"['PTT S?o Jos? do Rio Preto', 'IX.br (PTT.br) S?o Jos? do Rio Preto']",
    "prefixes":"{'ipv4': ['187.16.199.0/24'], 'ipv6': ['2001:12f8:0:22::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br",
    "participants_pch":18,
    "peak_pch":"1.8G",
    "avg_pch":"1G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -45.88694,-23.17944 ]
    },
    "properties": {
    "FIELD1":116,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Sao Jose dos Campos",
    "ixpname":"Ponto de Troca de Trafego do Sao Jose dos Campos",
    "alternatenames":"['IX.br (PTT.br) Sao Jos? dos Campos', 'PTT S?o Jos? dos Campos', 'IX.br (PTT.br) S?o Jos? dos Campos']",
    "prefixes":"{'ipv4': ['187.16.192.0/24'], 'ipv6': ['2001:12f8:0:15::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br",
    "participants_pch":13,
    "peak_pch":"370M",
    "avg_pch":"227M",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -44.30278,-2.52972 ]
    },
    "properties": {
    "FIELD1":117,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Sao Luis",
    "ixpname":"Ponto de Troca de Trafego do Sao Luis",
    "alternatenames":"['IX.br (PTT.br) S?o Lu?s', 'PTT S?o Lu?s']",
    "prefixes":"{'ipv4': ['45.227.0.0/24'], 'ipv6': ['2001:12f8:0:30::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br/",
    "participants_pch":16,
    "peak_pch":"1.9M",
    "avg_pch":"500M",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -42.80194,-5.08917 ]
    },
    "properties": {
    "FIELD1":118,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Teresina",
    "ixpname":"Ponto de Troca de Trafego do Teresina",
    "alternatenames":"['PTT Teresina', 'IX.br (PTT.br) Teresina']",
    "prefixes":"{'ipv4': ['200.219.138.0/24'], 'ipv6': ['2001:12f8:0:29::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br/",
    "participants_pch":19,
    "peak_pch":"4G",
    "avg_pch":"2.1G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -40.33778,-20.31944 ]
    },
    "properties": {
    "FIELD1":119,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Vitoria",
    "ixpname":"Ponto de Troca de Trafego do Vitoria",
    "alternatenames":"['IX.br (PTT.br) Vit?ria', 'PTT Vit?ria']",
    "prefixes":"{'ipv4': ['187.16.194.0/24'], 'ipv6': ['2001:12f8:0:17::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.br",
    "participants_pch":23,
    "peak_pch":"8.9G",
    "avg_pch":"4.9G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -50.16194,-25.095 ]
    },
    "properties": {
    "FIELD1":120,
    "country":"Brazil",
    "total_by_country":37,
    "city":"Ponta Grossa",
    "ixpname":"UEPG Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['143.208.160.0/24'], 'ipv6': ['2801:80:330::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.uepg.br",
    "participants_pch":3,
    "peak_pch":"220M",
    "avg_pch":"75M",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 23.32415,42.69751 ]
    },
    "properties": {
    "FIELD1":121,
    "country":"Bulgaria",
    "total_by_country":7,
    "city":"Sofia",
    "ixpname":"Balkan Internet Exchange",
    "alternatenames":"['B-IX']",
    "prefixes":"{'ipv4': ['217.174.157.0/24', '185.1.30.0/24'], 'ipv6': ['2001:7f8:8e::/118', '2001:7f8:8e::/48']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.b-ix.net/",
    "participants_pch":47,
    "peak_pch":"90G",
    "avg_pch":"53G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 23.32415,42.69751 ]
    },
    "properties": {
    "FIELD1":122,
    "country":"Bulgaria",
    "total_by_country":7,
    "city":"Sofia",
    "ixpname":"Bulgarian Internet eXchange",
    "alternatenames":"['BIX.BG']",
    "prefixes":"{'ipv4': ['193.169.198.0/23'], 'ipv6': ['2001:7f8:58::/48', '2001:7f8:58::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.bix.bg/",
    "participants_pch":77,
    "peak_pch":"286G",
    "avg_pch":"188G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 23.32415,42.69751 ]
    },
    "properties": {
    "FIELD1":123,
    "country":"Bulgaria",
    "total_by_country":7,
    "city":"Sofia",
    "ixpname":"GoCIS",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 23.32415,42.69751 ]
    },
    "properties": {
    "FIELD1":124,
    "country":"Bulgaria",
    "total_by_country":7,
    "city":"Sofia",
    "ixpname":"Megaport MegaIX Sofia",
    "alternatenames":"['MegaIX Sofia', 'Megaport MegaIX Sofia (formerly OM-NIX)']",
    "prefixes":"{'ipv4': ['91.212.235.0/24'], 'ipv6': ['2001:7f8:9f::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://megaport.com",
    "participants_pch":16,
    "peak_pch":"11G",
    "avg_pch":"6G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 23.32415,42.69751 ]
    },
    "properties": {
    "FIELD1":125,
    "country":"Bulgaria",
    "total_by_country":7,
    "city":"Sofia",
    "ixpname":"NetIX",
    "alternatenames":"['NetIX Communications Ltd.']",
    "prefixes":"{'ipv4': ['193.218.0.0/24'], 'ipv6': ['2001:67c:29f0::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.netix.net",
    "participants_pch":100,
    "peak_pch":"230G",
    "avg_pch":"215G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 23.32415,42.69751 ]
    },
    "properties": {
    "FIELD1":126,
    "country":"Bulgaria",
    "total_by_country":7,
    "city":"Sofia",
    "ixpname":"T-CIX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.40.0/24'], 'ipv6': ['2001:7f8:98::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.t-cix.net",
    "participants_pch":20,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 27.91667,43.21667 ]
    },
    "properties": {
    "FIELD1":127,
    "country":"Bulgaria",
    "total_by_country":7,
    "city":"Varna",
    "ixpname":"Varna Internet Exchange",
    "alternatenames":"['VarnaIX']",
    "prefixes":"{'ipv4': ['185.1.137.0/24'], 'ipv6': ['2001:7f8:db::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.varnaix.net",
    "participants_pch":8,
    "peak_pch":"2.2G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -1.53388,12.36566 ]
    },
    "properties": {
    "FIELD1":128,
    "country":"Burkina Faso",
    "total_by_country":1,
    "city":"Ouagadougou",
    "ixpname":"Burkina Faso IXP",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['196.13.207.128/26'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":12,
    "peak_pch":"8.57G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2015,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 29.36142,-3.38193 ]
    },
    "properties": {
    "FIELD1":129,
    "country":"Burundi",
    "total_by_country":1,
    "city":"Bujumbura",
    "ixpname":"Burundi Internet Exchange Point",
    "alternatenames":"['BDIXP']",
    "prefixes":"{'ipv4': ['154.73.42.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.bdixp.bi/",
    "participants_pch":8,
    "peak_pch":"2.74M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2017,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 104.91601,11.56245 ]
    },
    "properties": {
    "FIELD1":130,
    "country":"Cambodia",
    "total_by_country":4,
    "city":"Phnom Penh",
    "ixpname":"Cambodian Network Exchange",
    "alternatenames":"['CNX']",
    "prefixes":"{'ipv4': ['103.7.144.0/24', '103.7.144.0/26'], 'ipv6': ['2001:de8:1d::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://cnx.net.kh",
    "participants_pch":29,
    "peak_pch":"12G",
    "avg_pch":"3.5G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2008,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 104.91601,11.56245 ]
    },
    "properties": {
    "FIELD1":131,
    "country":"Cambodia",
    "total_by_country":4,
    "city":"Phnom Penh",
    "ixpname":"HTN-Cambodia Internet Exchange",
    "alternatenames":"['HT Networks Co., Ltd.']",
    "prefixes":"{'ipv4': ['218.100.71.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.htnetworks.com.kh/",
    "participants_pch":16,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2013,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 104.91601,11.56245 ]
    },
    "properties": {
    "FIELD1":132,
    "country":"Cambodia",
    "total_by_country":4,
    "city":"Phnom Penh",
    "ixpname":"MekongIX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":13,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":2020,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 104.91601,11.56245 ]
    },
    "properties": {
    "FIELD1":133,
    "country":"Cambodia",
    "total_by_country":4,
    "city":"Phnom Penh",
    "ixpname":"TC-IX",
    "alternatenames":"['Telecom Cambodia']",
    "prefixes":"{'ipv4': ['203.223.36.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.tc.com.kh",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 4.036072,9.6717645 ]
    },
    "properties": {
    "FIELD1":134,
    "country":"Cameroon",
    "total_by_country":3,
    "city":"Douala, CAMTEL BEPANDA",
    "ixpname":"CAMIX Douala",
    "alternatenames":"['Cameroon Internet Exchange Point']",
    "prefixes":"{'ipv4': ['196.49.38.128/25'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.camix.cm",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Sub-Saharan Africa",
    "year":2014,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 11.51667,3.86667 ]
    },
    "properties": {
    "FIELD1":135,
    "country":"Cameroon",
    "total_by_country":3,
    "city":"Yaounde",
    "ixpname":"Cameroon Internet Exchange Point",
    "alternatenames":"['CAMIX Yaounde']",
    "prefixes":"{'ipv4': ['196.60.6.0/24', '196.49.38.0/25'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.camix.cm",
    "participants_pch":10,
    "peak_pch":"53K",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2014,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 9.70428,4.04827 ]
    },
    "properties": {
    "FIELD1":136,
    "country":"Cameroon",
    "total_by_country":3,
    "city":"Douala",
    "ixpname":"Douala IXP",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['196.49.38.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":7,
    "peak_pch":"207K",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -114.08529,51.05011 ]
    },
    "properties": {
    "FIELD1":137,
    "country":"Canada",
    "total_by_country":14,
    "city":"Calgary",
    "ixpname":"Calgary Internet Exchange",
    "alternatenames":"['YYCIX', 'YYCIX Calgary Internet Exchange']",
    "prefixes":"{'ipv4': ['206.126.225.0/24'], 'ipv6': ['2001:504:2f::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://yycix.ca",
    "participants_pch":38,
    "peak_pch":"43.8G",
    "avg_pch":"34.4G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -79.4163,43.70011 ]
    },
    "properties": {
    "FIELD1":138,
    "country":"Canada",
    "total_by_country":14,
    "city":"Toronto",
    "ixpname":"Equinix Toronto",
    "alternatenames":"['Equinix Internet Exchange Toronto']",
    "prefixes":"{'ipv4': ['198.32.181.0/24'], 'ipv6': ['2001:504:d:80::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.equinix.com",
    "participants_pch":15,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -63.57291,44.6464 ]
    },
    "properties": {
    "FIELD1":139,
    "country":"Canada",
    "total_by_country":14,
    "city":"Halifax",
    "ixpname":"Halifax Internet Exchange",
    "alternatenames":"['HFXIX']",
    "prefixes":"{'ipv4': ['206.130.15.0/24'], 'ipv6': ['2001:504:37:10::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.aixp.ca",
    "participants_pch":17,
    "peak_pch":"150M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -97.14704,49.8844 ]
    },
    "properties": {
    "FIELD1":140,
    "country":"Canada",
    "total_by_country":14,
    "city":"Winnipeg",
    "ixpname":"Manitoba Internet Exchange",
    "alternatenames":"['MBIX']",
    "prefixes":"{'ipv4': ['206.72.208.0/24'], 'ipv6': ['2001:504:26::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.mbix.ca/",
    "participants_pch":22,
    "peak_pch":"1.8G",
    "avg_pch":"310M",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -79.4163,43.70011 ]
    },
    "properties": {
    "FIELD1":141,
    "country":"Canada",
    "total_by_country":14,
    "city":"Toronto",
    "ixpname":"Megaport Toronto",
    "alternatenames":"['Megaport MegaIX Toronto', 'MegaIX Toronto']",
    "prefixes":"{'ipv4': ['206.53.203.0/24'], 'ipv6': ['2606:a980:0:8::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://megaport.com",
    "participants_pch":6,
    "peak_pch":"500M",
    "avg_pch":"300M",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -64.7965,46.09454 ]
    },
    "properties": {
    "FIELD1":142,
    "country":"Canada",
    "total_by_country":14,
    "city":"Moncton",
    "ixpname":"Moncton Internet Exchange",
    "alternatenames":"['MonctonIX']",
    "prefixes":"{'ipv4': ['206.71.137.0/24'], 'ipv6': ['2001:504:73::/128', '2001:504:73:cafe::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://monctonix.ca",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -73.58781,45.50884 ]
    },
    "properties": {
    "FIELD1":143,
    "country":"Canada",
    "total_by_country":14,
    "city":"Montreal",
    "ixpname":"Quebec Internet Exchange",
    "alternatenames":"['Quebec Internet Exchange (QIX)']",
    "prefixes":"{'ipv4': ['198.179.18.0/24'], 'ipv6': ['2001:504:2d::/64']}",
    "sources":"['pdb']",
    "url":"https://www.qix.ca/?lang=en",
    "participants_pch":73,
    "peak_pch":"218G",
    "avg_pch":"79G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -79.4163,43.70011 ]
    },
    "properties": {
    "FIELD1":144,
    "country":"Canada",
    "total_by_country":14,
    "city":"Toronto",
    "ixpname":"Toronto Internet Exchange",
    "alternatenames":"['TORIX', 'Toronto Internet Exchange Community', 'TorIX']",
    "prefixes":"{'ipv4': ['206.108.34.0/23'], 'ipv6': ['2001:504:1a::34:0/111']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.torix.ca/",
    "participants_pch":226,
    "peak_pch":"783G",
    "avg_pch":"600G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":1998,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -123.11934,49.24966 ]
    },
    "properties": {
    "FIELD1":145,
    "country":"Canada",
    "total_by_country":14,
    "city":"Vancouver",
    "ixpname":"UNMETERED Exchange",
    "alternatenames":"['UNMETERED.Exchange', 'UNMETERED Exchange']",
    "prefixes":"{'ipv4': ['192.34.27.0/24', '192.34.26.0/23'], 'ipv6': ['2602:ffb1:4000::/48', '2602:ffb1:200::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://unmetered.exchange",
    "participants_pch":5,
    "peak_pch":"2.5G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -123.11934,49.24966 ]
    },
    "properties": {
    "FIELD1":146,
    "country":"Canada",
    "total_by_country":14,
    "city":"Vancouver",
    "ixpname":"Vancouver Internet Exchange",
    "alternatenames":"['VANIX']",
    "prefixes":"{'ipv4': ['206.41.104.0/24'], 'ipv6': ['2001:504:39::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.vanix.ca",
    "participants_pch":56,
    "peak_pch":"9.6G",
    "avg_pch":"4.8G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -123.35155,48.4359 ]
    },
    "properties": {
    "FIELD1":147,
    "country":"Canada",
    "total_by_country":14,
    "city":"Victoria",
    "ixpname":"Victoria Transit Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -97.14704,49.8844 ]
    },
    "properties": {
    "FIELD1":148,
    "country":"Canada",
    "total_by_country":14,
    "city":"Winnipeg",
    "ixpname":"Winnipeg Internet Exchange",
    "alternatenames":"['WPGIX']",
    "prefixes":"{'ipv4': ['206.126.109.0/24'], 'ipv6': ['2001:504:2c::/116', '2001:504:2c::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://wpgix.net/",
    "participants_pch":25,
    "peak_pch":"8.8G",
    "avg_pch":"2K",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -113.46871,53.55014 ]
    },
    "properties": {
    "FIELD1":149,
    "country":"Canada",
    "total_by_country":14,
    "city":"Edmonton",
    "ixpname":"YEGIX Edmonton Internet Exchange",
    "alternatenames":"['YEGIX']",
    "prefixes":"{'ipv4': ['206.53.140.0/24'], 'ipv6': ['2001:504:46::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.yegix.ca/",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -106.66892,52.13238 ]
    },
    "properties": {
    "FIELD1":150,
    "country":"Canada",
    "total_by_country":14,
    "city":"Saskatoon",
    "ixpname":"YXEIX Saskatoon Internet Exchange",
    "alternatenames":"['YXEIX', 'Saskatoon Internet Exchange Inc']",
    "prefixes":"{'ipv4': ['206.71.11.0/24'], 'ipv6': ['2001:504:69::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://yxeix.ca",
    "participants_pch":6,
    "peak_pch":"281M",
    "avg_pch":"340M",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 15.0444,12.10672 ]
    },
    "properties": {
    "FIELD1":151,
    "country":"Chad",
    "total_by_country":1,
    "city":"N'Djamena",
    "ixpname":"Tchad Internet Exchange Point",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -70.64827,-33.45694 ]
    },
    "properties": {
    "FIELD1":152,
    "country":"Chile",
    "total_by_country":8,
    "city":"Santiago",
    "ixpname":"NAP Chile",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['192.168.173.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":21,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -70.64827,-33.45694 ]
    },
    "properties": {
    "FIELD1":153,
    "country":"Chile",
    "total_by_country":8,
    "city":"Santiago",
    "ixpname":"PIT Chile - Santiago",
    "alternatenames":"['PIT Chile Santiago/ IXP Chile Santiago', 'PIT Chile', 'PIT Chile - Santiago']",
    "prefixes":"{'ipv4': ['200.23.206.0/24'], 'ipv6': ['2801:14:9000::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.pitchile.cl",
    "participants_pch":57,
    "peak_pch":"1.2T",
    "avg_pch":"900G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -70.29792,-18.4746 ]
    },
    "properties": {
    "FIELD1":154,
    "country":"Chile",
    "total_by_country":8,
    "city":"Arica",
    "ixpname":"PIT Chile Arica",
    "alternatenames":"['PIT Chile Arica']",
    "prefixes":"{'ipv4': ['45.71.8.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.pitarica.cl",
    "participants_pch":4,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -73.13348,-40.57395 ]
    },
    "properties": {
    "FIELD1":155,
    "country":"Chile",
    "total_by_country":8,
    "city":"Osorno",
    "ixpname":"PIT Chile Osorno",
    "alternatenames":"['PIT Osorno', 'PIT Chile Osorno']",
    "prefixes":"{'ipv4': ['45.71.11.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.pitosorno.cl",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -72.59842,-38.73965 ]
    },
    "properties": {
    "FIELD1":156,
    "country":"Chile",
    "total_by_country":8,
    "city":"Temuco",
    "ixpname":"PIT Chile Temuco",
    "alternatenames":"['PIT Temuco', 'PIT Chile Temuco']",
    "prefixes":"{'ipv4': ['45.71.10.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.pittemuco.cl",
    "participants_pch":4,
    "peak_pch":"650M",
    "avg_pch":"400M",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -70.64827,-33.45694 ]
    },
    "properties": {
    "FIELD1":157,
    "country":"Chile",
    "total_by_country":8,
    "city":"Santiago",
    "ixpname":"PIT entel",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['186.10.203.0/24'], 'ipv6': ['2800:300:1::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.pitentel.cl",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Latin America & Caribbean",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -73.04977,-36.82699 ]
    },
    "properties": {
    "FIELD1":158,
    "country":"Chile",
    "total_by_country":8,
    "city":"Concepcion",
    "ixpname":"PITChile Concepcion",
    "alternatenames":"['PITChile Concepcion', 'PIT Concepcion']",
    "prefixes":"{'ipv4': ['45.71.9.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.pitconcepcion.cl",
    "participants_pch":45,
    "peak_pch":"2.09G",
    "avg_pch":"1.3G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -70.64827,-33.45694 ]
    },
    "properties": {
    "FIELD1":159,
    "country":"Chile",
    "total_by_country":8,
    "city":"Santiago",
    "ixpname":"SCL-IX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":11,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"Latin America & Caribbean",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 113.25,23.11667 ]
    },
    "properties": {
    "FIELD1":160,
    "country":"China",
    "total_by_country":20,
    "city":"Guangzhou",
    "ixpname":".",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 116.39723,39.9075 ]
    },
    "properties": {
    "FIELD1":161,
    "country":"China",
    "total_by_country":20,
    "city":"Beijing",
    "ixpname":"Beijing National Internet Exchange Center",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":11,
    "peak_pch":"2G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 116.39723,39.9075 ]
    },
    "properties": {
    "FIELD1":162,
    "country":"China",
    "total_by_country":20,
    "city":"Beijing",
    "ixpname":"CHN-IX",
    "alternatenames":"['CHN IX']",
    "prefixes":"{'ipv4': ['106.48.32.0/19'], 'ipv6': ['2405:3b00::/64']}",
    "sources":"['pch', 'he']",
    "url":"http://www.chn-ix.net",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 116.39723,39.9075 ]
    },
    "properties": {
    "FIELD1":163,
    "country":"China",
    "total_by_country":20,
    "city":"Beijing",
    "ixpname":"CHN-IX Beijing",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":20,
    "peak_pch":"60G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 113.25,23.11667 ]
    },
    "properties": {
    "FIELD1":164,
    "country":"China",
    "total_by_country":20,
    "city":"Guangzhou",
    "ixpname":"CHN-IX Guangzhou",
    "alternatenames":"['CHN-IX China Guangzhou', 'CN-IX Guangzhou']",
    "prefixes":"{'ipv4': ['106.48.36.0/23', '103.40.220.0/22'], 'ipv6': ['2405:3b01::/64']}",
    "sources":"['pdb', 'he']",
    "url":"['http://www.cn-ix.com', 'http://www.chn-ix.net']",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 121.45806,31.22222 ]
    },
    "properties": {
    "FIELD1":165,
    "country":"China",
    "total_by_country":20,
    "city":"Shanghai",
    "ixpname":"CHN-IX Shanghai",
    "alternatenames":"['CHN-IX China Shanghai', 'CN-IX Shanghai']",
    "prefixes":"{'ipv4': ['106.48.38.0/23', '43.249.132.0/22'], 'ipv6': ['2405:3b02::/64']}",
    "sources":"['pdb', 'he']",
    "url":"['http://www.cn-ix.com', 'http://www.chn-ix.net']",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 113.25,23.11667 ]
    },
    "properties": {
    "FIELD1":166,
    "country":"China",
    "total_by_country":20,
    "city":"Guangzhou",
    "ixpname":"CN-IX Guangzhou",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['103.40.222.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.cn-ix.com",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 121.45806,31.22222 ]
    },
    "properties": {
    "FIELD1":167,
    "country":"China",
    "total_by_country":20,
    "city":"Shanghai",
    "ixpname":"CN-IX Shanghai",
    "alternatenames":"['CN-IX']",
    "prefixes":"{'ipv4': ['43.249.135.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.cn-ix.com",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 116.39723,39.9075 ]
    },
    "properties": {
    "FIELD1":168,
    "country":"China",
    "total_by_country":20,
    "city":"Beijing",
    "ixpname":"CN-IX-BJ",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['144.48.88.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.cn-ix.com",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 116.39723,39.9075 ]
    },
    "properties": {
    "FIELD1":169,
    "country":"China",
    "total_by_country":20,
    "city":"Beijing",
    "ixpname":"CNC Beijing NAP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 116.39723,39.9075 ]
    },
    "properties": {
    "FIELD1":170,
    "country":"China",
    "total_by_country":20,
    "city":"Beijing",
    "ixpname":"CNIX China Internet Exchange",
    "alternatenames":"['CNIX', 'China Internet Exchange']",
    "prefixes":"{'ipv4': ['103.216.40.0/23'], 'ipv6': ['2404:e780:f872:a::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.cnix.com.cn",
    "participants_pch":17,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 116.39723,39.9075 ]
    },
    "properties": {
    "FIELD1":171,
    "country":"China",
    "total_by_country":20,
    "city":"Beijing",
    "ixpname":"Cnean",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['101.251.128.0/22'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"http://www.cnean.com",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 118.77778,32.06167 ]
    },
    "properties": {
    "FIELD1":172,
    "country":"China",
    "total_by_country":20,
    "city":"Nanjing",
    "ixpname":"LSY.CN Nanjing",
    "alternatenames":"['LSHIY Group Nanjing Internet eXchange']",
    "prefixes":"{'ipv4': [], 'ipv6': ['2404:f4c0:4:6::/64', '2403:5180:25:320::/64', '2404:f4c0:4:320::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://ix.lsy.cn/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 114.0683,22.54554 ]
    },
    "properties": {
    "FIELD1":173,
    "country":"China",
    "total_by_country":20,
    "city":"Shenzhen",
    "ixpname":"LSY.CN Shenzhen",
    "alternatenames":"['LSHIY Group Shenzhen Internet eXchange']",
    "prefixes":"{'ipv4': [], 'ipv6': ['2404:f4c0:4:a::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://ix.lsy.cn/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 114.26667,30.58333 ]
    },
    "properties": {
    "FIELD1":174,
    "country":"China",
    "total_by_country":20,
    "city":"Wuhan",
    "ixpname":"LSY.CN Wuhan",
    "alternatenames":"['LSHIY Group Wuhan Internet eXchange']",
    "prefixes":"{'ipv4': [], 'ipv6': ['2404:f4c0:4:1::/64', '2403:5180:25:420::/64', '2404:f4c0:4:420::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://ix.lsy.cn/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 113.64861,34.75778 ]
    },
    "properties": {
    "FIELD1":175,
    "country":"China",
    "total_by_country":20,
    "city":"Zhengzhou",
    "ixpname":"MoeIX Zhengzhou",
    "alternatenames":"['MoeQing Internet Exchange - Zhengmsterdam']",
    "prefixes":"{'ipv4': [], 'ipv6': ['2a0c:b641:70:10::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.moeix.online",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 121.45806,31.22222 ]
    },
    "properties": {
    "FIELD1":176,
    "country":"China",
    "total_by_country":20,
    "city":"Shanghai",
    "ixpname":"Shanghai City Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 121.45806,31.22222 ]
    },
    "properties": {
    "FIELD1":177,
    "country":"China",
    "total_by_country":20,
    "city":"Shanghai",
    "ixpname":"Shanghai Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 116.39723,39.9075 ]
    },
    "properties": {
    "FIELD1":178,
    "country":"China",
    "total_by_country":20,
    "city":"Beijing",
    "ixpname":"TerreNAP Beijing",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 113.25,23.11667 ]
    },
    "properties": {
    "FIELD1":179,
    "country":"China",
    "total_by_country":20,
    "city":"Guangzhou",
    "ixpname":"Yajuu Senpai Internet eXchange",
    "alternatenames":"['Yajuu Senpai Internet eXchange']",
    "prefixes":"{'ipv4': ['103.86.68.128/27'], 'ipv6': ['2a0b:4340:9:514::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://yjsnpix.com",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.08175,4.60971 ]
    },
    "properties": {
    "FIELD1":180,
    "country":"Colombia",
    "total_by_country":3,
    "city":"Bogota",
    "ixpname":"Equinix Bogota",
    "alternatenames":"['Equinix Bogota Exchange']",
    "prefixes":"{'ipv4': ['208.115.128.0/24'], 'ipv6': ['2001:504:0:10::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.equinix.com",
    "participants_pch":14,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.08175,4.60971 ]
    },
    "properties": {
    "FIELD1":181,
    "country":"Colombia",
    "total_by_country":3,
    "city":"Bogota",
    "ixpname":"NAP-Colombia",
    "alternatenames":"['NAP-Colombia']",
    "prefixes":"{'ipv4': ['206.223.124.0/24', '206.223.124.128/25'], 'ipv6': ['2001:13c7:6000::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://nap.co",
    "participants_pch":21,
    "peak_pch":"50G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 29.22845,-1.67409 ]
    },
    "properties": {
    "FIELD1":182,
    "country":"Democratic Republic of the Congo",
    "total_by_country":4,
    "city":"Goma",
    "ixpname":"Goma Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Sub-Saharan Africa",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 15.31357,-4.32758 ]
    },
    "properties": {
    "FIELD1":183,
    "country":"Democratic Republic of the Congo",
    "total_by_country":4,
    "city":"Kinshasa",
    "ixpname":"Kinshasa Internet Exchange",
    "alternatenames":"['KINshasa Internet eXchange']",
    "prefixes":"{'ipv4': ['196.223.28.0/24', '196.216.216.0/23'], 'ipv6': ['2001:43f8:3c1::/48']}",
    "sources":"['pdb']",
    "url":"http://www.ispa-drc.cd",
    "participants_pch":11,
    "peak_pch":"5.1G",
    "avg_pch":"2.5G",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2002,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 27.47938,-11.66089 ]
    },
    "properties": {
    "FIELD1":184,
    "country":"Democratic Republic of the Congo",
    "total_by_country":4,
    "city":"Lubumbashi",
    "ixpname":"Lubumbashi Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":4,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"Sub-Saharan Africa",
    "year":2019,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 15.31357,-4.32758 ]
    },
    "properties": {
    "FIELD1":185,
    "country":"Democratic Republic of the Congo",
    "total_by_country":4,
    "city":"Kinshasa",
    "ixpname":"RDC-IX Kinshasa",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['196.223.28.0/24', '196.216.216.0/23'], 'ipv6': ['2001:43f8:3c0::/48', '2001:43f8:3c1::/48']}",
    "sources":"['he']",
    "url":"http://www.ispa-drc.cd",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Sub-Saharan Africa",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 15.28318,-4.26613 ]
    },
    "properties": {
    "FIELD1":186,
    "country":"Congo",
    "total_by_country":1,
    "city":"Brazzaville",
    "ixpname":"Congo Brazzaville IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":7,
    "peak_pch":"20K",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2013,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -84.08333,9.93333 ]
    },
    "properties": {
    "FIELD1":187,
    "country":"Costa Rica",
    "total_by_country":1,
    "city":"San Jose",
    "ixpname":"Punto de Intercambio Neutro de Internet",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['200.107.83.128/25'], 'ipv6': ['2801:1d:a000:1::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":27,
    "peak_pch":"8G",
    "avg_pch":"2.23G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -4.1197499,5.3487761 ]
    },
    "properties": {
    "FIELD1":188,
    "country":"Ivort Coast",
    "total_by_country":1,
    "city":"Abidjan",
    "ixpname":"Cote d'Ivoire Internet Exchange Point",
    "alternatenames":"['CIVIX']",
    "prefixes":"{'ipv4': ['196.223.4.0/24', '196.49.0.0/24'], 'ipv6': ['2001:db8::/64', '2001:43f8:940::/48']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.civix.ci",
    "participants_pch":6,
    "peak_pch":"422M",
    "avg_pch":"210M",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2013,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 15.97798,45.81444 ]
    },
    "properties": {
    "FIELD1":189,
    "country":"Croatia",
    "total_by_country":1,
    "city":"Zagreb",
    "ixpname":"Croatian Internet Exchange",
    "alternatenames":"['CIX']",
    "prefixes":"{'ipv4': ['185.1.87.0/24'], 'ipv6': ['2001:7f8:28::/48', '2001:7f8:28::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.cix.hr/",
    "participants_pch":34,
    "peak_pch":"40G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -82.38304,23.13302 ]
    },
    "properties": {
    "FIELD1":190,
    "country":"Cuba",
    "total_by_country":1,
    "city":"Habana",
    "ixpname":"NAP de Cuba",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['200.0.16.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":5,
    "peak_pch":"50M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -68.93354,12.1084 ]
    },
    "properties": {
    "FIELD1":191,
    "country":"Curacao",
    "total_by_country":2,
    "city":"Curacao",
    "ixpname":"AMS-IX Caribbean",
    "alternatenames":"['Amsterdam Internet Exchange Caribbean']",
    "prefixes":"{'ipv4': ['200.0.20.0/24'], 'ipv6': ['2001:13c7:6004::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.ams-ix.cw/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Latin America & Caribbean",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -68.93354,12.1084 ]
    },
    "properties": {
    "FIELD1":192,
    "country":"Curacao",
    "total_by_country":2,
    "city":"Willemstad",
    "ixpname":"Caribbean Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['200.0.20.0/24'], 'ipv6': ['2001:7f8:1::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":14,
    "peak_pch":"21.5G",
    "avg_pch":"12.6G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 33.3642,35.17531 ]
    },
    "properties": {
    "FIELD1":193,
    "country":"Cyprus",
    "total_by_country":2,
    "city":"Nicosia",
    "ixpname":"CyIX",
    "alternatenames":"['Cyprus Internet Exchange']",
    "prefixes":"{'ipv4': ['193.22.30.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.cytanet.com.cy/network/cyix/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":1999,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 33.3642,35.17531 ]
    },
    "properties": {
    "FIELD1":194,
    "country":"Cyprus",
    "total_by_country":2,
    "city":"Lefkosia",
    "ixpname":"Cyprus Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":3,
    "peak_pch":"10M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1999,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 16.60796,49.19522 ]
    },
    "properties": {
    "FIELD1":195,
    "country":"Czech Republic",
    "total_by_country":4,
    "city":"Brno",
    "ixpname":"Brno Internet Exchange Point",
    "alternatenames":"['Brno University of Technology', 'BR-IX']",
    "prefixes":"{'ipv4': ['185.1.25.0/24'], 'ipv6': ['2001:7f8:87::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.br-ix.cz",
    "participants_pch":7,
    "peak_pch":"50G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 14.42076,50.08804 ]
    },
    "properties": {
    "FIELD1":196,
    "country":"Czech Republic",
    "total_by_country":4,
    "city":"Prague",
    "ixpname":"NIX.CZ - Neutral Internet eXchange for the Czech Republic",
    "alternatenames":"['Neutral Internet Exchange in the Czech Republic']",
    "prefixes":"{'ipv4': ['91.210.16.0/22', '194.50.100.0/24'], 'ipv6': ['2001:7f8:14::/64', '2001:7f8:14:5ec::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.nix.cz/",
    "participants_pch":150,
    "peak_pch":"1T",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 14.42076,50.08804 ]
    },
    "properties": {
    "FIELD1":197,
    "country":"Czech Republic",
    "total_by_country":4,
    "city":"Prague",
    "ixpname":"Neutral czFree eXchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['81.201.48.192/26'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":10,
    "peak_pch":"115G",
    "avg_pch":"61G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 14.42076,50.08804 ]
    },
    "properties": {
    "FIELD1":198,
    "country":"Czech Republic",
    "total_by_country":4,
    "city":"Prague",
    "ixpname":"Peering.cz",
    "alternatenames":"['Peering.cz eXchange']",
    "prefixes":"{'ipv4': ['91.213.211.0/24'], 'ipv6': ['2001:7f8:7f::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.peering.cz",
    "participants_pch":148,
    "peak_pch":"900G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 12.56553,55.67594 ]
    },
    "properties": {
    "FIELD1":199,
    "country":"Denmark",
    "total_by_country":3,
    "city":"Copenhagen",
    "ixpname":"Content-IX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 12.56553,55.67594 ]
    },
    "properties": {
    "FIELD1":200,
    "country":"Denmark",
    "total_by_country":3,
    "city":"Copenhagen",
    "ixpname":"Danish Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['192.38.7.0/24'], 'ipv6': ['2001:7f8:1f::/48']}",
    "sources":"['he']",
    "url":"http://www.dix.dk/",
    "participants_pch":48,
    "peak_pch":"44.2G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1994,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 12.56553,55.67594 ]
    },
    "properties": {
    "FIELD1":201,
    "country":"Denmark",
    "total_by_country":3,
    "city":"Copenhagen",
    "ixpname":"Netnod Copenhagen",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['195.69.117.0/24', '195.69.118.0/24'], 'ipv6': ['2001:7f8:d::/48', '2001:7f8:d:201::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":50,
    "peak_pch":"154G",
    "avg_pch":"91G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 43.14503,11.58901 ]
    },
    "properties": {
    "FIELD1":202,
    "country":"Djibouti",
    "total_by_country":1,
    "city":"Djibouti City",
    "ixpname":"DjIX",
    "alternatenames":"['The Djibouti Internet Exchange']",
    "prefixes":"{'ipv4': ['196.223.38.0/24'], 'ipv6': ['2001:43f8:9c0:1000::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.djiboutidatacenter.com/",
    "participants_pch":10,
    "peak_pch":"6.8G",
    "avg_pch":"2.6G",
    "status_pch":"active",
    "only_in":"",
    "region":"Middle East & North Africa",
    "year":2016,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -61.38808,15.30174 ]
    },
    "properties": {
    "FIELD1":203,
    "country":"Dominica",
    "total_by_country":1,
    "city":"Roseau",
    "ixpname":"Dominica National Internet Exchange Point",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.53.141.0/27'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":4,
    "peak_pch":"67.5M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -69.89232,18.47186 ]
    },
    "properties": {
    "FIELD1":204,
    "country":"Dominican Republic",
    "total_by_country":1,
    "city":"Santo Domingo",
    "ixpname":"NAP del Caribe",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['191.97.88.0/21'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":15,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -79.88621,-2.19616 ]
    },
    "properties": {
    "FIELD1":205,
    "country":"Ecuador",
    "total_by_country":6,
    "city":"Guayaquil",
    "ixpname":"IXP Ecuador",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['200.107.255.120/29'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":9,
    "peak_pch":"964M",
    "avg_pch":"622M",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -80.71271,-0.96212 ]
    },
    "properties": {
    "FIELD1":206,
    "country":"Ecuador",
    "total_by_country":6,
    "city":"Manta",
    "ixpname":"IXP Ecuador - Manta",
    "alternatenames":"['IXP Ecuador - Manta']",
    "prefixes":"{'ipv4': ['190.52.206.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"https://www.ixp.ec",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -79.17536,-0.25305 ]
    },
    "properties": {
    "FIELD1":207,
    "country":"Ecuador",
    "total_by_country":6,
    "city":"Santo Domingo",
    "ixpname":"IXP Ecuador - STD",
    "alternatenames":"['IXP Ecuador - Santo Domingo']",
    "prefixes":"{'ipv4': ['200.107.255.0/24'], 'ipv6': ['2803:b4c0::/32']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.ixp.ec",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Latin America & Caribbean",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -79.80697,-3.32561 ]
    },
    "properties": {
    "FIELD1":208,
    "country":"Ecuador",
    "total_by_country":6,
    "city":"Pasaje",
    "ixpname":"IXP-APROSVA Pasaje",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['170.82.113.0/27'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":11,
    "peak_pch":"350M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -79.88621,-2.19616 ]
    },
    "properties": {
    "FIELD1":209,
    "country":"Ecuador",
    "total_by_country":6,
    "city":"Guayaquil",
    "ixpname":"NAP AEPROVI Guayaquil",
    "alternatenames":"['NAP / IXP / IX / PIT del Ecuador - Guayaquil']",
    "prefixes":"{'ipv4': ['200.110.120.0/24'], 'ipv6': ['2001:13c7:6f80::/48']}",
    "sources":"['pdb']",
    "url":"http://www.nap.ec",
    "participants_pch":10,
    "peak_pch":"10.4G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -78.52495,-0.22985 ]
    },
    "properties": {
    "FIELD1":210,
    "country":"Ecuador",
    "total_by_country":6,
    "city":"Quito",
    "ixpname":"NAP AEPROVI Quito",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['200.1.6.0/24'], 'ipv6': ['2001:13c7:6f00::/48']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":21,
    "peak_pch":"44.5G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 31.24967,30.06263 ]
    },
    "properties": {
    "FIELD1":211,
    "country":"Egypt",
    "total_by_country":2,
    "city":"Cairo",
    "ixpname":"Cairo Internet Exchange",
    "alternatenames":"['Cairo Internet eXchange', 'CAIX']",
    "prefixes":"{'ipv4': ['81.21.96.0/24'], 'ipv6': ['2001:4300:96::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.caix.net.eg/",
    "participants_pch":7,
    "peak_pch":"4G",
    "avg_pch":"2.6G",
    "status_pch":"active",
    "only_in":"",
    "region":"Middle East & North Africa",
    "year":2002,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 31.24967,30.06263 ]
    },
    "properties": {
    "FIELD1":212,
    "country":"Egypt",
    "total_by_country":2,
    "city":"Cairo",
    "ixpname":"Middle East Internet eXchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['196.223.7.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":10,
    "peak_pch":"15K",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Middle East & North Africa",
    "year":2007,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 24.75353,59.43696 ]
    },
    "properties": {
    "FIELD1":213,
    "country":"Estonia",
    "total_by_country":4,
    "city":"Tallinn",
    "ixpname":"PITER-IX Tallinn",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['37.9.49.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":11,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 24.75353,59.43696 ]
    },
    "properties": {
    "FIELD1":214,
    "country":"Estonia",
    "total_by_country":4,
    "city":"Tallinn",
    "ixpname":"Tallinn Governmental Internet Exchange",
    "alternatenames":"['RTIX']",
    "prefixes":"{'ipv4': ['213.184.52.0/24'], 'ipv6': ['2001:7f8:50:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.ria.ee/en.html",
    "participants_pch":11,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 24.75353,59.43696 ]
    },
    "properties": {
    "FIELD1":215,
    "country":"Estonia",
    "total_by_country":4,
    "city":"Tallinn",
    "ixpname":"Tallinn Internet Exchange (TIX)",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['194.116.188.0/23'], 'ipv6': ['2001:7f8:15::/48']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":6,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 24.75353,59.43696 ]
    },
    "properties": {
    "FIELD1":216,
    "country":"Estonia",
    "total_by_country":4,
    "city":"Tallinn",
    "ixpname":"Tallinn Internet Exchange (TLLIX)",
    "alternatenames":"['TLLIX', 'Tallinn Internet Exchange']",
    "prefixes":"{'ipv4': ['195.137.179.0/24'], 'ipv6': ['2001:7f8:39:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.tllix.net/",
    "participants_pch":10,
    "peak_pch":"1.1G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2005,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 31.38004,-26.49884 ]
    },
    "properties": {
    "FIELD1":217,
    "country":"Eswatini",
    "total_by_country":1,
    "city":"Swaziland",
    "ixpname":"SISPA",
    "alternatenames":"['Swaziland Peering Point']",
    "prefixes":"{'ipv4': ['196.223.37.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Sub-Saharan Africa",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 24.93545,60.16952 ]
    },
    "properties": {
    "FIELD1":218,
    "country":"Finland",
    "total_by_country":6,
    "city":"Helsinki",
    "ixpname":"Equinix Helsinki",
    "alternatenames":"['Equinix Internet Exchange Helsinki']",
    "prefixes":"{'ipv4': ['185.1.86.0/24'], 'ipv6': ['2001:7f8:af::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.equinix.fi/services/interconnection-connectivity/internet-exchange/",
    "participants_pch":10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 24.6522,60.2052 ]
    },
    "properties": {
    "FIELD1":219,
    "country":"Finland",
    "total_by_country":6,
    "city":"Espoo",
    "ixpname":"Finnish Communication and Internet Exchange Espoo",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['193.110.226.0/24', '193.110.227.32/27'], 'ipv6': ['2001:7f8:7:a::/64', '2001:7f8:7::/64', '2001:7f8:7:3::/64']}",
    "sources":"['he']",
    "url":"https://www.ficix.fi/",
    "participants_pch":12,
    "peak_pch":"19.1G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1993,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 24.93545,60.16952 ]
    },
    "properties": {
    "FIELD1":220,
    "country":"Finland",
    "total_by_country":6,
    "city":"Helsinki",
    "ixpname":"Finnish Communication and Internet Exchange Helsinki",
    "alternatenames":"['FICIX 2 Helsinki', 'FICIX']",
    "prefixes":"{'ipv4': ['193.110.224.0/24'], 'ipv6': ['2001:7f8:7:b::/64', '2001:7f8:7:1::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.ficix.fi/",
    "participants_pch":47,
    "peak_pch":"36G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1993,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 25.46816,65.01236 ]
    },
    "properties": {
    "FIELD1":221,
    "country":"Finland",
    "total_by_country":6,
    "city":"Oulu",
    "ixpname":"Finnish Communication and Internet Exchange Oulu",
    "alternatenames":"['FICIX 3 (Oulu)', 'FICIX 3 Oulu']",
    "prefixes":"{'ipv4': ['193.110.225.0/24'], 'ipv6': ['2001:7f8:7:c::/64', '2001:7f8:7:2::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.ficix.fi/",
    "participants_pch":7,
    "peak_pch":"900M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 24.93545,60.16952 ]
    },
    "properties": {
    "FIELD1":222,
    "country":"Finland",
    "total_by_country":6,
    "city":"Helsinki",
    "ixpname":"IXP HEL",
    "alternatenames":"['Internet Exchange Point - Helsinki']",
    "prefixes":"{'ipv4': [], 'ipv6': ['2a0c:3b80:4040:4649::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.ixp.cat",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 23.78712,61.49911 ]
    },
    "properties": {
    "FIELD1":223,
    "country":"Finland",
    "total_by_country":6,
    "city":"Tampere",
    "ixpname":"Tampere Region Exchange",
    "alternatenames":"['TREX']",
    "prefixes":"{'ipv4': ['195.140.192.0/24'], 'ipv6': ['2001:7f8:1d:4::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.trex.fi/",
    "participants_pch":21,
    "peak_pch":"1.2G",
    "avg_pch":"370M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 3.08682,45.77969 ]
    },
    "properties": {
    "FIELD1":224,
    "country":"France",
    "total_by_country":20,
    "city":"Clermont-Ferrand",
    "ixpname":"AuvernIX",
    "alternatenames":"['Auvergne et du Massif Central']",
    "prefixes":"{'ipv4': ['185.1.2.0/24'], 'ipv6': ['2001:7f8:81::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.auvernix.org",
    "participants_pch":9,
    "peak_pch":"800M",
    "avg_pch":"140M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -1.67429,48.11198 ]
    },
    "properties": {
    "FIELD1":225,
    "country":"France",
    "total_by_country":20,
    "city":"Rennes",
    "ixpname":"BreizhIX",
    "alternatenames":"['BreizhIX']",
    "prefixes":"{'ipv4': ['185.1.89.0/24'], 'ipv6': ['2001:7f8:b1::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.breizh-ix.net/",
    "participants_pch":13,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 5.38107,43.29695 ]
    },
    "properties": {
    "FIELD1":226,
    "country":"France",
    "total_by_country":20,
    "city":"Marseille",
    "ixpname":"DE-CIX Marseille",
    "alternatenames":"['Deutscher Commercial Internet Exchange Marseille']",
    "prefixes":"{'ipv4': ['185.1.47.0/24'], 'ipv6': ['2001:7f8:36::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://mrs.de-cix.net",
    "participants_pch":67,
    "peak_pch":"58G",
    "avg_pch":"42G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 2.3488,48.85341 ]
    },
    "properties": {
    "FIELD1":227,
    "country":"France",
    "total_by_country":20,
    "city":"Paris",
    "ixpname":"Equinix Paris",
    "alternatenames":"['Equinix Internet Exchange Paris']",
    "prefixes":"{'ipv4': ['195.42.144.0/23'], 'ipv6': ['2001:7f8:43::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.equinix-ix.fr/",
    "participants_pch":350,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 7.74553,48.58392 ]
    },
    "properties": {
    "FIELD1":228,
    "country":"France",
    "total_by_country":20,
    "city":"Alsace",
    "ixpname":"EuroGIX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.14.0/24'], 'ipv6': ['2001:7f8:79::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.eurogix.org/",
    "participants_pch":9,
    "peak_pch":"348M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 2.3488,48.85341 ]
    },
    "properties": {
    "FIELD1":229,
    "country":"France",
    "total_by_country":20,
    "city":"Paris",
    "ixpname":"FR-IX 75",
    "alternatenames":"['FR-IX']",
    "prefixes":"{'ipv4': ['91.216.67.0/24'], 'ipv6': ['2001:7f8:59:0:75::/96']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.fr-ix.fr",
    "participants_pch":18,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 2.3488,48.85341 ]
    },
    "properties": {
    "FIELD1":230,
    "country":"France",
    "total_by_country":20,
    "city":"Paris",
    "ixpname":"France-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['37.49.236.0/23', '37.49.236.0/22'], 'ipv6': ['2001:7f8:54::/64']}",
    "sources":"['pch', 'he']",
    "url":"https://www.franceix.net",
    "participants_pch":346,
    "peak_pch":"1.03T",
    "avg_pch":"824G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 5.38107,43.29695 ]
    },
    "properties": {
    "FIELD1":231,
    "country":"France",
    "total_by_country":20,
    "city":"Marseille",
    "ixpname":"France-IX Marseille",
    "alternatenames":"['FranceIX Marseille']",
    "prefixes":"{'ipv4': ['37.49.232.0/24'], 'ipv6': ['2001:7f8:54:5::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.franceix.net/en/france-ix-marseille/",
    "participants_pch":53,
    "peak_pch":"103G",
    "avg_pch":"72G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 2.3488,48.85341 ]
    },
    "properties": {
    "FIELD1":232,
    "country":"France",
    "total_by_country":20,
    "city":"Paris",
    "ixpname":"French National Internet Exchange IPv6",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': ['2001:7f8:25:1::/128']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":16,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 5.71479,45.17869 ]
    },
    "properties": {
    "FIELD1":233,
    "country":"France",
    "total_by_country":20,
    "city":"Grenoble",
    "ixpname":"GrenoblIX",
    "alternatenames":"['GrenoblIX, the Grenoble IX']",
    "prefixes":"{'ipv4': ['77.95.71.0/24', '77.95.68.0/24'], 'ipv6': ['2001:7f8:47:38::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://grenoblix.net/",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 3.05858,50.63297 ]
    },
    "properties": {
    "FIELD1":234,
    "country":"France",
    "total_by_country":20,
    "city":"Lille",
    "ixpname":"Lillix",
    "alternatenames":"['Northern France and Eurometropolis GIX']",
    "prefixes":"{'ipv4': ['193.34.197.128/25', '193.34.197.0/24'], 'ipv6': ['2001:7f8:6d::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.lillix.fr",
    "participants_pch":23,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 4.84671,45.74846 ]
    },
    "properties": {
    "FIELD1":235,
    "country":"France",
    "total_by_country":20,
    "city":"Lyon",
    "ixpname":"Lyon Internet Exchange",
    "alternatenames":"['Lyonix, the Lyon IX', 'Lyonix', 'LyonIX']",
    "prefixes":"{'ipv4': ['77.95.71.0/24'], 'ipv6': ['2001:7f8:47:47::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.lyonix.net/",
    "participants_pch":95,
    "peak_pch":"42.9G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 2.3488,48.85341 ]
    },
    "properties": {
    "FIELD1":236,
    "country":"France",
    "total_by_country":20,
    "city":"Paris",
    "ixpname":"Metropolitan Area Ethernet-Paris",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 2.3488,48.85341 ]
    },
    "properties": {
    "FIELD1":237,
    "country":"France",
    "total_by_country":20,
    "city":"Paris",
    "ixpname":"Mix Internet Exchange and Transit",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":1999,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -0.7039,49.27732 ]
    },
    "properties": {
    "FIELD1":238,
    "country":"France",
    "total_by_country":20,
    "city":"Normandy",
    "ixpname":"NormandIX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.38.0/24'], 'ipv6': ['2001:7f8:99:ffff::/64']}",
    "sources":"['pdb']",
    "url":"",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -1.55336,47.21725 ]
    },
    "properties": {
    "FIELD1":239,
    "country":"France",
    "total_by_country":20,
    "city":"Nantes",
    "ixpname":"Ouest IX",
    "alternatenames":"['OuestIX', 'Le GIX du Grand Ouest']",
    "prefixes":"{'ipv4': ['185.1.66.0/26'], 'ipv6': ['2001:7f8:34::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.ouestix.fr/",
    "participants_pch":10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 2.3488,48.85341 ]
    },
    "properties": {
    "FIELD1":240,
    "country":"France",
    "total_by_country":20,
    "city":"Paris",
    "ixpname":"Paris Internet Exchange Service",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 2.3488,48.85341 ]
    },
    "properties": {
    "FIELD1":241,
    "country":"France",
    "total_by_country":20,
    "city":"Paris",
    "ixpname":"Reunion Internet Exchange",
    "alternatenames":"['REUNIX']",
    "prefixes":"{'ipv4': ['194.57.253.128/27'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.renater.fr/spip.php?rubrique280",
    "participants_pch":10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2006,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 2.3488,48.85341 ]
    },
    "properties": {
    "FIELD1":242,
    "country":"France",
    "total_by_country":20,
    "city":"Paris",
    "ixpname":"Service for French Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['194.68.129.0/24'], 'ipv6': ['2001:7f8:4e:2::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":75,
    "peak_pch":"5G",
    "avg_pch":"8G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1995,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 1.44367,43.60426 ]
    },
    "properties": {
    "FIELD1":243,
    "country":"France",
    "total_by_country":20,
    "city":"Toulouse",
    "ixpname":"TouIX",
    "alternatenames":"['TouIX', 'Toulouse Internet eXchange']",
    "prefixes":"{'ipv4': ['91.213.236.0/24'], 'ipv6': ['2001:7f8:68::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.touix.net/",
    "participants_pch":13,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 9.45356,0.39241 ]
    },
    "properties": {
    "FIELD1":244,
    "country":"Gabon",
    "total_by_country":1,
    "city":"Libreville",
    "ixpname":"Gabon Internet Exchange",
    "alternatenames":"['Gabon Internet eXchange', 'GABIX']",
    "prefixes":"{'ipv4': ['196.223.39.0/24'], 'ipv6': ['2001:43f8:1160::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.gabix.ga",
    "participants_pch":4,
    "peak_pch":"100M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -16.67806,13.43833 ]
    },
    "properties": {
    "FIELD1":245,
    "country":"Gambia",
    "total_by_country":1,
    "city":"Serrekunda",
    "ixpname":"Serrekunda Internet Exchange Point",
    "alternatenames":"['SIXP Gambia', 'Serekunda Internet Exchange Point']",
    "prefixes":"{'ipv4': ['196.223.34.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.sixp.gm",
    "participants_pch":7,
    "peak_pch":"501M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2013,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 44.83368,41.69411 ]
    },
    "properties": {
    "FIELD1":246,
    "country":"Georgia",
    "total_by_country":1,
    "city":"Tbilisi",
    "ixpname":"Georgian Internet Exchange Point",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.80717,53.07582 ]
    },
    "properties": {
    "FIELD1":247,
    "country":"Germany",
    "total_by_country":35,
    "city":"Bremen",
    "ixpname":"BREM-IX",
    "alternatenames":"['Bremen Internet Exchange']",
    "prefixes":"{'ipv4': ['185.1.35.0/24'], 'ipv6': ['2001:7f8:92::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.brem-ix.net/",
    "participants_pch":10,
    "peak_pch":"647M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.40444,49.00937 ]
    },
    "properties": {
    "FIELD1":248,
    "country":"Germany",
    "total_by_country":35,
    "city":"Karlsruhe",
    "ixpname":"Baden-Wurttemberg Internet Exchange ",
    "alternatenames":"['Baden-W?rttemberg Internet Exchange - Karlsruhe']",
    "prefixes":"{'ipv4': ['185.1.61.0/24'], 'ipv6': ['2001:7f8:9d::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.bw-ix.net/",
    "participants_pch":6,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 13.41053,52.52437 ]
    },
    "properties": {
    "FIELD1":249,
    "country":"Germany",
    "total_by_country":35,
    "city":"Berlin",
    "ixpname":"Berlin Commercial Internet Exchange",
    "alternatenames":"['BCIX']",
    "prefixes":"{'ipv4': ['193.178.185.0/24'], 'ipv6': ['2001:7f8:19:1::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"https://www.bcix.de/",
    "participants_pch":83,
    "peak_pch":"560G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 13.33165,52.97852 ]
    },
    "properties": {
    "FIELD1":250,
    "country":"Germany",
    "total_by_country":35,
    "city":"Zehdenick",
    "ixpname":"CCCAMP-IX",
    "alternatenames":"['Chaos Communication Camp 2019 Popup IXP']",
    "prefixes":"{'ipv4': ['185.236.243.0/24'], 'ipv6': ['2a0d:eb02:4242:4242::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://bgp.wtf/cccamp19",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.80717,53.07582 ]
    },
    "properties": {
    "FIELD1":251,
    "country":"Germany",
    "total_by_country":35,
    "city":"Bremen",
    "ixpname":"Central Internet Exchange",
    "alternatenames":"['Central Internet Exchange']",
    "prefixes":"{'ipv4': ['185.1.60.0/24'], 'ipv6': ['2001:7f8:9c::/64']}",
    "sources":"['pdb']",
    "url":"http://www.centralIX.net",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 13.41053,52.52437 ]
    },
    "properties": {
    "FIELD1":252,
    "country":"Germany",
    "total_by_country":35,
    "city":"Berlin",
    "ixpname":"Community-IX",
    "alternatenames":"['Non-commercial Community Exchange']",
    "prefixes":"{'ipv4': ['185.1.74.0/26'], 'ipv6': ['2001:7f8:a5::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.community-ix.de/",
    "participants_pch":14,
    "peak_pch":"14G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 6.77616,51.22172 ]
    },
    "properties": {
    "FIELD1":253,
    "country":"Germany",
    "total_by_country":35,
    "city":"Dusseldorf",
    "ixpname":"DE-CIX Dusseldorf",
    "alternatenames":"['Deutscher Commercial Internet Exchange Dusseldorf', 'DE-CIX D?sseldorf']",
    "prefixes":"{'ipv4': ['185.1.58.0/24'], 'ipv6': ['2001:7f8:9e::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.de-cix.net/locations/germany/dusseldorf",
    "participants_pch":29,
    "peak_pch":"116G",
    "avg_pch":"76.4G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.68417,50.11552 ]
    },
    "properties": {
    "FIELD1":254,
    "country":"Germany",
    "total_by_country":35,
    "city":"Frankfurt",
    "ixpname":"DE-CIX Frankfurt",
    "alternatenames":"['Deutscher Commercial Internet Exchange']",
    "prefixes":"{'ipv4': ['80.81.192.0/21'], 'ipv6': ['2001:7f8::/64', '2001:7f8:e1::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://fra.de-cix.net",
    "participants_pch":776,
    "peak_pch":"7.59T",
    "avg_pch":"5.35T",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1995,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 9.99302,53.55073 ]
    },
    "properties": {
    "FIELD1":255,
    "country":"Germany",
    "total_by_country":35,
    "city":"Hamburg",
    "ixpname":"DE-CIX Hamburg",
    "alternatenames":"['Deutscher Commercial Internet Exchange Hamburg']",
    "prefixes":"{'ipv4': ['80.81.203.0/24'], 'ipv6': ['2001:7f8:3d::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ham.de-cix.net",
    "participants_pch":52,
    "peak_pch":"46.5G",
    "avg_pch":"29G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 11.57549,48.13743 ]
    },
    "properties": {
    "FIELD1":256,
    "country":"Germany",
    "total_by_country":35,
    "city":"Munich",
    "ixpname":"DE-CIX Munich",
    "alternatenames":"['Deutscher Commercial Internet Exchange Munich']",
    "prefixes":"{'ipv4': ['80.81.202.0/24'], 'ipv6': ['2001:7f8:44::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://muc.de-cix.net",
    "participants_pch":40,
    "peak_pch":"40.6G",
    "avg_pch":"23.9G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.68417,50.11552 ]
    },
    "properties": {
    "FIELD1":257,
    "country":"Germany",
    "total_by_country":35,
    "city":"Frankfurt",
    "ixpname":"Deutscher Commercial Internet Exchange DE-CIX Frankfurt",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['80.81.200.0/24', '80.81.192.0/21'], 'ipv6': ['2001:7f8::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":1995,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 7.466,51.51494 ]
    },
    "properties": {
    "FIELD1":258,
    "country":"Germany",
    "total_by_country":35,
    "city":"Dortmund",
    "ixpname":"Dortmund Internet exchange",
    "alternatenames":"['DO-IX', 'Dortmund Internet eXchange']",
    "prefixes":"{'ipv4': ['185.1.18.0/24'], 'ipv6': ['2001:67c:2b9c::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.do-ix.net",
    "participants_pch":9,
    "peak_pch":"25.2G",
    "avg_pch":"13K",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 11.07752,49.45421 ]
    },
    "properties": {
    "FIELD1":259,
    "country":"Germany",
    "total_by_country":35,
    "city":"Nuremberg",
    "ixpname":"E-IX",
    "alternatenames":"['ElectroNIX']",
    "prefixes":"{'ipv4': [], 'ipv6': ['2602:fed2:7706::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://e-ix.network",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.68417,50.11552 ]
    },
    "properties": {
    "FIELD1":260,
    "country":"Germany",
    "total_by_country":35,
    "city":"Frankfurt",
    "ixpname":"Equinix Frankfurt",
    "alternatenames":"['Equinix Internet Exchange Frankfurt']",
    "prefixes":"{'ipv4': ['185.1.102.0/24'], 'ipv6': ['2001:7f8:bd::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.equinix.de/services/interconnection-connectivity/internet-exchange/",
    "participants_pch":50,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 13.41053,52.52437 ]
    },
    "properties": {
    "FIELD1":261,
    "country":"Germany",
    "total_by_country":35,
    "city":"Berlin",
    "ixpname":"European Commercial Internet Exchange Berlin",
    "alternatenames":"['ECIX-BER', 'ECIX Berlin']",
    "prefixes":"{'ipv4': ['194.9.117.0/24'], 'ipv6': ['2001:7f8:8:5::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.ecix.net/",
    "participants_pch":56,
    "peak_pch":"286G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 6.77616,51.22172 ]
    },
    "properties": {
    "FIELD1":262,
    "country":"Germany",
    "total_by_country":35,
    "city":"Dusseldorf",
    "ixpname":"European Commercial Internet Exchange Dusseldorf",
    "alternatenames":"['ECIX-DUS', 'ECIX Dusseldorf', 'European Commercial Internet Exchange Duesseldorf']",
    "prefixes":"{'ipv4': ['194.146.118.0/24'], 'ipv6': ['2001:7f8:8::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.ecix.net/",
    "participants_pch":113,
    "peak_pch":"22.9G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.68417,50.11552 ]
    },
    "properties": {
    "FIELD1":263,
    "country":"Germany",
    "total_by_country":35,
    "city":"Frankfurt",
    "ixpname":"European Commercial Internet Exchange Frankfurt",
    "alternatenames":"['ECIX Frankfurt', 'ECIX-FRA']",
    "prefixes":"{'ipv4': ['62.69.146.0/23'], 'ipv6': ['2001:7f8:8:20::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.ecix.net",
    "participants_pch":106,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 9.99302,53.55073 ]
    },
    "properties": {
    "FIELD1":264,
    "country":"Germany",
    "total_by_country":35,
    "city":"Hamburg",
    "ixpname":"European Commercial Internet Exchange Hamburg",
    "alternatenames":"['ECIX Hamburg', 'ECIX-HAM']",
    "prefixes":"{'ipv4': ['193.42.155.0/24'], 'ipv6': ['2001:7f8:8:10::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.ecix.net/",
    "participants_pch":59,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 11.57549,48.13743 ]
    },
    "properties": {
    "FIELD1":265,
    "country":"Germany",
    "total_by_country":35,
    "city":"Munich",
    "ixpname":"European Commercial Internet Exchange Munich",
    "alternatenames":"['ECIX-MUC / INXS by ecix', 'INXS by ecix', 'INXS / ECIX-MUC']",
    "prefixes":"{'ipv4': ['194.59.190.0/24'], 'ipv6': ['2001:7f8:2c:1000::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.ecix.net",
    "participants_pch":52,
    "peak_pch":"20G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1994,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.68417,50.11552 ]
    },
    "properties": {
    "FIELD1":266,
    "country":"Germany",
    "total_by_country":35,
    "city":"Frankfurt",
    "ixpname":"Frankfurt Network Access Point",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 11.07752,49.45421 ]
    },
    "properties": {
    "FIELD1":267,
    "country":"Germany",
    "total_by_country":35,
    "city":"Nuremberg",
    "ixpname":"IXP NUR",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': ['2a0c:3b80:4040:4445::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.ixp.cat",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.68417,50.11552 ]
    },
    "properties": {
    "FIELD1":268,
    "country":"Germany",
    "total_by_country":35,
    "city":"Frankfurt",
    "ixpname":"KleyReX Internet Exchange",
    "alternatenames":"['KleyReX']",
    "prefixes":"{'ipv4': ['193.189.82.0/23'], 'ipv6': ['2001:7f8:33::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.kleyrex.net/",
    "participants_pch":138,
    "peak_pch":"3.06G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.68417,50.11552 ]
    },
    "properties": {
    "FIELD1":269,
    "country":"Germany",
    "total_by_country":35,
    "city":"Frankfurt",
    "ixpname":"LNK-IX - Frankfurt",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.128.0/24'], 'ipv6': ['2001:7f8:d3::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://ix.lnk.ro",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.68417,50.11552 ]
    },
    "properties": {
    "FIELD1":270,
    "country":"Germany",
    "total_by_country":35,
    "city":"Frankfurt",
    "ixpname":"LocIX",
    "alternatenames":"['LocIX Internet Exchange']",
    "prefixes":"{'ipv4': ['185.1.119.0/24', '192.168.50.0/24'], 'ipv6': ['2a07:1c44:61f0::/48', '2a07:1c44:61f0::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://locix.online",
    "participants_pch":131,
    "peak_pch":"1.9G",
    "avg_pch":"1.1G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 6.77616,51.22172 ]
    },
    "properties": {
    "FIELD1":271,
    "country":"Germany",
    "total_by_country":35,
    "city":"Dusseldorf",
    "ixpname":"Local Internet Exchange Dusseldorf",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":32,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.68417,50.11552 ]
    },
    "properties": {
    "FIELD1":272,
    "country":"Germany",
    "total_by_country":35,
    "city":"Frankfurt",
    "ixpname":"MAE-Frankfurt",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.65027,49.87167 ]
    },
    "properties": {
    "FIELD1":273,
    "country":"Germany",
    "total_by_country":35,
    "city":"Darmstadt",
    "ixpname":"Metropolitan Area Network Darmstadt",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 7.62571,51.96236 ]
    },
    "properties": {
    "FIELD1":274,
    "country":"Germany",
    "total_by_country":35,
    "city":"Munster",
    "ixpname":"Munster Internet Exchange",
    "alternatenames":"['MS-IX']",
    "prefixes":"{'ipv4': ['185.1.144.0/24'], 'ipv6': ['2001:7f8:df::/64', '2a0d:1a47:ffff::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ms-ix.net/",
    "participants_pch":7,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 11.07752,49.45421 ]
    },
    "properties": {
    "FIELD1":275,
    "country":"Germany",
    "total_by_country":35,
    "city":"Nuremberg",
    "ixpname":"Nuernberger Internet Exchange",
    "alternatenames":"['Nuernberger Internet Exchange [N-IX.de]']",
    "prefixes":"{'ipv4': ['195.85.217.0/24'], 'ipv6': ['2001:7f8:29:1::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.n-ix.net",
    "participants_pch":45,
    "peak_pch":"9.5G",
    "avg_pch":"7.4G",
    "status_pch":"active",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 6.77616,51.22172 ]
    },
    "properties": {
    "FIELD1":276,
    "country":"Germany",
    "total_by_country":35,
    "city":"Dusseldorf",
    "ixpname":"OpenCarrier e.G. Member IX Dusseldorf",
    "alternatenames":"['OpenCarrier eG Member IX Duesseldorf ']",
    "prefixes":"{'ipv4': ['194.54.92.0/25'], 'ipv6': ['2001:7f8:3a:e201::/64']}",
    "sources":"['pdb']",
    "url":"http://www.opencarrier.eu/",
    "participants_pch":23,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.68417,50.11552 ]
    },
    "properties": {
    "FIELD1":277,
    "country":"Germany",
    "total_by_country":35,
    "city":"Frankfurt",
    "ixpname":"OpenCarrier e.G. Member IX Frankfurt",
    "alternatenames":"['OpenCarrier eG Member-IX Frankfurt']",
    "prefixes":"{'ipv4': ['194.54.93.0/25'], 'ipv6': ['2001:7f8:3a:e202::/64']}",
    "sources":"['pdb']",
    "url":"http://www.opencarrier.eu/",
    "participants_pch":23,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 9.17702,48.78232 ]
    },
    "properties": {
    "FIELD1":278,
    "country":"Germany",
    "total_by_country":35,
    "city":"Stuttgart",
    "ixpname":"Stuttgarter Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['193.138.31.0/24'], 'ipv6': ['2001:504:16::/48']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":25,
    "peak_pch":"1.75G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2005,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 7.14816,51.25627 ]
    },
    "properties": {
    "FIELD1":279,
    "country":"Germany",
    "total_by_country":35,
    "city":"Wuppertal",
    "ixpname":"United Peering",
    "alternatenames":"['United Peering', 'United Peering - free and open peering (UP-IXP)']",
    "prefixes":"{'ipv4': ['185.1.54.0/24'], 'ipv6': ['2001:7f8:95::/48']}",
    "sources":"['pdb', 'pch']",
    "url":"https://united-peering.net/",
    "participants_pch":13,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.68417,50.11552 ]
    },
    "properties": {
    "FIELD1":280,
    "country":"Germany",
    "total_by_country":35,
    "city":"Frankfurt",
    "ixpname":"XchangePoint Frankfurt IPP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 9.99302,53.55073 ]
    },
    "properties": {
    "FIELD1":281,
    "country":"Germany",
    "total_by_country":35,
    "city":"Hamburg",
    "ixpname":"XchangePoint Hamburg IPP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -0.1969,5.55602 ]
    },
    "properties": {
    "FIELD1":282,
    "country":"Ghana",
    "total_by_country":1,
    "city":"Accra",
    "ixpname":"Ghana Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['196.201.2.0/24', '196.49.14.0/24'], 'ipv6': ['2001:43f8:ae0::/48', '2001:43f8:ae1::/48']}",
    "sources":"['he']",
    "url":"http://www.gixa.org.gh",
    "participants_pch":21,
    "peak_pch":"4.8G",
    "avg_pch":"30G",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2005,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 23.72784,37.98376 ]
    },
    "properties": {
    "FIELD1":283,
    "country":"Greece",
    "total_by_country":2,
    "city":"Athens",
    "ixpname":"GR-IX Athens",
    "alternatenames":"['Greek Internet Exchange - Athens', 'GR-IX Athens']",
    "prefixes":"{'ipv4': ['176.126.38.0/25'], 'ipv6': ['2001:7f8:6e::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.gr-ix.gr/",
    "participants_pch":41,
    "peak_pch":"114G",
    "avg_pch":"76G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 22.93086,40.64361 ]
    },
    "properties": {
    "FIELD1":284,
    "country":"Greece",
    "total_by_country":2,
    "city":"Thessaloniki",
    "ixpname":"GR-IX Thessaloniki",
    "alternatenames":"['Greek Internet Exchange - Thessaloniki', 'GR-IX Thessaloniki']",
    "prefixes":"{'ipv4': ['185.1.123.0/24'], 'ipv6': ['2001:7f8:ce::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.gr-ix.gr/",
    "participants_pch":12,
    "peak_pch":"1.6G",
    "avg_pch":"940M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -61.75226,12.05288 ]
    },
    "properties": {
    "FIELD1":285,
    "country":"Grenada",
    "total_by_country":1,
    "city":"St. Georges",
    "ixpname":"Grenada Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.126.244.0/24'], 'ipv6': ['2001:1808:1:1::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":9,
    "peak_pch":"1.55G",
    "avg_pch":"780M",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 144.78138,13.48773 ]
    },
    "properties": {
    "FIELD1":286,
    "country":"Guam",
    "total_by_country":3,
    "city":"Tumon",
    "ixpname":"GOREX",
    "alternatenames":"['Guam Open Research & Education Exchange']",
    "prefixes":"{'ipv4': ['192.35.145.0/24'], 'ipv6': ['2604:8ac0::/32']}",
    "sources":"['pdb', 'he']",
    "url":"https://gorex.uog.edu",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 144.78143,13.48754 ]
    },
    "properties": {
    "FIELD1":287,
    "country":"Guam",
    "total_by_country":3,
    "city":"Guam",
    "ixpname":"Guam Internet Exchange",
    "alternatenames":"['GU-IX']",
    "prefixes":"{'ipv4': ['202.128.12.0/26'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.gu-ix.net",
    "participants_pch":5,
    "peak_pch":"1G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 144.80109,13.44761 ]
    },
    "properties": {
    "FIELD1":288,
    "country":"Guam",
    "total_by_country":3,
    "city":"Mangilao",
    "ixpname":"Mariana Islands Internet Exchange",
    "alternatenames":"['Mariana Islands Internet Exchange']",
    "prefixes":"{'ipv4': ['103.115.192.0/23'], 'ipv6': ['2001:de9:4000::/48']}",
    "sources":"['pdb', 'he']",
    "url":"https://mariix.net",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -13.67729,9.53795 ]
    },
    "properties": {
    "FIELD1":289,
    "country":"Guinea",
    "total_by_country":1,
    "city":"Conakry",
    "ixpname":"IXP-GUINEE",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['196.60.38.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -52.33333,4.93333 ]
    },
    "properties": {
    "FIELD1":290,
    "country":"Guyana",
    "total_by_country":1,
    "city":"Cayenne",
    "ixpname":"Guyanix",
    "alternatenames":"['Guyanix']",
    "prefixes":"{'ipv4': ['194.57.235.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.renater.fr/guyanix?lang=fr",
    "participants_pch":9,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -72.33881,18.54349 ]
    },
    "properties": {
    "FIELD1":291,
    "country":"Haiti",
    "total_by_country":1,
    "city":"Port au Prince",
    "ixpname":"AHTIC Internet Exchange Point",
    "alternatenames":"['AIX', 'HIX Haiti', 'Haiti Internet Exchange']",
    "prefixes":"{'ipv4': ['200.0.18.0/24'], 'ipv6': ['2001:13c7:6003::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"",
    "participants_pch":9,
    "peak_pch":"2.4G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2009,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -87.20681,14.0818 ]
    },
    "properties": {
    "FIELD1":292,
    "country":"Honduras",
    "total_by_country":1,
    "city":"Tegucigalpa",
    "ixpname":"IXP-HN Puntos de Intercambio de Tr?fico ? Honduras",
    "alternatenames":"['Internet Exchange Point Honduras', 'IXP-HN']",
    "prefixes":"{'ipv4': ['181.210.17.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.ixp.hn/",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2015,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 113.9400016,22.3353826 ]
    },
    "properties": {
    "FIELD1":293,
    "country":"Hong Kong",
    "total_by_country":8,
    "city":"Hong Kong",
    "ixpname":"AMS-IX Hong Kong",
    "alternatenames":"['Amsterdam Internet Exchange Hong Kong']",
    "prefixes":"{'ipv4': ['103.247.139.0/24', '103.247.139.0/25'], 'ipv6': ['2001:df0:296::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.ams-ix.hk",
    "participants_pch":43,
    "peak_pch":"34.9G",
    "avg_pch":"26.3G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 113.9400016,22.3353826 ]
    },
    "properties": {
    "FIELD1":294,
    "country":"Hong Kong",
    "total_by_country":8,
    "city":"Hong Kong",
    "ixpname":"BBIX Hong Kong",
    "alternatenames":"['BroadBand Internet eXchange Hong Kong']",
    "prefixes":"{'ipv4': ['103.203.158.0/23'], 'ipv6': ['2403:c780:b800:bb00::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.bbix.net/en/",
    "participants_pch":27,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 113.9400016,22.3353826 ]
    },
    "properties": {
    "FIELD1":295,
    "country":"Hong Kong",
    "total_by_country":8,
    "city":"Hong Kong",
    "ixpname":"Equinix Hong Kong",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['119.27.63.0/24', '36.255.56.0/22'], 'ipv6': ['2001:de8:7::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.equinix.com",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 113.9400016,22.3353826 ]
    },
    "properties": {
    "FIELD1":296,
    "country":"Hong Kong",
    "total_by_country":8,
    "city":"Hong Kong",
    "ixpname":"Hong Kong Internet Exchange",
    "alternatenames":"['HKIX']",
    "prefixes":"{'ipv4': ['202.40.160.0/23', '123.255.88.0/21'], 'ipv6': ['2001:7fa:0:1::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"https://www.hkix.net/",
    "participants_pch":293,
    "peak_pch":"1.21T",
    "avg_pch":"852G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":1995,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 113.9400016,22.3353826 ]
    },
    "properties": {
    "FIELD1":297,
    "country":"Hong Kong",
    "total_by_country":8,
    "city":"Hong Kong",
    "ixpname":"LightIX HK",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['103.135.101.224/27'], 'ipv6': ['2404:7ac0:e:20::/64']}",
    "sources":"['he']",
    "url":"https://www.lightvm.net/ixchange",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 113.9400016,22.3353826 ]
    },
    "properties": {
    "FIELD1":298,
    "country":"Hong Kong",
    "total_by_country":8,
    "city":"Hong Kong",
    "ixpname":"Megaport Hong Kong",
    "alternatenames":"['MegaIX Hong Kong']",
    "prefixes":"{'ipv4': ['103.48.48.0/23'], 'ipv6': ['2001:def::/48']}",
    "sources":"['pch', 'he']",
    "url":"http://www.megaport.com",
    "participants_pch":7,
    "peak_pch":"180M",
    "avg_pch":"102M",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 113.9400016,22.3353826 ]
    },
    "properties": {
    "FIELD1":299,
    "country":"Hong Kong",
    "total_by_country":8,
    "city":"Hong Kong",
    "ixpname":"MoeIX Hong Kong",
    "alternatenames":"['MoeQing Internet Exchange - Hong Kong']",
    "prefixes":"{'ipv4': [], 'ipv6': ['2a0c:b641:70:bbbb::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.moeix.online/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 113.9400016,22.3353826 ]
    },
    "properties": {
    "FIELD1":300,
    "country":"Hong Kong",
    "total_by_country":8,
    "city":"Hong Kong",
    "ixpname":"iAdvantage Internet Exchange",
    "alternatenames":"['iAdvantage Internet Exchange', 'IAIX']",
    "prefixes":"{'ipv4': ['210.184.127.0/24'], 'ipv6': ['2403:2400:1100::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.iadvantage.net",
    "participants_pch":202,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 72.88261,19.07283 ]
    },
    "properties": {
    "FIELD1":301,
    "country":"India",
    "total_by_country":21,
    "city":"Mumbai",
    "ixpname":"AMS-IX India",
    "alternatenames":"['Amsterdam Internet Exchange India']",
    "prefixes":"{'ipv4': ['223.31.200.0/24'], 'ipv6': ['2001:e48:44:100b::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ams-ix.in/",
    "participants_pch":10,
    "peak_pch":"37G",
    "avg_pch":"21.5G",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2017,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 77.23149,28.65195 ]
    },
    "properties": {
    "FIELD1":302,
    "country":"India",
    "total_by_country":21,
    "city":"New Delhi",
    "ixpname":"ANI Peering Exchange",
    "alternatenames":"['ANI-IX Delhi']",
    "prefixes":"{'ipv4': ['163.53.87.0/24', '45.248.174.0/24', '45.248.172.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://aninetwork.in/aniix/index.html",
    "participants_pch":15,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 77.75,20.93333 ]
    },
    "properties": {
    "FIELD1":303,
    "country":"India",
    "total_by_country":21,
    "city":"Amaravati",
    "ixpname":"Amaravati Internet Exchange",
    "alternatenames":"['AMR-IX']",
    "prefixes":"{'ipv4': ['103.115.147.0/24'], 'ipv6': ['2001:de8:c000::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.amr-ix.net",
    "participants_pch":4,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 72.88261,19.07283 ]
    },
    "properties": {
    "FIELD1":304,
    "country":"India",
    "total_by_country":21,
    "city":"Mumbai",
    "ixpname":"Bharat IX - Mumbai",
    "alternatenames":"['Bharat Internet Exchange in Mumbai']",
    "prefixes":"{'ipv4': ['103.105.218.0/24'], 'ipv6': ['2001:de8:4000::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.bharatix.net",
    "participants_pch":10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2017,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 80.27847,13.08784 ]
    },
    "properties": {
    "FIELD1":305,
    "country":"India",
    "total_by_country":21,
    "city":"Chennai",
    "ixpname":"Extreme IX Chennai",
    "alternatenames":"['ExtremeIX Chennai']",
    "prefixes":"{'ipv4': ['45.120.251.0/24'], 'ipv6': ['2001:df2:1900:3::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://extreme-ix.org",
    "participants_pch":25,
    "peak_pch":"10G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2016,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 78.45636,17.38405 ]
    },
    "properties": {
    "FIELD1":306,
    "country":"India",
    "total_by_country":21,
    "city":"Hyderabad",
    "ixpname":"Extreme IX Hyderabad",
    "alternatenames":"['ExtremeIX Hyderabad']",
    "prefixes":"{'ipv4': ['103.77.110.0/24'], 'ipv6': ['2001:df2:1900:4::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://extreme-ix.org",
    "participants_pch":6,
    "peak_pch":"10G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2016,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 88.36304,22.56263 ]
    },
    "properties": {
    "FIELD1":307,
    "country":"India",
    "total_by_country":21,
    "city":"Kolkata",
    "ixpname":"Extreme IX Kolkata",
    "alternatenames":"['ExtremeIX Kolkata']",
    "prefixes":"{'ipv4': ['45.120.249.0/24'], 'ipv6': ['2001:df2:1900:5::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://extreme-ix.org",
    "participants_pch":3,
    "peak_pch":"6G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 72.88261,19.07283 ]
    },
    "properties": {
    "FIELD1":308,
    "country":"India",
    "total_by_country":21,
    "city":"Mumbai",
    "ixpname":"Extreme IX Mumbai",
    "alternatenames":"['ExtremeIX Mumbai']",
    "prefixes":"{'ipv4': ['103.77.108.0/24'], 'ipv6': ['2001:df2:1900:2::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://extreme-ix.org",
    "participants_pch":147,
    "peak_pch":"200G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2016,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 77.23149,28.65195 ]
    },
    "properties": {
    "FIELD1":309,
    "country":"India",
    "total_by_country":21,
    "city":"New Delhi",
    "ixpname":"Extreme IX New Delhi",
    "alternatenames":"['Extreme IX', 'ExtremeIX Delhi', 'Extreme IX Delhi']",
    "prefixes":"{'ipv4': ['45.120.248.0/24'], 'ipv6': ['2001:df2:1900:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://extreme-ix.org",
    "participants_pch":83,
    "peak_pch":"200G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2016,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 88.36304,22.56263 ]
    },
    "properties": {
    "FIELD1":310,
    "country":"India",
    "total_by_country":21,
    "city":"Kolkata",
    "ixpname":"IIFON IX Kolkata",
    "alternatenames":"['India Internet Foundation']",
    "prefixes":"{'ipv4': ['103.74.224.0/24'], 'ipv6': ['2001:ded:8000::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://iifon.org",
    "participants_pch":4,
    "peak_pch":"999M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2016,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 72.88261,19.07283 ]
    },
    "properties": {
    "FIELD1":311,
    "country":"India",
    "total_by_country":21,
    "city":"Mumbai",
    "ixpname":"JetPeer IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['115.42.32.0/24'], 'ipv6': []}",
    "sources":"['he']",
    "url":"http://www.jetpeer.in",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"South Asia",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 72.88261,19.07283 ]
    },
    "properties": {
    "FIELD1":312,
    "country":"India",
    "total_by_country":21,
    "city":"Mumbai",
    "ixpname":"Mumbai Internet Exchange (Mumbai IX)",
    "alternatenames":"['Mumbai IX', 'Mumbai Internet Exchange powered by DE-CIX (fka Mumbai Convergence Hub)']",
    "prefixes":"{'ipv4': ['103.27.170.0/24'], 'ipv6': ['2401:7500:fff6::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.mumbai-ix.net",
    "participants_pch":156,
    "peak_pch":"858G",
    "avg_pch":"255K",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2014,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 72.58727,23.02579 ]
    },
    "properties": {
    "FIELD1":313,
    "country":"India",
    "total_by_country":21,
    "city":"Ahmedabad",
    "ixpname":"National Internet Exchange of India - Ahmedabad",
    "alternatenames":"['NIXI Ahmedabad']",
    "prefixes":"{'ipv4': ['218.100.49.128/26'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.nixi.in",
    "participants_pch":4,
    "peak_pch":"20K",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2008,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 77.59369,12.97194 ]
    },
    "properties": {
    "FIELD1":314,
    "country":"India",
    "total_by_country":21,
    "city":"Bangalore",
    "ixpname":"National Internet Exchange of India - Bangalore",
    "alternatenames":"['NIXI Bangalore']",
    "prefixes":"{'ipv4': ['218.100.49.0/26'], 'ipv6': ['2001:de8:1:4::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.nixi.in",
    "participants_pch":4,
    "peak_pch":"1.57M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2008,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 91.7458,26.1844 ]
    },
    "properties": {
    "FIELD1":315,
    "country":"India",
    "total_by_country":21,
    "city":"Guwahati",
    "ixpname":"National Internet Exchange of India - Guwahati",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":7,
    "peak_pch":"103M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 78.45636,17.38405 ]
    },
    "properties": {
    "FIELD1":316,
    "country":"India",
    "total_by_country":21,
    "city":"Hyderabad",
    "ixpname":"National Internet Exchange of India - Hyderabad",
    "alternatenames":"['National Internet eXchange of India ', 'NIXI Hyderabad']",
    "prefixes":"{'ipv4': ['218.100.49.64/26'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.nixi.in",
    "participants_pch":8,
    "peak_pch":"2.1M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2008,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 88.36304,22.56263 ]
    },
    "properties": {
    "FIELD1":317,
    "country":"India",
    "total_by_country":21,
    "city":"Kolkata",
    "ixpname":"National Internet Exchange of India - Kolkata",
    "alternatenames":"['NIXI Kolkata']",
    "prefixes":"{'ipv4': ['218.100.48.192/26'], 'ipv6': ['2001:de8:1:5::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://nixi.in",
    "participants_pch":10,
    "peak_pch":"7.56M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2003,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 72.88261,19.07283 ]
    },
    "properties": {
    "FIELD1":318,
    "country":"India",
    "total_by_country":21,
    "city":"Mumbai",
    "ixpname":"National Internet Exchange of India - Mumbai",
    "alternatenames":"['National Internet eXchange of India', 'NIXI Mumbai']",
    "prefixes":"{'ipv4': ['218.100.48.64/26'], 'ipv6': ['2001:de8:1:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.nixi.in",
    "participants_pch":44,
    "peak_pch":"5.37G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2003,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 77.23149,28.65195 ]
    },
    "properties": {
    "FIELD1":319,
    "country":"India",
    "total_by_country":21,
    "city":"New Delhi",
    "ixpname":"National Internet Exchange of India - New Delhi",
    "alternatenames":"['NIXI Delhi', 'National Internet eXchange of India']",
    "prefixes":"{'ipv4': ['218.100.48.0/26'], 'ipv6': ['2001:de8:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.nixi.in",
    "participants_pch":34,
    "peak_pch":"1.18G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2003,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 80.27847,13.08784 ]
    },
    "properties": {
    "FIELD1":320,
    "country":"India",
    "total_by_country":21,
    "city":"Chennai",
    "ixpname":"REDIX Chennai",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['103.129.155.0/24'], 'ipv6': ['2001:df6:7900::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://redix.org",
    "participants_pch":4,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 80.45729,16.29974 ]
    },
    "properties": {
    "FIELD1":321,
    "country":"India",
    "total_by_country":21,
    "city":"Guntur",
    "ixpname":"Remki Internet Exchange",
    "alternatenames":"['Remki Internet Exchange (RIX) - Remki IX']",
    "prefixes":"{'ipv4': ['103.111.7.0/24'], 'ipv6': ['2001:df5:b500:7::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://internet-exchange.remki.net",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"South Asia",
    "year":2017,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 115.21667,-8.65 ]
    },
    "properties": {
    "FIELD1":322,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Denpasar",
    "ixpname":"Bali Internet eXchange - Denpasar",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":20,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 104.02491,1.14937 ]
    },
    "properties": {
    "FIELD1":323,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Batam",
    "ixpname":"Batam Internet Exchange",
    "alternatenames":"['BatamIX']",
    "prefixes":"{'ipv4': ['27.124.87.0/24'], 'ipv6': ['2402:d680:1000:4::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://batamix.net",
    "participants_pch":13,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2019,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 106.84513,-6.21462 ]
    },
    "properties": {
    "FIELD1":324,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Jakarta",
    "ixpname":"Biznet Internet Exchange",
    "alternatenames":"['BIX Jakarta']",
    "prefixes":"{'ipv4': ['218.100.41.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"",
    "participants_pch":39,
    "peak_pch":"5G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2006,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 106.84513,-6.21462 ]
    },
    "properties": {
    "FIELD1":325,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Jakarta",
    "ixpname":"CDIX",
    "alternatenames":"['Cyber Data Internet Xchange']",
    "prefixes":"{'ipv4': ['103.30.172.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"http://www.cyberdc.net/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 110.36472,-7.80139 ]
    },
    "properties": {
    "FIELD1":326,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Yogyakarta",
    "ixpname":"CitranetIX",
    "alternatenames":"['Citranet Internet Exchange (CIX)']",
    "prefixes":"{'ipv4': ['103.101.136.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.citra.net.id/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 106.84513,-6.21462 ]
    },
    "properties": {
    "FIELD1":327,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Jakarta",
    "ixpname":"Cyber 2 Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 112.75083,-7.24917 ]
    },
    "properties": {
    "FIELD1":328,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Surabaya",
    "ixpname":"IIX Jawa Timur",
    "alternatenames":"['IIX-Surabaya']",
    "prefixes":"{'ipv4': ['218.100.32.0/24'], 'ipv6': ['2001:7fa:2:50ba::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.iix.net.id",
    "participants_pch":47,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 107.60694,-6.92222 ]
    },
    "properties": {
    "FIELD1":329,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Bandung",
    "ixpname":"IIX-Jabar",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":7,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 105.26111,-5.42917 ]
    },
    "properties": {
    "FIELD1":330,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Bandar Lampung",
    "ixpname":"IIX-Lampung",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":6,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 101.44167,0.51667 ]
    },
    "properties": {
    "FIELD1":331,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Pekanbaru",
    "ixpname":"IIX-RI",
    "alternatenames":"['Riau Internet Exchange Point']",
    "prefixes":"{'ipv4': ['103.54.2.0/23'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.wanxp.net.id",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 104.02491,1.14937 ]
    },
    "properties": {
    "FIELD1":332,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Batam",
    "ixpname":"IXP BAT",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': ['2a0c:3b80:4040:4944::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.ixp.cat",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 106.84513,-6.21462 ]
    },
    "properties": {
    "FIELD1":333,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Jakarta",
    "ixpname":"IndonesiaEP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 106.84513,-6.21462 ]
    },
    "properties": {
    "FIELD1":334,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Jakarta",
    "ixpname":"Indonesian Internet Exchange - Jakarta",
    "alternatenames":"['IIX', 'Indonesia Internet Exchange', 'IIX-Jakarta']",
    "prefixes":"{'ipv4': ['103.28.74.0/23', '218.100.4.0/24'], 'ipv6': ['2001:7fa:2::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.iix.net.id",
    "participants_pch":252,
    "peak_pch":"3.4G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":1997,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 106.84513,-6.21462 ]
    },
    "properties": {
    "FIELD1":335,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Jakarta",
    "ixpname":"Jakarta Internet Exchange",
    "alternatenames":"['JKT-IX']",
    "prefixes":"{'ipv4': ['119.11.184.0/24'], 'ipv6': ['2404:c8:0:a::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.glc.ntt.com/en/services/service-in-indonesia/data-center/internet-exchange.html",
    "participants_pch":9,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 106.84513,-6.21462 ]
    },
    "properties": {
    "FIELD1":336,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Jakarta",
    "ixpname":"Matrix Cable System Internet Exchange",
    "alternatenames":"['Matrix Cable Internet eXchange', 'MCIX']",
    "prefixes":"{'ipv4': ['119.110.115.0/24', '119.110.116.0/23', '119.110.118.0/24'], 'ipv6': ['2404:c000:4004::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.nap.net.id",
    "participants_pch":68,
    "peak_pch":"10G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2011,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 106.84513,-6.21462 ]
    },
    "properties": {
    "FIELD1":337,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Jakarta",
    "ixpname":"NEX Internet Exchange",
    "alternatenames":"['Cyber 2 Internet Exchange', 'C2IX']",
    "prefixes":"{'ipv4': ['218.100.72.0/23'], 'ipv6': ['2001:df0:b1:72::/63']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.cyber2dc.com",
    "participants_pch":12,
    "peak_pch":"495M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2010,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 106.84513,-6.21462 ]
    },
    "properties": {
    "FIELD1":338,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Jakarta",
    "ixpname":"OpenIXP Internet exchange Point",
    "alternatenames":"['National Inter Connection Exchange (NiCE)', 'OpenIXP / NiCE']",
    "prefixes":"{'ipv4': ['218.100.27.0/24', '218.100.36.0/24'], 'ipv6': ['2001:7fa:f::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.openixp.net",
    "participants_pch":1097,
    "peak_pch":"1.03T",
    "avg_pch":"600G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2005,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 106.84513,-6.21462 ]
    },
    "properties": {
    "FIELD1":339,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Jakarta",
    "ixpname":"PT. Cyberindo Aditama",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":2008,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 110.36472,-7.80139 ]
    },
    "properties": {
    "FIELD1":341,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Yogyakarta",
    "ixpname":"Universitas Negeri Yogyakarta Internet Exchange Point",
    "alternatenames":"['Universitas Negeri Yogyakarta Internet Exchange Point']",
    "prefixes":"{'ipv4': ['101.203.169.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://puskom.uny.ac.id",
    "participants_pch":4,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 115.21667,-8.65 ]
    },
    "properties": {
    "FIELD1":342,
    "country":"Indonesia",
    "total_by_country":21,
    "city":"Denpasar",
    "ixpname":"cloudXchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":14,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":2019,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 59.60567,36.29807 ]
    },
    "properties": {
    "FIELD1":343,
    "country":"Iran",
    "total_by_country":4,
    "city":"Mashhad",
    "ixpname":"Mashhad IX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Middle East & North Africa",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 52.53113,29.61031 ]
    },
    "properties": {
    "FIELD1":344,
    "country":"Iran",
    "total_by_country":4,
    "city":"Shiraz",
    "ixpname":"Shiraz IX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Middle East & North Africa",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 46.2919,38.08 ]
    },
    "properties": {
    "FIELD1":345,
    "country":"Iran",
    "total_by_country":4,
    "city":"Tabriz",
    "ixpname":"Tabriz IX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Middle East & North Africa",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 51.42151,35.69439 ]
    },
    "properties": {
    "FIELD1":346,
    "country":"Iran",
    "total_by_country":4,
    "city":"Tehran",
    "ixpname":"Tehran IX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Middle East & North Africa",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -6.24889,53.33306 ]
    },
    "properties": {
    "FIELD1":347,
    "country":"Ireland",
    "total_by_country":7,
    "city":"Dublin",
    "ixpname":"Equinix Dublin",
    "alternatenames":"['Equinix Internet Exchange Dublin']",
    "prefixes":"{'ipv4': ['185.1.109.0/24'], 'ipv6': ['2001:7f8:c3::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.equinix.ie/services/interconnection-connectivity/internet-exchange/",
    "participants_pch":10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -8.47061,51.89797 ]
    },
    "properties": {
    "FIELD1":348,
    "country":"Ireland",
    "total_by_country":7,
    "city":"Cork",
    "ixpname":"INEX Cork",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.69.0/24'], 'ipv6': ['2001:7f8:18:210::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.inex.ie",
    "participants_pch":7,
    "peak_pch":"360G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -6.24889,53.33306 ]
    },
    "properties": {
    "FIELD1":349,
    "country":"Ireland",
    "total_by_country":7,
    "city":"Dublin",
    "ixpname":"INEX Dublin",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['194.88.240.0/25', '194.88.241.0/26', '194.88.241.64/26', '185.6.36.0/23'], 'ipv6': ['2001:7f8:18::/64', '2001:7f8:18:12::/64', '2001:7f8:18:70::/64', '2001:7f8:18:72::/64']}",
    "sources":"['he']",
    "url":"https://www.inex.ie/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -6.24889,53.33306 ]
    },
    "properties": {
    "FIELD1":350,
    "country":"Ireland",
    "total_by_country":7,
    "city":"Dublin",
    "ixpname":"INEX LAN1",
    "alternatenames":"['Internet Neutral Exchange Association CLG']",
    "prefixes":"{'ipv4': ['185.6.36.0/23'], 'ipv6': ['2001:7f8:18::/64']}",
    "sources":"['pdb']",
    "url":"https://www.inex.ie/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -6.24889,53.33306 ]
    },
    "properties": {
    "FIELD1":351,
    "country":"Ireland",
    "total_by_country":7,
    "city":"Dublin",
    "ixpname":"INEX LAN2",
    "alternatenames":"['Internet Neutral Exchange Association CLG']",
    "prefixes":"{'ipv4': ['194.88.240.0/25'], 'ipv6': ['2001:7f8:18:12::/64']}",
    "sources":"['pdb']",
    "url":"https://www.inex.ie/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -6.24889,53.33306 ]
    },
    "properties": {
    "FIELD1":352,
    "country":"Ireland",
    "total_by_country":7,
    "city":"Dublin",
    "ixpname":"Internet Neutral Exchange Association Limited",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['194.88.240.0/25', '185.6.36.0/23'], 'ipv6': ['2001:7f8:18::/48']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":57,
    "peak_pch":"320G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -9.05095,53.27245 ]
    },
    "properties": {
    "FIELD1":353,
    "country":"Ireland",
    "total_by_country":7,
    "city":"Galway",
    "ixpname":"eXchange West",
    "alternatenames":"['Exchange West']",
    "prefixes":"{'ipv4': ['195.60.82.64/26'], 'ipv6': ['2001:7f8:4d:1::/64']}",
    "sources":"['pdb']",
    "url":"http://www.exwest.net/",
    "participants_pch":2,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 34.78057,32.08088 ]
    },
    "properties": {
    "FIELD1":354,
    "country":"Israel",
    "total_by_country":1,
    "city":"Tel-Aviv",
    "ixpname":"Israeli Internet Exchange",
    "alternatenames":"['IIX Israel', 'Israel Internet eXchange']",
    "prefixes":"{'ipv4': ['192.114.62.0/24'], 'ipv6': ['2001:7f8:3b::/64', '2001:7f8:3b::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.iix.net.il",
    "participants_pch":20,
    "peak_pch":"80G",
    "avg_pch":"56G",
    "status_pch":"active",
    "only_in":"",
    "region":"Middle East & North Africa",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 13.33561,38.13205 ]
    },
    "properties": {
    "FIELD1":355,
    "country":"Italy",
    "total_by_country":12,
    "city":"Palermo",
    "ixpname":"DE-CIX Palermo",
    "alternatenames":"['Deutscher Commercial Internet Exchange Palermo']",
    "prefixes":"{'ipv4': ['185.1.46.0/24'], 'ipv6': ['2001:7f8:32::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://pmo.de-cix.net",
    "participants_pch":5,
    "peak_pch":"1.9G",
    "avg_pch":"1.4G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 9.18951,45.46427 ]
    },
    "properties": {
    "FIELD1":356,
    "country":"Italy",
    "total_by_country":12,
    "city":"Milan",
    "ixpname":"Equinix Milan",
    "alternatenames":"['Equinix Internet Exchange Milan']",
    "prefixes":"{'ipv4': ['185.1.106.0/24'], 'ipv6': ['2001:7f8:c0::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.equinix.it/services/interconnection-connectivity/internet-exchange/",
    "participants_pch":10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 13.23715,46.0693 ]
    },
    "properties": {
    "FIELD1":357,
    "country":"Italy",
    "total_by_country":12,
    "city":"Udine",
    "ixpname":"Friuli Venezia Giulia Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['82.193.63.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 9.18951,45.46427 ]
    },
    "properties": {
    "FIELD1":358,
    "country":"Italy",
    "total_by_country":12,
    "city":"Milan",
    "ixpname":"Milan Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['217.29.66.0/24'], 'ipv6': ['2001:7f8:b:100::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":295,
    "peak_pch":"813G",
    "avg_pch":"554G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 9.18951,45.46427 ]
    },
    "properties": {
    "FIELD1":359,
    "country":"Italy",
    "total_by_country":12,
    "city":"Milan",
    "ixpname":"Milan Neutral Access Point",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.114.0/24'], 'ipv6': ['2001:7f8:c5::/48']}",
    "sources":"['he']",
    "url":"https://www.minap.it/",
    "participants_pch":41,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 12.51133,41.89193 ]
    },
    "properties": {
    "FIELD1":360,
    "country":"Italy",
    "total_by_country":12,
    "city":"Rome",
    "ixpname":"NaMeX - Nautilus Mediterranean Exchange Point",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['193.201.28.0/25', '193.201.29.0/25'], 'ipv6': ['2001:7f8:10::/64', '2001:7f8:10:b::/64']}",
    "sources":"['he']",
    "url":"https://www.namex.it",
    "participants_pch":88,
    "peak_pch":"92G",
    "avg_pch":"61G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 12.51133,41.89193 ]
    },
    "properties": {
    "FIELD1":361,
    "country":"Italy",
    "total_by_country":12,
    "city":"Rome",
    "ixpname":"NaMeX Rome IXP",
    "alternatenames":"['Nautilus Mediterranean Exchange Point']",
    "prefixes":"{'ipv4': ['193.201.28.0/24'], 'ipv6': ['2001:7f8:10::/64']}",
    "sources":"['pdb']",
    "url":"https://www.namex.it",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 9.69342,45.05242 ]
    },
    "properties": {
    "FIELD1":362,
    "country":"Italy",
    "total_by_country":12,
    "city":"Piacenza",
    "ixpname":"Piacenza Internet Exchange",
    "alternatenames":"['Piacenza Internet Exchange']",
    "prefixes":"{'ipv4': ['185.1.97.0/24'], 'ipv6': ['2001:7f8:b9::/48']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.pcix.it/",
    "participants_pch":4,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 11.33982,46.49067 ]
    },
    "properties": {
    "FIELD1":363,
    "country":"Italy",
    "total_by_country":12,
    "city":"Bolzano",
    "ixpname":"South Tyrol Internet Exchange",
    "alternatenames":"['STIX']",
    "prefixes":"{'ipv4': ['185.1.124.0/24'], 'ipv6': ['2001:7f8:cf::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.stix.bz/",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 7.68682,45.07049 ]
    },
    "properties": {
    "FIELD1":364,
    "country":"Italy",
    "total_by_country":12,
    "city":"Torino",
    "ixpname":"Torino Piemonte Exchange Point",
    "alternatenames":"['Consorzio Top-IX', 'TOP-IX']",
    "prefixes":"{'ipv4': ['194.116.96.0/24', '194.116.100.0/24'], 'ipv6': ['2001:7f8:23:ffff::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.top-ix.org",
    "participants_pch":120,
    "peak_pch":"116G",
    "avg_pch":"71G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 11.19924,43.83193 ]
    },
    "properties": {
    "FIELD1":365,
    "country":"Italy",
    "total_by_country":12,
    "city":"Sesto Fiorentino - Florence",
    "ixpname":"Tuscany Internet Exchange",
    "alternatenames":"['Tuscany Internet eXchange']",
    "prefixes":"{'ipv4': ['193.42.140.0/23'], 'ipv6': ['2001:7f8:57:1000::/64']}",
    "sources":"['pdb']",
    "url":"http://www.tix.it/",
    "participants_pch":33,
    "peak_pch":"1.5G",
    "avg_pch":"560M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 11.88586,45.40797 ]
    },
    "properties": {
    "FIELD1":366,
    "country":"Italy",
    "total_by_country":12,
    "city":"Padova",
    "ixpname":"VSIX NAP del Nord Est",
    "alternatenames":"['VSIX Nap del Nord Est']",
    "prefixes":"{'ipv4': ['95.140.128.0/23', '95.140.130.0/23'], 'ipv6': ['2001:7f8:5f:ffff::/64', '2001:7f8:5f:ffef::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.vsix.it/",
    "participants_pch":40,
    "peak_pch":"38G",
    "avg_pch":"21.6G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -76.79358,17.99702 ]
    },
    "properties": {
    "FIELD1":367,
    "country":"Jamaica",
    "total_by_country":1,
    "city":"Kingston",
    "ixpname":"Jamaica Internet Exchange Point",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.41.107.0/24'], 'ipv6': ['2001:504:3e::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":4,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 140.11667,39.71667 ]
    },
    "properties": {
    "FIELD1":368,
    "country":"Japan",
    "total_by_country":23,
    "city":"Akita",
    "ixpname":"Akita Regional IX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 139.69171,35.6895 ]
    },
    "properties": {
    "FIELD1":369,
    "country":"Japan",
    "total_by_country":23,
    "city":"Tokyo",
    "ixpname":"Asia Smart IX [BBIX Asia]",
    "alternatenames":"['Asia Smart IX']",
    "prefixes":"{'ipv4': ['103.203.156.0/23'], 'ipv6': ['2403:c780:a800:bb00::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.bbix.net/en",
    "participants_pch":7,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 130.41667,33.6 ]
    },
    "properties": {
    "FIELD1":370,
    "country":"Japan",
    "total_by_country":23,
    "city":"Fukuoka",
    "ixpname":"BBIX Fukuoka",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['218.100.6.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 136.90641,35.18147 ]
    },
    "properties": {
    "FIELD1":371,
    "country":"Japan",
    "total_by_country":23,
    "city":"Nagoya",
    "ixpname":"BBIX Nagoya",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2005,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 135.50218,34.69374 ]
    },
    "properties": {
    "FIELD1":372,
    "country":"Japan",
    "total_by_country":23,
    "city":"Osaka",
    "ixpname":"BBIX Osaka",
    "alternatenames":"['BroadBand Internet eXchange Osaka']",
    "prefixes":"{'ipv4': ['218.100.7.0/24', '218.100.9.0/24'], 'ipv6': ['2001:de8:c::/48', '2001:de8:c:2::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.bbix.net/",
    "participants_pch":16,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 139.69171,35.6895 ]
    },
    "properties": {
    "FIELD1":373,
    "country":"Japan",
    "total_by_country":23,
    "city":"Tokyo",
    "ixpname":"BBIX Tokyo",
    "alternatenames":"['BroadBand Internet eXchange Tokyo']",
    "prefixes":"{'ipv4': ['218.100.6.0/24', '218.100.6.0/23'], 'ipv6': ['2001:de8:c::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.bbix.net/",
    "participants_pch":149,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 139.00589,37.88637 ]
    },
    "properties": {
    "FIELD1":374,
    "country":"Japan",
    "total_by_country":23,
    "city":"Niigata",
    "ixpname":"Echigo-IX",
    "alternatenames":"['Echigo Internet Exchange']",
    "prefixes":"{'ipv4': ['58.84.254.0/23', '58.84.254.0/24'], 'ipv6': ['2402:a800:fff0::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.echigo-ix.jp/",
    "participants_pch":6,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 139.69171,35.6895 ]
    },
    "properties": {
    "FIELD1":375,
    "country":"Japan",
    "total_by_country":23,
    "city":"Tokyo",
    "ixpname":"Equinix IBK Tokyo",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['203.190.230.0/24'], 'ipv6': ['2001:de8:5::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://ix.equinix.com",
    "participants_pch":94,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 135.50218,34.69374 ]
    },
    "properties": {
    "FIELD1":376,
    "country":"Japan",
    "total_by_country":23,
    "city":"Osaka",
    "ixpname":"Equinix Osaka",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['203.190.227.0/24'], 'ipv6': ['2001:de8:5:1::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.equinix.co.jp/",
    "participants_pch":20,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 136.90641,35.18147 ]
    },
    "properties": {
    "FIELD1":377,
    "country":"Japan",
    "total_by_country":23,
    "city":"Nagoya",
    "ixpname":"JPIX Nagoya",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 135.50218,34.69374 ]
    },
    "properties": {
    "FIELD1":378,
    "country":"Japan",
    "total_by_country":23,
    "city":"Osaka",
    "ixpname":"JPIX Osaka",
    "alternatenames":"['JPIX OSAKA', 'Japan Internet Exchange Osaka']",
    "prefixes":"{'ipv4': ['103.246.232.0/24'], 'ipv6': ['2001:de8:8:6::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.jpix.ad.jp/en/",
    "participants_pch":49,
    "peak_pch":"595G",
    "avg_pch":"340G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 139.69171,35.6895 ]
    },
    "properties": {
    "FIELD1":379,
    "country":"Japan",
    "total_by_country":23,
    "city":"Tokyo",
    "ixpname":"JPIX Tokyo",
    "alternatenames":"['JPIX TOKYO', 'Japan Internet Exchange Tokyo']",
    "prefixes":"{'ipv4': ['210.171.224.0/23'], 'ipv6': ['2001:de8:8::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.jpix.ad.jp/en/",
    "participants_pch":174,
    "peak_pch":"995G",
    "avg_pch":"630G",
    "status_pch":"",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 135.50218,34.69374 ]
    },
    "properties": {
    "FIELD1":380,
    "country":"Japan",
    "total_by_country":23,
    "city":"Osaka",
    "ixpname":"JPNAP Osaka",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['210.173.178.0/25'], 'ipv6': ['2001:7fa:7:2::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.jpnap.net/en/",
    "participants_pch":52,
    "peak_pch":"597G",
    "avg_pch":"357G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 139.69171,35.6895 ]
    },
    "properties": {
    "FIELD1":381,
    "country":"Japan",
    "total_by_country":23,
    "city":"Tokyo",
    "ixpname":"JPNAP Tokyo I - Otemachi",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"https://www.jpnap.net/en/",
    "participants_pch":130,
    "peak_pch":"1.32T",
    "avg_pch":"780G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 139.69171,35.6895 ]
    },
    "properties": {
    "FIELD1":382,
    "country":"Japan",
    "total_by_country":23,
    "city":"Tokyo",
    "ixpname":"JPNAP Tokyo II - Ikebukuro",
    "alternatenames":"['JPNAP Tokyo 2']",
    "prefixes":"{'ipv4': ['218.100.45.0/24'], 'ipv6': ['2001:7fa:7:3::/64']}",
    "sources":"['pch', 'he']",
    "url":"http://www.mfeed.ad.jp",
    "participants_pch":5,
    "peak_pch":"100G",
    "avg_pch":"48G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 135.75385,35.02107 ]
    },
    "properties": {
    "FIELD1":383,
    "country":"Japan",
    "total_by_country":23,
    "city":"Kyoto",
    "ixpname":"Kyoto Municipal Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 139.69171,35.6895 ]
    },
    "properties": {
    "FIELD1":384,
    "country":"Japan",
    "total_by_country":23,
    "city":"Tokyo",
    "ixpname":"LSY.CN Tokyo",
    "alternatenames":"['LSHIY Group Tokyo Internet eXchange']",
    "prefixes":"{'ipv4': [], 'ipv6': ['2404:f4c0:4:5::/64', '2404:f4c0:4:270::/64', '2403:5180:25:270::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://ix.lsy.cn/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 135.50218,34.69374 ]
    },
    "properties": {
    "FIELD1":385,
    "country":"Japan",
    "total_by_country":23,
    "city":"Osaka",
    "ixpname":"MoeIX Osaka",
    "alternatenames":"['MoeQing Internet Exchange - Osaka']",
    "prefixes":"{'ipv4': ['62.133.35.0/24'], 'ipv6': ['2a0c:b641:70:cafe::/64', '2a0c:5440:ffff:b233::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.moeix.online",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 135.50218,34.69374 ]
    },
    "properties": {
    "FIELD1":386,
    "country":"Japan",
    "total_by_country":23,
    "city":"Osaka",
    "ixpname":"NSPIXP-3",
    "alternatenames":"['NSPIXP3', 'Wide NSPIXP3']",
    "prefixes":"{'ipv4': ['202.249.38.0/26', '202.249.38.0/24'], 'ipv6': ['2001:200:0:fe10::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://nspixp.wide.ad.jp/3/",
    "participants_pch":23,
    "peak_pch":"72G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 139.69171,35.6895 ]
    },
    "properties": {
    "FIELD1":387,
    "country":"Japan",
    "total_by_country":23,
    "city":"Tokyo",
    "ixpname":"Network Service Provider IXP (Distributed IX in Edo)",
    "alternatenames":"['DIX-IE', 'Distributed IX in EDO (former NSPIXP2)']",
    "prefixes":"{'ipv4': ['202.249.2.0/24'], 'ipv6': ['2001:200:0:fe00::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://nspixp.wide.ad.jp/",
    "participants_pch":46,
    "peak_pch":"23G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 139.69171,35.6895 ]
    },
    "properties": {
    "FIELD1":388,
    "country":"Japan",
    "total_by_country":23,
    "city":"Tokyo",
    "ixpname":"Network Service Provider IXP-6",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': ['3ffe:501:0:1800:200:f8ff:fe1f:7490/128']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":51,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":1999,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 139.69171,35.6895 ]
    },
    "properties": {
    "FIELD1":390,
    "country":"Japan",
    "total_by_country":23,
    "city":"Tokyo",
    "ixpname":"Tokyo Lambda Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 80.26669,50.42675 ]
    },
    "properties": {
    "FIELD1":391,
    "country":"Kazakhstan",
    "total_by_country":3,
    "city":"Semey",
    "ixpname":"KazNIX",
    "alternatenames":"['KazNIX Exchange Point']",
    "prefixes":"{'ipv4': ['185.79.213.0/24'], 'ipv6': ['2a01:7640:9400::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://kaznix.kz",
    "participants_pch":6,
    "peak_pch":"127M",
    "avg_pch":"56M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 71.44598,51.1801 ]
    },
    "properties": {
    "FIELD1":392,
    "country":"Kazakhstan",
    "total_by_country":3,
    "city":"Astana",
    "ixpname":"Kazakhstan Internet Exchange",
    "alternatenames":"['Kazakhstan Internet Exchange']",
    "prefixes":"{'ipv4': ['195.12.116.0/23'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"http://sts.kz/",
    "participants_pch":13,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 76.92861,43.25667 ]
    },
    "properties": {
    "FIELD1":393,
    "country":"Kazakhstan",
    "total_by_country":3,
    "city":"Almaty",
    "ixpname":"Kazakhstan Traffic Exchange",
    "alternatenames":"['Kazakhstan Traffic Exchange']",
    "prefixes":"{'ipv4': ['195.2.230.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.kaz-ix.kz/web/",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 39.66359,-4.05466 ]
    },
    "properties": {
    "FIELD1":394,
    "country":"Kenya",
    "total_by_country":4,
    "city":"Mombasa",
    "ixpname":"Asteroid Mombasa",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 39.66359,-4.05466 ]
    },
    "properties": {
    "FIELD1":395,
    "country":"Kenya",
    "total_by_country":4,
    "city":"Mombasa",
    "ixpname":"KIXP - Mombasa",
    "alternatenames":"['Kenya Internet Exchange Point - Mombasa']",
    "prefixes":"{'ipv4': ['196.60.2.0/27'], 'ipv6': ['2001:43f8:c0:2::/64']}",
    "sources":"['pdb']",
    "url":"https://www.tespok.co.ke/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Sub-Saharan Africa",
    "year":2016,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 36.81667,-1.28333 ]
    },
    "properties": {
    "FIELD1":396,
    "country":"Kenya",
    "total_by_country":4,
    "city":"Nairobi",
    "ixpname":"Kenya Internet Exchange Point-Nairobi",
    "alternatenames":"['Kenya Internet Exchange Point - Nairobi']",
    "prefixes":"{'ipv4': ['196.223.21.0/24'], 'ipv6': ['2001:43f8:60:1::/64']}",
    "sources":"['pdb']",
    "url":"https://www.tespok.co.ke/",
    "participants_pch":38,
    "peak_pch":"8.1G",
    "avg_pch":"4.7G",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2001,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 39.66359,-4.05466 ]
    },
    "properties": {
    "FIELD1":397,
    "country":"Kenya",
    "total_by_country":4,
    "city":"Mombasa",
    "ixpname":"Mombasa Internet Exchange Point",
    "alternatenames":"['TESPOK-KIXP-MBA']",
    "prefixes":"{'ipv4': ['196.60.2.0/24'], 'ipv6': ['2001:43f8:c0::/64', '2001:43f8:c0:2::/64']}",
    "sources":"['pch', 'he']",
    "url":"https://www.tespok.co.ke/",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2016,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 126.8494667,37.5652894 ]
    },
    "properties": {
    "FIELD1":398,
    "country":"South Korea",
    "total_by_country":6,
    "city":"Seoul",
    "ixpname":"6NGIX",
    "alternatenames":"['KISA 6NGIX Center']",
    "prefixes":"{'ipv4': ['203.254.32.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://vsix.kr/eng/biz/contents/0000000101/getContents.do",
    "participants_pch":82,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 126.8494667,37.5652894 ]
    },
    "properties": {
    "FIELD1":399,
    "country":"South Korea",
    "total_by_country":6,
    "city":"Seoul",
    "ixpname":"Korea Internet Data Center",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":1999,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 126.8494667,37.5652894 ]
    },
    "properties": {
    "FIELD1":400,
    "country":"South Korea",
    "total_by_country":6,
    "city":"Seoul",
    "ixpname":"Korea Internet Exchange KIX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 126.8494667,37.5652894 ]
    },
    "properties": {
    "FIELD1":401,
    "country":"South Korea",
    "total_by_country":6,
    "city":"Seoul",
    "ixpname":"Korea Internet Neutral Exchange KINX",
    "alternatenames":"['Korean Internet Neutral Exchange', 'KINX']",
    "prefixes":"{'ipv4': ['192.145.251.0/24'], 'ipv6': ['2001:7fa:8::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.kinx.net/?lang=en",
    "participants_pch":45,
    "peak_pch":"157G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 126.8494667,37.5652894 ]
    },
    "properties": {
    "FIELD1":402,
    "country":"South Korea",
    "total_by_country":6,
    "city":"Seoul",
    "ixpname":"LGDACOM Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['198.32.209.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":52,
    "peak_pch":"70G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 127.29223,36.59245 ]
    },
    "properties": {
    "FIELD1":403,
    "country":"South Korea",
    "total_by_country":6,
    "city":"Sejong",
    "ixpname":"Sejong Neutral-IX",
    "alternatenames":"['Sejong Telecom Neutral Internet Exchange']",
    "prefixes":"{'ipv4': ['203.255.114.0/23'], 'ipv6': ['2001:3a8:7000::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.sejongtelecom.net/en/pages/service/data_network_nix",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 21.16688,42.67272 ]
    },
    "properties": {
    "FIELD1":404,
    "country":"Kosovo",
    "total_by_country":1,
    "city":"Prishtina",
    "ixpname":"KOSIX Internet Exchange Point",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 74.59,42.87 ]
    },
    "properties": {
    "FIELD1":405,
    "country":"Kyrgyz Republic",
    "total_by_country":3,
    "city":"Bishkek",
    "ixpname":"KG-IX",
    "alternatenames":"['KG-IX']",
    "prefixes":"{'ipv4': ['185.1.110.0/24'], 'ipv6': ['2001:7f8:3c:3e8::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.kg-ix.net",
    "participants_pch":5,
    "peak_pch":"7G",
    "avg_pch":"3G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 74.59,42.87 ]
    },
    "properties": {
    "FIELD1":406,
    "country":"Kyrgyz Republic",
    "total_by_country":3,
    "city":"Bishkek",
    "ixpname":"Kyrgyz IXP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":2002,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 74.59,42.87 ]
    },
    "properties": {
    "FIELD1":407,
    "country":"Kyrgyz Republic",
    "total_by_country":3,
    "city":"Bishkek",
    "ixpname":"SR-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.54.252.0/24'], 'ipv6': ['2a00:7160:5::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://sr-ix.asia/",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 102.6,17.96667 ]
    },
    "properties": {
    "FIELD1":408,
    "country":"Laos",
    "total_by_country":1,
    "city":"Vientiane",
    "ixpname":"Lao National Internet Center",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['172.16.96.0/24', '172.16.97.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":7,
    "peak_pch":"1M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2010,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 24.10589,56.946 ]
    },
    "properties": {
    "FIELD1":409,
    "country":"Latvia",
    "total_by_country":2,
    "city":"Riga",
    "ixpname":"MSK-IX Riga",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['193.232.244.0/24'], 'ipv6': ['2001:7f8:20:1101::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.msk-ix.ru/en/ix/rix",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 24.10589,56.946 ]
    },
    "properties": {
    "FIELD1":410,
    "country":"Latvia",
    "total_by_country":2,
    "city":"Riga",
    "ixpname":"Santa Monica Internet Local Exchange",
    "alternatenames":"['SMILE-IXP', 'SMILE-LV']",
    "prefixes":"{'ipv4': ['195.246.227.0/24'], 'ipv6': ['2001:7f8:16::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.smile-ixp.net",
    "participants_pch":39,
    "peak_pch":"8.9G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2005,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 35.50157,33.89332 ]
    },
    "properties": {
    "FIELD1":411,
    "country":"Lebanon",
    "total_by_country":2,
    "city":"Beirut",
    "ixpname":"Advanced Internet Exchange",
    "alternatenames":"['Advanced IX Lebanon']",
    "prefixes":"{'ipv4': ['185.1.108.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"http://www.a-ix.org",
    "participants_pch":26,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Middle East & North Africa",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 35.50157,33.89332 ]
    },
    "properties": {
    "FIELD1":412,
    "country":"Lebanon",
    "total_by_country":2,
    "city":"Beirut",
    "ixpname":"Beirut Internet Exchange",
    "alternatenames":"['Beirut Internet Exchange - Lebanon']",
    "prefixes":"{'ipv4': ['198.32.157.0/25', '185.91.96.0/22', '198.32.157.0/24'], 'ipv6': ['2001:7f8:52::/64', '2001:7f8:52::/48']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.beirutix.net",
    "participants_pch":12,
    "peak_pch":"61.8M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Middle East & North Africa",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 27.48333,-29.31667 ]
    },
    "properties": {
    "FIELD1":413,
    "country":"Lesotho",
    "total_by_country":2,
    "city":"Maseru",
    "ixpname":"Lesotho Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Sub-Saharan Africa",
    "year":2011,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 27.48333,-29.31667 ]
    },
    "properties": {
    "FIELD1":414,
    "country":"Lesotho",
    "total_by_country":2,
    "city":"Maseru",
    "ixpname":"Lesotho Internet Exchange Point",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['196.223.24.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2011,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -10.7969,6.30054 ]
    },
    "properties": {
    "FIELD1":415,
    "country":"Liberia",
    "total_by_country":1,
    "city":"Monrovia",
    "ixpname":"Liberia Internet Exchange Point",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['196.223.44.0/24'], 'ipv6': ['2a06:5600::/48']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":4,
    "peak_pch":"2M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2015,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 9.52223,47.21071 ]
    },
    "properties": {
    "FIELD1":416,
    "country":"Liechtenstein",
    "total_by_country":1,
    "city":"Eschen",
    "ixpname":"Rheintal Internet Exchange",
    "alternatenames":"['Rheintal IX Internet Exchange', 'Rheintal IX']",
    "prefixes":"{'ipv4': ['91.232.229.0/24'], 'ipv6': ['2001:7f8:66::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"['http://www.rheintal-ix.net', 'https://www.rheintal-ix.net']",
    "participants_pch":13,
    "peak_pch":"1.2G",
    "avg_pch":"265M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 25.2798,54.68916 ]
    },
    "properties": {
    "FIELD1":417,
    "country":"Lithuania",
    "total_by_country":4,
    "city":"Vilnius",
    "ixpname":"Baltic Internet Exchange",
    "alternatenames":"['BALT-IX']",
    "prefixes":"{'ipv4': ['77.241.206.0/24'], 'ipv6': ['2001:1ab8:8486::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.balt-ix.lt",
    "participants_pch":42,
    "peak_pch":"78G",
    "avg_pch":"45G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 25.2798,54.68916 ]
    },
    "properties": {
    "FIELD1":418,
    "country":"Lithuania",
    "total_by_country":4,
    "city":"Vilnius",
    "ixpname":"Lithuania Internet Exchange",
    "alternatenames":"['Lithuanian Internet eXchange Point', 'LIXP']",
    "prefixes":"{'ipv4': ['185.1.92.0/24'], 'ipv6': ['2001:7f8:b4::/48']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.lixp.lt/en/",
    "participants_pch":18,
    "peak_pch":"37G",
    "avg_pch":"27G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 25.2798,54.68916 ]
    },
    "properties": {
    "FIELD1":419,
    "country":"Lithuania",
    "total_by_country":4,
    "city":"Vilnius",
    "ixpname":"Lithuanian Internet service providers exchange unit",
    "alternatenames":"['Lietuvos Interneto paslaug? tiek?j? apsikeitimo mazgu', 'LIPTAM']",
    "prefixes":"{'ipv4': ['193.219.13.64/26'], 'ipv6': ['2001:778:0:1001::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://is.lt/",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 25.2798,54.68916 ]
    },
    "properties": {
    "FIELD1":420,
    "country":"Lithuania",
    "total_by_country":4,
    "city":"Vilnius",
    "ixpname":"Lithuanian peering center",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.113.0/24'], 'ipv6': ['2001:7f8:c4::/48', '2a03:67e0:0:9::/64']}",
    "sources":"['he']",
    "url":"http://datalogistics.lt/en/node/99",
    "participants_pch":28,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 6.13,49.61167 ]
    },
    "properties": {
    "FIELD1":421,
    "country":"Luxembourg",
    "total_by_country":1,
    "city":"Luxembourg",
    "ixpname":"Luxembourg Commercial Internet Exchange",
    "alternatenames":"['LU-CIX']",
    "prefixes":"{'ipv4': ['188.93.170.0/23'], 'ipv6': ['2001:7f8:4c::/48', '2001:7f8:4c::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.lu-cix.lu/",
    "participants_pch":79,
    "peak_pch":"200G",
    "avg_pch":"105G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 47.53613,-18.91368 ]
    },
    "properties": {
    "FIELD1":422,
    "country":"Madagascar",
    "total_by_country":1,
    "city":"Antananarivo",
    "ixpname":"Madagascar Global Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['196.223.41.0/24'], 'ipv6': ['2001:43f8:a10::/64']}",
    "sources":"['he']",
    "url":"http://www.mgix.mg",
    "participants_pch":9,
    "peak_pch":"11.8M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2016,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 35.00854,-15.78499 ]
    },
    "properties": {
    "FIELD1":423,
    "country":"Malawi",
    "total_by_country":1,
    "city":"Blantyre",
    "ixpname":"Malawi IXP",
    "alternatenames":"['Malawi Internet Exchange (MIX)']",
    "prefixes":"{'ipv4': ['196.223.27.0/24', '196.49.72.0/24'], 'ipv6': ['2001:43f8:13a0::/64', '2001:43f8:380::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.mispa.org.mw/",
    "participants_pch":2,
    "peak_pch":"10M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2008,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 103.7627233,1.4816994 ]
    },
    "properties": {
    "FIELD1":424,
    "country":"Malaysia",
    "total_by_country":3,
    "city":"Joaor Bahru",
    "ixpname":"Joaor Bahru Internet Exchange",
    "alternatenames":"['JBIX']",
    "prefixes":"{'ipv4': ['103.119.232.0/22'], 'ipv6': ['2403:4ac0::/32']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.jbix.my",
    "participants_pch":12,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 101.68653,3.1412 ]
    },
    "properties": {
    "FIELD1":425,
    "country":"Malaysia",
    "total_by_country":3,
    "city":"Kuala Lumpur",
    "ixpname":"Malaysia Internet Exchange",
    "alternatenames":"['MyIX']",
    "prefixes":"{'ipv4': ['218.100.44.0/24'], 'ipv6': ['2001:de8:10::/48']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.myix.my",
    "participants_pch":75,
    "peak_pch":"249G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2006,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 101.68653,3.1412 ]
    },
    "properties": {
    "FIELD1":426,
    "country":"Malaysia",
    "total_by_country":3,
    "city":"Kuala Lumpur",
    "ixpname":"Thai-IX Malaysia by CS Loxinfo",
    "alternatenames":"['Thai-IX Malaysia by CS Loxinfo']",
    "prefixes":"{'ipv4': ['27.254.16.0/23'], 'ipv6': ['2404:b0:13:a::/64']}",
    "sources":"['pdb']",
    "url":"https://www.cslthai-ix.net",
    "participants_pch":10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -8,12.65 ]
    },
    "properties": {
    "FIELD1":427,
    "country":"Mali",
    "total_by_country":1,
    "city":"Bamako",
    "ixpname":"Mali IXP",
    "alternatenames":"['MLIX', Point d'?change du Mali\"]\"",
    "prefixes":"{'ipv4': ['196.60.46.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.mlix.ml",
    "participants_pch":4,
    "peak_pch":"173M",
    "avg_pch":"15M",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 14.48278,35.8925 ]
    },
    "properties": {
    "FIELD1":428,
    "country":"Malta",
    "total_by_country":1,
    "city":"Msida",
    "ixpname":"Malta Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Middle East & North Africa",
    "year":1999,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -61.07418,14.60365 ]
    },
    "properties": {
    "FIELD1":429,
    "country":"Martinique",
    "total_by_country":1,
    "city":"Fort-de-France",
    "ixpname":"Martinix",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['194.254.208.128/27'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"https://www.renater.fr/martinix",
    "participants_pch":3,
    "peak_pch":"517M",
    "avg_pch":"120M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 57.49163,-20.24494 ]
    },
    "properties": {
    "FIELD1":430,
    "country":"Mauritius",
    "total_by_country":1,
    "city":"Ebene",
    "ixpname":"Mauritius Internet Exchange",
    "alternatenames":"['MIXP', 'Mauritius Internet Exchange Point']",
    "prefixes":"{'ipv4': ['196.223.0.0/24'], 'ipv6': ['2001:43f8:270:d0d0::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.mixp.org/",
    "participants_pch":10,
    "peak_pch":"80M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2005,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -99.12766,19.42847 ]
    },
    "properties": {
    "FIELD1":431,
    "country":"Mexico",
    "total_by_country":3,
    "city":"Mexico DF",
    "ixpname":"IXP.MX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['201.131.204.0/24'], 'ipv6': ['2806:239::/64']}",
    "sources":"['he']",
    "url":"http://www.ixp.mx",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Latin America & Caribbean",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -99.12766,19.42847 ]
    },
    "properties": {
    "FIELD1":432,
    "country":"Mexico",
    "total_by_country":3,
    "city":"Mexico DF",
    "ixpname":"IXP.MX - Mexico City",
    "alternatenames":"['Mexico IXP']",
    "prefixes":"{'ipv4': ['201.131.204.0/26'], 'ipv6': ['2806:239::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.ixp.mx",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Latin America & Caribbean",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -99.12766,19.42847 ]
    },
    "properties": {
    "FIELD1":433,
    "country":"Mexico",
    "total_by_country":3,
    "city":"Mexico DF",
    "ixpname":"Mexico IXP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":7,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"Latin America & Caribbean",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 28.8575,47.00556 ]
    },
    "properties": {
    "FIELD1":434,
    "country":"Moldova",
    "total_by_country":1,
    "city":"Chisinau",
    "ixpname":"KIVIX",
    "alternatenames":"['Chisinau Internet Exchange']",
    "prefixes":"{'ipv4': ['185.1.45.0/24'], 'ipv6': ['2001:7f8:2e::/48']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.kivix.net",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 106.88324,47.90771 ]
    },
    "properties": {
    "FIELD1":435,
    "country":"Mongolia",
    "total_by_country":1,
    "city":"Ulaanbaatar",
    "ixpname":"Mongolia Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":2001,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 19.26361,42.44111 ]
    },
    "properties": {
    "FIELD1":436,
    "country":"Montenegro",
    "total_by_country":1,
    "city":"Podgorica",
    "ixpname":"Montenegro Internet eXchange Point",
    "alternatenames":"['MIXP.me']",
    "prefixes":"{'ipv4': ['185.1.44.0/24'], 'ipv6': ['2001:7f8:22::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.mixp.me/eng/",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -7.61138,33.58831 ]
    },
    "properties": {
    "FIELD1":437,
    "country":"Morocco",
    "total_by_country":2,
    "city":"Casablanca",
    "ixpname":"Casablanca Internet Exchange",
    "alternatenames":"['CAS-IX', 'Casablanca Internet Exchange Point']",
    "prefixes":"{'ipv4': ['169.255.176.0/22'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.casix.ma",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Middle East & North Africa",
    "year":2019,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -6.83255,34.01325 ]
    },
    "properties": {
    "FIELD1":438,
    "country":"Morocco",
    "total_by_country":2,
    "city":"Rabat",
    "ixpname":"Maroc Internet Exchange Point",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Middle East & North Africa",
    "year":2016,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 32.58322,-25.96553 ]
    },
    "properties": {
    "FIELD1":439,
    "country":"Mozambique",
    "total_by_country":1,
    "city":"Maputo",
    "ixpname":"Mozambique Internet Exchange",
    "alternatenames":"['MOZIX']",
    "prefixes":"{'ipv4': ['196.223.33.0/24', '192.168.10.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.mozix.org.mz",
    "participants_pch":15,
    "peak_pch":"14.7M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2002,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 96.15611,16.80528 ]
    },
    "properties": {
    "FIELD1":440,
    "country":"Myanmar",
    "total_by_country":1,
    "city":"Yangon",
    "ixpname":"Myanmar Internet Exchange",
    "alternatenames":"['MMIX']",
    "prefixes":"{'ipv4': ['103.103.194.0/24', '103.116.194.0/24'], 'ipv6': ['2001:df3:1300::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.mm-ix.net",
    "participants_pch":12,
    "peak_pch":"12G",
    "avg_pch":"6.7G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2017,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 17.08323,-22.55941 ]
    },
    "properties": {
    "FIELD1":441,
    "country":"Namibia",
    "total_by_country":1,
    "city":"Windhoek",
    "ixpname":"Windhoek IXP",
    "alternatenames":"['IXP Namibia', 'Windhoek Internet Exchange Point']",
    "prefixes":"{'ipv4': ['196.223.35.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://dev.ixp.org.na/",
    "participants_pch":11,
    "peak_pch":"50M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 85.3206,27.70169 ]
    },
    "properties": {
    "FIELD1":442,
    "country":"Nepal",
    "total_by_country":3,
    "city":"Kathmandu",
    "ixpname":"Nepal Internet Exchange",
    "alternatenames":"['Internet Exchange Nepal']",
    "prefixes":"{'ipv4': ['198.32.231.0/25'], 'ipv6': ['2404:2c00:ffff:e::/64']}",
    "sources":"['pdb']",
    "url":"http://www.npix.net.np/",
    "participants_pch":36,
    "peak_pch":"6.4G",
    "avg_pch":"284M",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2002,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 85.31417,27.67658 ]
    },
    "properties": {
    "FIELD1":443,
    "country":"Nepal",
    "total_by_country":3,
    "city":"Lalitpur",
    "ixpname":"Nepal Internet Exchange (Edit)",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":30,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"South Asia",
    "year":2002,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 85.31417,27.67658 ]
    },
    "properties": {
    "FIELD1":444,
    "country":"Nepal",
    "total_by_country":3,
    "city":"Lalitpur",
    "ixpname":"npIX JWL",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['98.32.231.128/25'], 'ipv6': ['2404:2c00:ffff:f::/64']}",
    "sources":"['pdb']",
    "url":"http://www.npix.net.np/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"South Asia",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 4.88969,52.37403 ]
    },
    "properties": {
    "FIELD1":445,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"Amsterdam",
    "ixpname":"Amsterdam Internet Exchange",
    "alternatenames":"['AMS-IX']",
    "prefixes":"{'ipv4': ['80.249.208.0/21', '193.105.101.0/24'], 'ipv6': ['2001:7f8:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.ams-ix.net/",
    "participants_pch":807,
    "peak_pch":"6.78T",
    "avg_pch":"4.93T",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 4.88969,52.37403 ]
    },
    "properties": {
    "FIELD1":446,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"Amsterdam",
    "ixpname":"Asteroid Amsterdam IXP",
    "alternatenames":"['Asteroid Amsterdam', 'Asteroid Amsterdam IX']",
    "prefixes":"{'ipv4': ['185.1.94.0/24'], 'ipv6': ['2001:7f8:b6::/64', '2001:7f8:b6:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.asteroidhq.com/ixp-locations/1",
    "participants_pch":30,
    "peak_pch":"18G",
    "avg_pch":"16.5G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 4.88969,52.37403 ]
    },
    "properties": {
    "FIELD1":447,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"Amsterdam",
    "ixpname":"Equinix Amsterdam",
    "alternatenames":"['Equinix Internet Exchange Amsterdam']",
    "prefixes":"{'ipv4': ['185.1.112.0/24'], 'ipv6': ['2001:7f8:83::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.equinix.nl/services/interconnection-connectivity/internet-exchange/",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 5.80859,53.20139 ]
    },
    "properties": {
    "FIELD1":448,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"Leeuwarden",
    "ixpname":"Friese Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":38,
    "peak_pch":"3.1G",
    "avg_pch":"3K",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2006,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 6.56667,53.21917 ]
    },
    "properties": {
    "FIELD1":449,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"Groningen",
    "ixpname":"Groningen-IX",
    "alternatenames":"['GN-IX', 'Groningen Internet Exchange']",
    "prefixes":"{'ipv4': ['193.111.172.0/24'], 'ipv6': ['2001:7f8:31::/48', '2001:7f8:31::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.gn-ix.net/",
    "participants_pch":51,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 4.88969,52.37403 ]
    },
    "properties": {
    "FIELD1":450,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"Amsterdam",
    "ixpname":"LSIX",
    "alternatenames":"['LayerSwitch Internet Exchange']",
    "prefixes":"{'ipv4': ['185.1.32.0/24'], 'ipv6': ['2001:7f8:8f::/48']}",
    "sources":"['pdb']",
    "url":"https://lsix.net",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 4.88969,52.37403 ]
    },
    "properties": {
    "FIELD1":451,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"Amsterdam",
    "ixpname":"LSY.CN Amsterdam",
    "alternatenames":"['LSHIY Group Amsterdam Internet eXchange']",
    "prefixes":"{'ipv4': [], 'ipv6': ['2404:f4c0:4:4::/64', '2404:f4c0:4:870::/64', '2403:5180:25:870::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://ix.lsy.cn/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 4.29861,52.07667 ]
    },
    "properties": {
    "FIELD1":452,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"The Hague",
    "ixpname":"LayerSwitch Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":43,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 6.89583,52.21833 ]
    },
    "properties": {
    "FIELD1":453,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"Enschede",
    "ixpname":"Nederlands-Duitse Internet Exchange",
    "alternatenames":"['NDIX', 'Nederlands Duitse Internet Exchange']",
    "prefixes":"{'ipv4': ['193.108.98.0/24'], 'ipv6': ['2001:7f8:e::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.ndix.net",
    "participants_pch":31,
    "peak_pch":"50M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 6.19444,52.69583 ]
    },
    "properties": {
    "FIELD1":454,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"Meppel",
    "ixpname":"Netherlands Local Internet Exchange",
    "alternatenames":"['Netherlands Local Internet Exchange']",
    "prefixes":"{'ipv4': ['185.1.138.0/24', '194.28.98.224/27'], 'ipv6': ['2a0c:b641:700::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.nlocix.net",
    "participants_pch":36,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 4.29861,52.07667 ]
    },
    "properties": {
    "FIELD1":455,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"The Hague",
    "ixpname":"Neutral Internet Exchange",
    "alternatenames":"['NL-ix']",
    "prefixes":"{'ipv4': ['193.239.116.0/22', '194.246.39.224/27'], 'ipv6': ['2001:7f8:13::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"https://www.nl-ix.net/",
    "participants_pch":654,
    "peak_pch":"2.2T",
    "avg_pch":"1.6T",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 4.88969,52.37403 ]
    },
    "properties": {
    "FIELD1":456,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"Amsterdam",
    "ixpname":"Neutral Internet Exchange - Amsterdam",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['194.246.39.224/27', '193.239.116.0/22'], 'ipv6': ['2001:7f8:13::/64']}",
    "sources":"['he']",
    "url":"https://www.nl-ix.net/",
    "participants_pch":654,
    "peak_pch":"2.2T",
    "avg_pch":"1.6T",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 4.88969,52.37403 ]
    },
    "properties": {
    "FIELD1":457,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"Amsterdam",
    "ixpname":"Neutral Internet Exchange 2",
    "alternatenames":"['Neutral Internet Exchange 2']",
    "prefixes":"{'ipv4': ['185.1.122.0/24'], 'ipv6': ['2001:7f8:cd::/48']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.nl-ix.net",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 4.47917,51.9225 ]
    },
    "properties": {
    "FIELD1":458,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"Rotterdam",
    "ixpname":"Rotterdam Internet eXchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['91.194.218.0/24'], 'ipv6': ['2001:7f8:61::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":29,
    "peak_pch":"250G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 5.71806,52.525 ]
    },
    "properties": {
    "FIELD1":459,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"Dronten",
    "ixpname":"SPEED-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['he']",
    "url":"https://speed-ix.net",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 5.71806,52.525 ]
    },
    "properties": {
    "FIELD1":460,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"Dronten",
    "ixpname":"Speed Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":140,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 4.88969,52.37403 ]
    },
    "properties": {
    "FIELD1":461,
    "country":"Netherlands",
    "total_by_country":17,
    "city":"Amsterdam",
    "ixpname":"XchangePoint Amsterdam IPP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -63.0509077,18.0248271 ]
    },
    "properties": {
    "FIELD1":462,
    "country":"Antilles",
    "total_by_country":1,
    "city":"Philipsburg",
    "ixpname":"Open Caribbean Internet eXchange",
    "alternatenames":"['OCIX']",
    "prefixes":"{'ipv4': ['200.0.22.0/23'], 'ipv6': ['2001:13c7:6002::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.ocix.net",
    "participants_pch":8,
    "peak_pch":"1.3G",
    "avg_pch":"736M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 174.76349,-36.84853 ]
    },
    "properties": {
    "FIELD1":463,
    "country":"New Zealand",
    "total_by_country":8,
    "city":"Auckland",
    "ixpname":"Auckland Internet Exchange",
    "alternatenames":"['AKL-IX']",
    "prefixes":"{'ipv4': ['43.243.21.0/24'], 'ipv6': ['2001:7fa:11:6::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.ix.nz",
    "participants_pch":48,
    "peak_pch":"33G",
    "avg_pch":"21G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 174.76349,-36.84853 ]
    },
    "properties": {
    "FIELD1":464,
    "country":"New Zealand",
    "total_by_country":8,
    "city":"Auckland",
    "ixpname":"Auckland Peering Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['192.203.154.0/24'], 'ipv6': ['2001:7fa:4:c0cb::/64']}",
    "sources":"['he']",
    "url":"http://ape.nzix.net/",
    "participants_pch":83,
    "peak_pch":"12.8G",
    "avg_pch":"7.7G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":1999,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 172.63333,-43.53333 ]
    },
    "properties": {
    "FIELD1":465,
    "country":"New Zealand",
    "total_by_country":8,
    "city":"Christchurch",
    "ixpname":"Christchurch Internet Exchange",
    "alternatenames":"['CHIX-NZ']",
    "prefixes":"{'ipv4': ['218.100.24.0/24'], 'ipv6': ['2001:7fa:3:5f44::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://chix.nzix.net/",
    "participants_pch":12,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 175.28333,-37.78333 ]
    },
    "properties": {
    "FIELD1":466,
    "country":"New Zealand",
    "total_by_country":8,
    "city":"Hamilton",
    "ixpname":"Hamilton Internet Exchange",
    "alternatenames":"['HIX-NZ']",
    "prefixes":"{'ipv4': ['218.100.56.0/24'], 'ipv6': ['2001:7fa:3::/48', '2001:7fa:3:b0df::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"['http://wix.nzix.net/hix.html', 'http://www.nzix.net/hix.html']",
    "participants_pch":2,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 174.76349,-36.84853 ]
    },
    "properties": {
    "FIELD1":467,
    "country":"New Zealand",
    "total_by_country":8,
    "city":"Auckland",
    "ixpname":"MegaPort-IX Auckland",
    "alternatenames":"['Megaport MegaIX Auckland', 'MegaIX Auckland']",
    "prefixes":"{'ipv4': ['43.243.22.0/23'], 'ipv6': ['2001:dea:0:40::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://megaport.com",
    "participants_pch":71,
    "peak_pch":"36G",
    "avg_pch":"12.4G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 172.63333,-43.53333 ]
    },
    "properties": {
    "FIELD1":468,
    "country":"New Zealand",
    "total_by_country":8,
    "city":"Christchurch",
    "ixpname":"New Zealand Internet Exchange Christchurch",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":7,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 175.61113,-40.35636 ]
    },
    "properties": {
    "FIELD1":469,
    "country":"New Zealand",
    "total_by_country":8,
    "city":"Palmerston North",
    "ixpname":"Palmerston North Internet Exchange",
    "alternatenames":"['PNIX']",
    "prefixes":"{'ipv4': ['218.100.21.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"http://pnix.nzix.net/",
    "participants_pch":4,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 174.77557,-41.28664 ]
    },
    "properties": {
    "FIELD1":470,
    "country":"New Zealand",
    "total_by_country":8,
    "city":"Wellington",
    "ixpname":"Wellington Internet Exchange",
    "alternatenames":"['WIX-NZ']",
    "prefixes":"{'ipv4': ['202.7.0.0/23'], 'ipv6': ['2001:7fa:3:ca07::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://wix.nzix.net/",
    "participants_pch":89,
    "peak_pch":"540M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -86.2504,12.13282 ]
    },
    "properties": {
    "FIELD1":471,
    "country":"Nicaragua",
    "total_by_country":1,
    "city":"Managua",
    "ixpname":"Nicaraguan Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Latin America & Caribbean",
    "year":2004,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 2.1098,13.51366 ]
    },
    "properties": {
    "FIELD1":472,
    "country":"Niger",
    "total_by_country":1,
    "city":"Niamey",
    "ixpname":".",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Sub-Saharan Africa",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 7.49508,9.05785 ]
    },
    "properties": {
    "FIELD1":473,
    "country":"Nigeria",
    "total_by_country":5,
    "city":"Abuja",
    "ixpname":"Internet Exchange Point of Nigeria - Abuja",
    "alternatenames":"['Internet exchange Point of Nigeria, Abuja']",
    "prefixes":"{'ipv4': ['196.216.150.0/25'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.ixp.net.ng",
    "participants_pch":10,
    "peak_pch":"55.9G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2012,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 3.39467,6.45407 ]
    },
    "properties": {
    "FIELD1":474,
    "country":"Nigeria",
    "total_by_country":5,
    "city":"Lagos",
    "ixpname":"Internet Exchange Point of Nigeria - Lagos",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['196.216.148.0/24'], 'ipv6': ['2001:43f8:bb1::/64', '2001:43f8:bb0::/64']}",
    "sources":"['he']",
    "url":"http://www.ixp.net.ng",
    "participants_pch":61,
    "peak_pch":"145G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2006,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 7.0134,4.77742 ]
    },
    "properties": {
    "FIELD1":475,
    "country":"Nigeria",
    "total_by_country":5,
    "city":"Port Harcourt",
    "ixpname":"Internet Exchange Point of Nigeria - Port Harcourt",
    "alternatenames":"['IXPN Port Harcourt', 'Internet Exchange Point of Nigeria, Port Harcourt']",
    "prefixes":"{'ipv4': ['196.216.151.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.ixp.net.ng",
    "participants_pch":4,
    "peak_pch":"42M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2012,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 3.39467,6.45407 ]
    },
    "properties": {
    "FIELD1":476,
    "country":"Nigeria",
    "total_by_country":5,
    "city":"Lagos",
    "ixpname":"WAF-IX, Lagos",
    "alternatenames":"['WAF-IX Lagos', 'WAF-IX, Lagos, Nigeria']",
    "prefixes":"{'ipv4': ['196.60.58.0/24'], 'ipv6': ['2001:43f8:11f0::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.wafix.net",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Sub-Saharan Africa",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 3.39467,6.45407 ]
    },
    "properties": {
    "FIELD1":477,
    "country":"Nigeria",
    "total_by_country":5,
    "city":"Lagos",
    "ixpname":"West African Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['45.222.254.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":2,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 21.43141,41.99646 ]
    },
    "properties": {
    "FIELD1":478,
    "country":"North Macedonia",
    "total_by_country":1,
    "city":"skopje",
    "ixpname":"IXP.mk",
    "alternatenames":"['Faculty of Computer Science and Engineering - IXP.mk']",
    "prefixes":"{'ipv4': ['185.1.121.0/24'], 'ipv6': ['2001:7f8:cb:dcbb::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ixp.mk",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 5.32415,60.39299 ]
    },
    "properties": {
    "FIELD1":479,
    "country":"Norway",
    "total_by_country":10,
    "city":"Bergen",
    "ixpname":"Bergen Internet Exchange",
    "alternatenames":"['BIX Bergen']",
    "prefixes":"{'ipv4': ['193.156.125.0/24', '185.1.65.128/27'], 'ipv6': ['2001:7f8:12:4::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.nix.no/",
    "participants_pch":6,
    "peak_pch":"440M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 10.74609,59.91273 ]
    },
    "properties": {
    "FIELD1":480,
    "country":"Norway",
    "total_by_country":10,
    "city":"Oslo",
    "ixpname":"Free Internet eXchange Oslo",
    "alternatenames":"['FIXO Internet Exchange Oslo', 'FIXO']",
    "prefixes":"{'ipv4': ['91.198.176.0/24'], 'ipv6': ['2001:7f8:41::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.fixo.no",
    "participants_pch":55,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 10.74609,59.91273 ]
    },
    "properties": {
    "FIELD1":481,
    "country":"Norway",
    "total_by_country":10,
    "city":"Oslo",
    "ixpname":"NIX - Oslo",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['193.156.90.0/24', '185.1.55.0/24'], 'ipv6': ['2001:7f8:12:1::/64']}",
    "sources":"['he']",
    "url":"https://www.nix.no",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":1993,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 10.74609,59.91273 ]
    },
    "properties": {
    "FIELD1":482,
    "country":"Norway",
    "total_by_country":10,
    "city":"Oslo",
    "ixpname":"NIX1",
    "alternatenames":"['Norwegian Internet Exchange, NIX1 (location 1)']",
    "prefixes":"{'ipv4': ['185.1.55.0/24'], 'ipv6': ['2001:7f8:12:1::/64']}",
    "sources":"['pdb']",
    "url":"https://www.nix.no",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 10.74609,59.91273 ]
    },
    "properties": {
    "FIELD1":483,
    "country":"Norway",
    "total_by_country":10,
    "city":"Oslo",
    "ixpname":"NIX2",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['193.156.120.0/24', '185.1.65.0/26'], 'ipv6': ['2001:7f8:12:2::/64']}",
    "sources":"['he']",
    "url":"https://www.nix.no/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 10.74609,59.91273 ]
    },
    "properties": {
    "FIELD1":484,
    "country":"Norway",
    "total_by_country":10,
    "city":"Oslo",
    "ixpname":"Norwegian Internet Exchange Oslo 1",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['193.156.90.0/24'], 'ipv6': ['2001:7f8:12:1::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":91,
    "peak_pch":"96G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1993,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 10.74609,59.91273 ]
    },
    "properties": {
    "FIELD1":485,
    "country":"Norway",
    "total_by_country":10,
    "city":"Oslo",
    "ixpname":"Norwegian Internet Exchange Oslo 2",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['193.156.120.0/24'], 'ipv6': ['2001:7f8:12:2::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":22,
    "peak_pch":"11G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 5.73332,58.97005 ]
    },
    "properties": {
    "FIELD1":486,
    "country":"Norway",
    "total_by_country":10,
    "city":"Stavanger",
    "ixpname":"Stavanger Internet exchange",
    "alternatenames":"['SIX Stavanger']",
    "prefixes":"{'ipv4': ['185.1.65.224/27'], 'ipv6': ['2001:7f8:12:6::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.nix.no",
    "participants_pch":4,
    "peak_pch":"200M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 18.95508,69.6489 ]
    },
    "properties": {
    "FIELD1":487,
    "country":"Norway",
    "total_by_country":10,
    "city":"Tromso",
    "ixpname":"Tromso Internet exchange",
    "alternatenames":"['TIX Troms?ÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂ¨ÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂ£']",
    "prefixes":"{'ipv4': ['185.1.65.192/27'], 'ipv6': ['2001:7f8:12:5::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.nix.no",
    "participants_pch":7,
    "peak_pch":"128M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 10.39506,63.43049 ]
    },
    "properties": {
    "FIELD1":488,
    "country":"Norway",
    "total_by_country":10,
    "city":"Trondheim",
    "ixpname":"Trondheim Internet Exchange",
    "alternatenames":"['TRDIX']",
    "prefixes":"{'ipv4': ['193.156.93.0/24'], 'ipv6': ['2001:7f8:12:3::/64']}",
    "sources":"['pch', 'he']",
    "url":"http://www.nix.no",
    "participants_pch":5,
    "peak_pch":"1.2G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2005,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 67.0104,24.8608 ]
    },
    "properties": {
    "FIELD1":489,
    "country":"Pakistan",
    "total_by_country":2,
    "city":"Karachi",
    "ixpname":"PKIXP Karachi (ex ZPIX)",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"South Asia",
    "year":2011,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 73.04329,33.72148 ]
    },
    "properties": {
    "FIELD1":490,
    "country":"Pakistan",
    "total_by_country":2,
    "city":"Islamabad",
    "ixpname":"Pakistan Internet Exchange Point",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":9,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2017,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -79.51973,8.9936 ]
    },
    "properties": {
    "FIELD1":491,
    "country":"Panama",
    "total_by_country":2,
    "city":"Panama City",
    "ixpname":"Intered Panama",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['200.46.153.8/30'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":211,
    "peak_pch":"34.7M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -79.51973,8.9936 ]
    },
    "properties": {
    "FIELD1":492,
    "country":"Panama",
    "total_by_country":2,
    "city":"Panama City",
    "ixpname":"Secretaria Nacional de Ciencia, Tecnologia e Innovacion",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Latin America & Caribbean",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 147.15089,-9.47723 ]
    },
    "properties": {
    "FIELD1":493,
    "country":"Papua New Guinea",
    "total_by_country":2,
    "city":"Port Moresby",
    "ixpname":"PNG Neutral Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['103.82.247.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"http://www.pgix.org.pg/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":2017,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 147.15089,-9.47723 ]
    },
    "properties": {
    "FIELD1":494,
    "country":"Papua New Guinea",
    "total_by_country":2,
    "city":"Port Moresby",
    "ixpname":"PNG-IXP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":2015,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -54.61111,-25.50972 ]
    },
    "properties": {
    "FIELD1":495,
    "country":"Paraguay",
    "total_by_country":2,
    "city":"Ciudad del Este",
    "ixpname":"IX-CDE",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":4,
    "peak_pch":"3G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -57.647,-25.28646 ]
    },
    "properties": {
    "FIELD1":496,
    "country":"Paraguay",
    "total_by_country":2,
    "city":"Asuncion",
    "ixpname":"Punto de Intercambio de Tr?fico de Paraguay",
    "alternatenames":"['IXpy', 'IX.py']",
    "prefixes":"{'ipv4': ['201.217.14.0/24'], 'ipv6': ['2001:1320:cafe::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.py",
    "participants_pch":15,
    "peak_pch":"4.4G",
    "avg_pch":"3G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -77.02824,-12.04318 ]
    },
    "properties": {
    "FIELD1":497,
    "country":"Peru",
    "total_by_country":2,
    "city":"Lima",
    "ixpname":"NAP Peru",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.223.130.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":15,
    "peak_pch":"36G",
    "avg_pch":"25G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -77.02824,-12.04318 ]
    },
    "properties": {
    "FIELD1":498,
    "country":"Peru",
    "total_by_country":2,
    "city":"Lima",
    "ixpname":"PIT Peru",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['45.183.47.0/24'], 'ipv6': ['2803:cd60:6411:5::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.pitperu.net",
    "participants_pch":12,
    "peak_pch":"52G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 121.0509,14.6488 ]
    },
    "properties": {
    "FIELD1":499,
    "country":"Philippines",
    "total_by_country":4,
    "city":"Quezon City",
    "ixpname":"Bayan Telecommunications Internet and Gaming Exchange",
    "alternatenames":"['Bayan Telecommunications Internet and Gaming Exchange']",
    "prefixes":"{'ipv4': ['202.78.121.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 121.03269,14.55027 ]
    },
    "properties": {
    "FIELD1":500,
    "country":"Philippines",
    "total_by_country":4,
    "city":"Makati City",
    "ixpname":"GIX",
    "alternatenames":"['Globe Internet Exchange']",
    "prefixes":"{'ipv4': ['203.177.27.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.globe.com.ph/business",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 120.9822,14.6042 ]
    },
    "properties": {
    "FIELD1":501,
    "country":"Philippines",
    "total_by_country":4,
    "city":"Manila",
    "ixpname":"GetaFIX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['103.104.19.0/24'], 'ipv6': ['2401:fdc0::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://getafix.ph/",
    "participants_pch":5,
    "peak_pch":"20G",
    "avg_pch":"12G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 120.9822,14.6042 ]
    },
    "properties": {
    "FIELD1":502,
    "country":"Philippines",
    "total_by_country":4,
    "city":"Manila",
    "ixpname":"Philippine Open Internet Exchange",
    "alternatenames":"['PHOpenIX', 'PhOpenIX-Manila', 'Philippine Open Internet Exchange (Manila)']",
    "prefixes":"{'ipv4': ['198.32.172.0/24'], 'ipv6': ['2001:478:172::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.phopenix.net",
    "participants_pch":60,
    "peak_pch":"66G",
    "avg_pch":"41G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2007,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 18.53188,54.51889 ]
    },
    "properties": {
    "FIELD1":503,
    "country":"Poland",
    "total_by_country":18,
    "city":"Gdynia",
    "ixpname":"APLIX",
    "alternatenames":"['Aplix - Aplitt IXP']",
    "prefixes":"{'ipv4': ['185.42.185.0/24'], 'ipv6': ['2a01:65a0:a5::/48']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.aplix.pl",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 17.95578,52.65806 ]
    },
    "properties": {
    "FIELD1":504,
    "country":"Poland",
    "total_by_country":18,
    "city":"Mogilno",
    "ixpname":"CePIX.pl",
    "alternatenames":"['Central Polish Internet eXchange']",
    "prefixes":"{'ipv4': ['193.8.61.192/26'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://cepix.pl/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 19.93658,50.06143 ]
    },
    "properties": {
    "FIELD1":505,
    "country":"Poland",
    "total_by_country":18,
    "city":"Krakow",
    "ixpname":"Cracow Internet Exchange",
    "alternatenames":"['CIX KR', 'CIX - Cracow Internet Exchange']",
    "prefixes":"{'ipv4': ['93.159.151.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.ix.krakow.pl/",
    "participants_pch":52,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 19.02754,50.25841 ]
    },
    "properties": {
    "FIELD1":506,
    "country":"Poland",
    "total_by_country":18,
    "city":"Katowice",
    "ixpname":"EPIX.Katowice",
    "alternatenames":"['EPIX.Katowice', 'Stowarzyszenie na Rzecz Rozwoju Spoleczenstwa Informacyjnego e-Poludnie']",
    "prefixes":"{'ipv4': ['178.216.40.0/21', '195.191.170.0/23'], 'ipv6': ['2001:7f8:5b::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.epix.net.pl/",
    "participants_pch":430,
    "peak_pch":"700G",
    "avg_pch":"100K",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 21.01178,52.22977 ]
    },
    "properties": {
    "FIELD1":507,
    "country":"Poland",
    "total_by_country":18,
    "city":"Warsaw",
    "ixpname":"EPIX.Warsaw-KIX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['91.212.9.0/24', '89.46.144.0/21'], 'ipv6': ['2001:678:3ac::/48']}",
    "sources":"['he']",
    "url":"http://www.epix.net.pl/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 21.01178,52.22977 ]
    },
    "properties": {
    "FIELD1":508,
    "country":"Poland",
    "total_by_country":18,
    "city":"Warsaw",
    "ixpname":"EPIX.Warszawa-KIX",
    "alternatenames":"['EPIX']",
    "prefixes":"{'ipv4': ['89.46.144.0/21'], 'ipv6': ['2001:7f8:69::/64', '2001:678:3ac::/48']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.epix.net.pl/",
    "participants_pch":350,
    "peak_pch":"1.3T",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 21.01178,52.22977 ]
    },
    "properties": {
    "FIELD1":509,
    "country":"Poland",
    "total_by_country":18,
    "city":"Warsaw",
    "ixpname":"Equinix IX Warsaw (ex-PLIX)",
    "alternatenames":"['PLIX', 'Polish Internet Exchange']",
    "prefixes":"{'ipv4': ['195.182.218.0/23'], 'ipv6': ['2001:7f8:42::/48']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.plix.pl/",
    "participants_pch":266,
    "peak_pch":"883G",
    "avg_pch":"521G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2006,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 18.64912,54.35227 ]
    },
    "properties": {
    "FIELD1":510,
    "country":"Poland",
    "total_by_country":18,
    "city":"Gdansk",
    "ixpname":"GIX Gdansk",
    "alternatenames":"['Gdansk Internet eXchange']",
    "prefixes":"{'ipv4': ['188.116.45.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.gix.gda.pl",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 21.01178,52.22977 ]
    },
    "properties": {
    "FIELD1":511,
    "country":"Poland",
    "total_by_country":18,
    "city":"Warsaw",
    "ixpname":"HVIX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['188.128.254.128/26'], 'ipv6': ['2a02:25af:ffff::/64']}",
    "sources":"['he']",
    "url":"",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 19.47395,51.77058 ]
    },
    "properties": {
    "FIELD1":512,
    "country":"Poland",
    "total_by_country":18,
    "city":"Lodz",
    "ixpname":"IX.LODZ.PL",
    "alternatenames":"['IX.LODZ.PL - ÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂ¡ÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂÃÂ§??dzki W?ze?? Telekomunikacyjny']",
    "prefixes":"{'ipv4': ['193.151.115.0/24', '193.151.113.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"http://ix.lodz.pl",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 19.47395,51.77058 ]
    },
    "properties": {
    "FIELD1":513,
    "country":"Poland",
    "total_by_country":18,
    "city":"Lodz",
    "ixpname":"Lodz Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":18,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 16.92993,52.40692 ]
    },
    "properties": {
    "FIELD1":514,
    "country":"Poland",
    "total_by_country":18,
    "city":"Poznan",
    "ixpname":"Poznan Internet Exchange",
    "alternatenames":"['POZIX']",
    "prefixes":"{'ipv4': ['185.1.4.0/22', '185.1.4.0/24'], 'ipv6': ['2001:7f8:4b::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.pozix.pl/",
    "participants_pch":15,
    "peak_pch":"223G",
    "avg_pch":"90G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2006,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 21.99901,50.04132 ]
    },
    "properties": {
    "FIELD1":515,
    "country":"Poland",
    "total_by_country":18,
    "city":"Rzeszow",
    "ixpname":"RZ-IX",
    "alternatenames":"['Rzeszowski Punkt Wymiany Ruchu']",
    "prefixes":"{'ipv4': ['185.1.42.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 21.01178,52.22977 ]
    },
    "properties": {
    "FIELD1":517,
    "country":"Poland",
    "total_by_country":18,
    "city":"Warsaw",
    "ixpname":"TPIX - Internet Exchange",
    "alternatenames":"['TPIX']",
    "prefixes":"{'ipv4': ['195.149.232.0/23'], 'ipv6': ['2001:7f8:27::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.tpix.pl/en",
    "participants_pch":214,
    "peak_pch":"728G",
    "avg_pch":"374G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 21.01178,52.22977 ]
    },
    "properties": {
    "FIELD1":518,
    "country":"Poland",
    "total_by_country":18,
    "city":"Warsaw",
    "ixpname":"Thinx Poland",
    "alternatenames":"['Thinx']",
    "prefixes":"{'ipv4': ['212.91.0.0/22'], 'ipv6': ['2001:7f8:60::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.atman.pl",
    "participants_pch":187,
    "peak_pch":"5.2G",
    "avg_pch":"3.1G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2006,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 19.02754,50.25841 ]
    },
    "properties": {
    "FIELD1":519,
    "country":"Poland",
    "total_by_country":18,
    "city":"Katowice",
    "ixpname":"Tysiaclecie Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 17.03333,51.1 ]
    },
    "properties": {
    "FIELD1":520,
    "country":"Poland",
    "total_by_country":18,
    "city":"Wroclaw",
    "ixpname":"Wroclaw Internet eXchange",
    "alternatenames":"['Wroclaw Internet Exchange']",
    "prefixes":"{'ipv4': ['212.127.92.0/23'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"http://wrix.org",
    "participants_pch":38,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -9.13333,38.71667 ]
    },
    "properties": {
    "FIELD1":521,
    "country":"Portugal",
    "total_by_country":4,
    "city":"Lisbon",
    "ixpname":"DE-CIX Lisbon",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.131.0/24'], 'ipv6': ['2001:7f8:d5::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.de-cix.net/en/locations/portugal/Lisbon",
    "participants_pch":14,
    "peak_pch":"10.8G",
    "avg_pch":"7.3G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -9.13333,38.71667 ]
    },
    "properties": {
    "FIELD1":522,
    "country":"Portugal",
    "total_by_country":4,
    "city":"Lisbon",
    "ixpname":"Equinix Lisbon",
    "alternatenames":"['Equinix Internet Exchange Lisbon']",
    "prefixes":"{'ipv4': ['185.1.116.0/24'], 'ipv6': ['2001:7f8:c7::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.equinix.com/home/lisbon/",
    "participants_pch":13,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -9.13333,38.71667 ]
    },
    "properties": {
    "FIELD1":523,
    "country":"Portugal",
    "total_by_country":4,
    "city":"Lisbon",
    "ixpname":"Gigabit Portuguese Internet Exchange Point",
    "alternatenames":"['GigaPIX', 'GIGAbit Portuguese Internet eXchange']",
    "prefixes":"{'ipv4': ['193.136.250.0/24', '193.136.251.0/26'], 'ipv6': ['2001:7f8:a:1::/64', '2001:7f8:a:2::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.gigapix.pt",
    "participants_pch":33,
    "peak_pch":"66.8G",
    "avg_pch":"41G",
    "status_pch":"unknown",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1995,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -8.61099,41.14961 ]
    },
    "properties": {
    "FIELD1":524,
    "country":"Portugal",
    "total_by_country":4,
    "city":"Porto",
    "ixpname":"Gigabit Portuguese Internet Exchange Point Oporto",
    "alternatenames":"['GIGAbit Portuguese Internet eXchange OPorto', 'GigaPIX Oporto']",
    "prefixes":"{'ipv4': ['193.136.251.96/27'], 'ipv6': ['2001:7f8:a:11::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.gigapix.pt",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -66.10572,18.46633 ]
    },
    "properties": {
    "FIELD1":525,
    "country":"Puerto Rico",
    "total_by_country":1,
    "city":"San Juan",
    "ixpname":"Puerto Rico Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['204.138.0.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"https://www.puertorico-ix.com",
    "participants_pch":6,
    "peak_pch":"1.8G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 51.53096,25.28545 ]
    },
    "properties": {
    "FIELD1":526,
    "country":"Qatar",
    "total_by_country":1,
    "city":"Doha",
    "ixpname":"Doha IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['198.32.72.0/24'], 'ipv6': ['2001:1a10:cd:2::/64']}",
    "sources":"['pdb', 'he']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"Middle East & North Africa",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 26.10626,44.43225 ]
    },
    "properties": {
    "FIELD1":527,
    "country":"Romania",
    "total_by_country":8,
    "city":"Bucharest",
    "ixpname":"Balcan-IX",
    "alternatenames":"['BALCAN-IX']",
    "prefixes":"{'ipv4': ['80.97.248.0/24', '80.97.248.0/23'], 'ipv6': ['2a02:d10:80::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.balcan-ix.net",
    "participants_pch":46,
    "peak_pch":"18G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 26.10626,44.43225 ]
    },
    "properties": {
    "FIELD1":528,
    "country":"Romania",
    "total_by_country":8,
    "city":"Bucharest",
    "ixpname":"InterLAN-IX",
    "alternatenames":"['InterLAN Internet Exchange']",
    "prefixes":"{'ipv4': ['86.104.125.0/24'], 'ipv6': ['2001:7f8:64:225::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.interlan.ro/en/",
    "participants_pch":83,
    "peak_pch":"200G",
    "avg_pch":"128G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 26.10626,44.43225 ]
    },
    "properties": {
    "FIELD1":529,
    "country":"Romania",
    "total_by_country":8,
    "city":"Bucharest",
    "ixpname":"LL-IX",
    "alternatenames":"['LLHost Inc. SRL']",
    "prefixes":"{'ipv4': ['5.101.92.0/22'], 'ipv6': ['2001:678:4fc::/48']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.ll-ix.com",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 25.4567,44.92543 ]
    },
    "properties": {
    "FIELD1":530,
    "country":"Romania",
    "total_by_country":8,
    "city":"Targoviste",
    "ixpname":"LNK-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': ['2a0d:f407::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 26.10626,44.43225 ]
    },
    "properties": {
    "FIELD1":531,
    "country":"Romania",
    "total_by_country":8,
    "city":"Bucharest",
    "ixpname":"RoNIX",
    "alternatenames":"['Romanian Internet Exchange']",
    "prefixes":"{'ipv4': ['217.156.113.0/24', '185.1.103.0/24'], 'ipv6': ['2001:7f8:49::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://anisp.ro/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 26.10626,44.43225 ]
    },
    "properties": {
    "FIELD1":532,
    "country":"Romania",
    "total_by_country":8,
    "city":"Bucharest",
    "ixpname":"Romania Commercial Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":2020,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 26.10626,44.43225 ]
    },
    "properties": {
    "FIELD1":533,
    "country":"Romania",
    "total_by_country":8,
    "city":"Bucharest",
    "ixpname":"Romania Internet eXchange Point",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":3,
    "peak_pch":"1G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 44.4379269,26.024598 ]
    },
    "properties": {
    "FIELD1":534,
    "country":"Romania",
    "total_by_country":8,
    "city":"Bucharest",
    "ixpname":"Romanian National Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['217.156.113.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":38,
    "peak_pch":"47G",
    "avg_pch":"30G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 60.6122,56.8519 ]
    },
    "properties": {
    "FIELD1":535,
    "country":"Russia",
    "total_by_country":47,
    "city":"Ekaterinburg",
    "ixpname":"CLOUD-IX EKT",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['31.28.29.0/24'], 'ipv6': ['2a00:13c0:3:9::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.cloud-ix.net/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 37.61556,55.75222 ]
    },
    "properties": {
    "FIELD1":536,
    "country":"Russia",
    "total_by_country":47,
    "city":"Moscow",
    "ixpname":"CLOUD-IX MSK",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['31.28.19.0/24'], 'ipv6': ['2a00:13c0:3:1::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.cloud-ix.net/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 30.31413,59.93863 ]
    },
    "properties": {
    "FIELD1":537,
    "country":"Russia",
    "total_by_country":47,
    "city":"St. Petersburg",
    "ixpname":"CLOUD-IX SPB",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['31.28.18.0/24'], 'ipv6': ['2a00:13c0:3:2::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.cloud-ix.net/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 39.1843,51.67204 ]
    },
    "properties": {
    "FIELD1":538,
    "country":"Russia",
    "total_by_country":47,
    "city":"Voronezh",
    "ixpname":"CLOUD-IX VRJ",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['31.28.17.0/24'], 'ipv6': ['2a00:13c0:3:5::/64']}",
    "sources":"['pdb']",
    "url":"http://www.cloud-ix.net/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 30.31413,59.93863 ]
    },
    "properties": {
    "FIELD1":539,
    "country":"Russia",
    "total_by_country":47,
    "city":"St. Petersburg",
    "ixpname":"CODIX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.23.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"http://miran.ru",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 61.42915,55.15402 ]
    },
    "properties": {
    "FIELD1":540,
    "country":"Russia",
    "total_by_country":47,
    "city":"Chelyabinsk",
    "ixpname":"Chelyabinsk Peering Point",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 113.50087,52.03171 ]
    },
    "properties": {
    "FIELD1":541,
    "country":"Russia",
    "total_by_country":47,
    "city":"Chita",
    "ixpname":"DV-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.118.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://dv-ix.ru",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 135.08379,48.48271 ]
    },
    "properties": {
    "FIELD1":543,
    "country":"Russia",
    "total_by_country":47,
    "city":"Khabarovsk",
    "ixpname":"DataIX Khabarovsk",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":30,
    "peak_pch":"1.6M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 37.61556,55.75222 ]
    },
    "properties": {
    "FIELD1":544,
    "country":"Russia",
    "total_by_country":47,
    "city":"Moscow",
    "ixpname":"DataIX Moscow",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":282,
    "peak_pch":"1.6T",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 82.9346,55.0415 ]
    },
    "properties": {
    "FIELD1":545,
    "country":"Russia",
    "total_by_country":47,
    "city":"Novosibirsk",
    "ixpname":"DataIX Novosibirsk",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":27,
    "peak_pch":"8G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 30.31413,59.93863 ]
    },
    "properties": {
    "FIELD1":546,
    "country":"Russia",
    "total_by_country":47,
    "city":"St. Petersburg",
    "ixpname":"DataIX St Petersburg",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":298,
    "peak_pch":"140G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 55.96779,54.74306 ]
    },
    "properties": {
    "FIELD1":547,
    "country":"Russia",
    "total_by_country":47,
    "city":"Ufa",
    "ixpname":"DataIX Ufa",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":94,
    "peak_pch":"120G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 37.61556,55.75222 ]
    },
    "properties": {
    "FIELD1":548,
    "country":"Russia",
    "total_by_country":47,
    "city":"Moscow",
    "ixpname":"DataLine-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.52.0/24'], 'ipv6': ['2001:7f8:62:52::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.dtln.ru/en/services/telecom/dataline-ix",
    "participants_pch":84,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 37.61556,55.75222 ]
    },
    "properties": {
    "FIELD1":549,
    "country":"Russia",
    "total_by_country":47,
    "city":"Moscow",
    "ixpname":"Eurasia Peering IX",
    "alternatenames":"['Eurasia Peering LLC']",
    "prefixes":"{'ipv4': ['185.232.60.0/23'], 'ipv6': ['2a0d:e180::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://eurasiapeering.com/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 30.31413,59.93863 ]
    },
    "properties": {
    "FIELD1":550,
    "country":"Russia",
    "total_by_country":47,
    "city":"Saint Petersburg",
    "ixpname":"Global-IX",
    "alternatenames":"['GlobalNet']",
    "prefixes":"{'ipv4': ['109.239.136.0/23'], 'ipv6': ['2001:b28:3ff::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://global-ix.ru/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 92.86717,56.01839 ]
    },
    "properties": {
    "FIELD1":551,
    "country":"Russia",
    "total_by_country":47,
    "city":"Krasnoyarsk",
    "ixpname":"Krasnoyarsk Internet Exchange",
    "alternatenames":"['Krasnoyarsk Internet Exchange']",
    "prefixes":"{'ipv4': ['185.1.13.0/24'], 'ipv6': ['2001:7f8:78::/48', '2001:7f8:78::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://webra.ru",
    "participants_pch":48,
    "peak_pch":"85G",
    "avg_pch":"51.2G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2006,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 60.6122,56.8519 ]
    },
    "properties": {
    "FIELD1":552,
    "country":"Russia",
    "total_by_country":47,
    "city":"Ekaterinburg",
    "ixpname":"MSK-IX Ekaterinburg",
    "alternatenames":"['MSK-IX Ekaterinburg (former EKT-IX)']",
    "prefixes":"{'ipv4': ['194.85.107.0/24'], 'ipv6': ['2001:7f8:20:301::107:0/128', '2001:7f8:20:301::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.msk-ix.ru/en/ix/ekt",
    "participants_pch":46,
    "peak_pch":"43.2G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 49.12214,55.78874 ]
    },
    "properties": {
    "FIELD1":553,
    "country":"Russia",
    "total_by_country":47,
    "city":"Kazan",
    "ixpname":"MSK-IX Kazan",
    "alternatenames":"['MSK-IX Kazan (former KZN-IX)']",
    "prefixes":"{'ipv4': ['194.190.119.0/24'], 'ipv6': ['2001:7f8:20:801::119:0/128', '2001:7f8:20:801::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.msk-ix.ru/en/ix/kzn",
    "participants_pch":8,
    "peak_pch":"1.12G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 37.61556,55.75222 ]
    },
    "properties": {
    "FIELD1":554,
    "country":"Russia",
    "total_by_country":47,
    "city":"Moscow",
    "ixpname":"MSK-IX Moscow",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['193.232.244.0/24', '195.208.208.0/21'], 'ipv6': ['2001:7f8:20:101::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.msk-ix.ru/en",
    "participants_pch":467,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1995,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 82.9346,55.0415 ]
    },
    "properties": {
    "FIELD1":555,
    "country":"Russia",
    "total_by_country":47,
    "city":"Novosibirsk",
    "ixpname":"MSK-IX Novosibirsk",
    "alternatenames":"['MSK-IX Novosibirsk (former NSK-IX)']",
    "prefixes":"{'ipv4': ['193.232.87.0/24'], 'ipv6': ['2001:7f8:20:401::87:0/128', '2001:7f8:20:401::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.msk-ix.ru/en/ix/nsk",
    "participants_pch":63,
    "peak_pch":"26.5G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 39.72328,47.23135 ]
    },
    "properties": {
    "FIELD1":556,
    "country":"Russia",
    "total_by_country":47,
    "city":"Rostov-on-Don",
    "ixpname":"MSK-IX Rostov-on-Don",
    "alternatenames":"['MSK-IX Rostov-on-Don (former RND-IX)']",
    "prefixes":"{'ipv4': ['193.232.140.0/24'], 'ipv6': ['2001:7f8:20:501::140:0/128', '2001:7f8:20:501::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.msk-ix.ru/en/ix/rnd",
    "participants_pch":15,
    "peak_pch":"4.16G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 50.15,53.20007 ]
    },
    "properties": {
    "FIELD1":557,
    "country":"Russia",
    "total_by_country":47,
    "city":"Samara",
    "ixpname":"MSK-IX Samara",
    "alternatenames":"['MSK-IX Samara (former SMR-IX)']",
    "prefixes":"{'ipv4': ['193.232.135.0/24'], 'ipv6': ['2001:7f8:20:601::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.msk-ix.ru/en/ix/smr",
    "participants_pch":17,
    "peak_pch":"12.4G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 30.31413,59.93863 ]
    },
    "properties": {
    "FIELD1":558,
    "country":"Russia",
    "total_by_country":47,
    "city":"St. Petersburg",
    "ixpname":"MSK-IX St. Petersburg",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['194.85.177.0/24'], 'ipv6': ['2001:7f8:20:201::/64']}",
    "sources":"['pch', 'he']",
    "url":"http://www.msk-ix.ru/en/ix/spb",
    "participants_pch":92,
    "peak_pch":"83.4G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 41.9734,45.0428 ]
    },
    "properties": {
    "FIELD1":559,
    "country":"Russia",
    "total_by_country":47,
    "city":"Stavropol",
    "ixpname":"MSK-IX Stavropol",
    "alternatenames":"['MSK-IX Stavropol (former STW-IX)']",
    "prefixes":"{'ipv4': ['194.85.177.0/24'], 'ipv6': ['2001:7f8:20:901::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.msk-ix.ru/en/ix/stw",
    "participants_pch":7,
    "peak_pch":"240M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 131.87353,43.10562 ]
    },
    "properties": {
    "FIELD1":560,
    "country":"Russia",
    "total_by_country":47,
    "city":"Vladivostok",
    "ixpname":"MSK-IX Vladivostok",
    "alternatenames":"['MSK-IX Vladivostok (former VLV-IX)']",
    "prefixes":"{'ipv4': ['193.232.136.0/24'], 'ipv6': ['2001:7f8:20:701::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.msk-ix.ru/en/ix/vlv",
    "participants_pch":14,
    "peak_pch":"528M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 44.9629296,34.0215339 ]
    },
    "properties": {
    "FIELD1":561,
    "country":"Russia",
    "total_by_country":47,
    "city":"Simferopol",
    "ixpname":"Media-IX",
    "alternatenames":"['Media-IX']",
    "prefixes":"{'ipv4': ['193.34.200.128/25'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"http://m-ix.net/",
    "participants_pch":59,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 37.61556,55.75222 ]
    },
    "properties": {
    "FIELD1":562,
    "country":"Russia",
    "total_by_country":47,
    "city":"Moscow",
    "ixpname":"MegaFon-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['62.89.200.0/23'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"http://megafon.ru",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 30.31413,59.93863 ]
    },
    "properties": {
    "FIELD1":563,
    "country":"Russia",
    "total_by_country":47,
    "city":"St. Petersburg",
    "ixpname":"NW-IX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 44.00205,56.32867 ]
    },
    "properties": {
    "FIELD1":564,
    "country":"Russia",
    "total_by_country":47,
    "city":"Nizhny Novgorod",
    "ixpname":"Nizhny Novgorod Internet Exchange",
    "alternatenames":"['Nizhny Novgorod  Internet Exchange']",
    "prefixes":"{'ipv4': ['91.230.65.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://ix-nnov.ru/",
    "participants_pch":15,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 73.36859,54.99244 ]
    },
    "properties": {
    "FIELD1":565,
    "country":"Russia",
    "total_by_country":47,
    "city":"Omsk",
    "ixpname":"Omsk Internet exchange",
    "alternatenames":"['OMSK-IX', 'Omsk Internet Exchange']",
    "prefixes":"{'ipv4': ['94.137.48.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"http://omsk-ix.ru/",
    "participants_pch":15,
    "peak_pch":"10.7G",
    "avg_pch":"5.2G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2006,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 30.31413,59.93863 ]
    },
    "properties": {
    "FIELD1":566,
    "country":"Russia",
    "total_by_country":47,
    "city":"St. Petersburg",
    "ixpname":"PIRIX",
    "alternatenames":"['Pirix Internet Exchange']",
    "prefixes":"{'ipv4': ['193.28.6.0/24'], 'ipv6': ['2001:7f8:82::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.pirix.ru",
    "participants_pch":50,
    "peak_pch":"7.9G",
    "avg_pch":"5.1G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 37.61556,55.75222 ]
    },
    "properties": {
    "FIELD1":567,
    "country":"Russia",
    "total_by_country":47,
    "city":"Moscow",
    "ixpname":"PITER-IX Moscow",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['31.44.186.0/24', '31.44.187.0/24', '37.9.49.0/24', '193.27.39.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"https://piter-ix.ru",
    "participants_pch":53,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 30.31413,59.93863 ]
    },
    "properties": {
    "FIELD1":568,
    "country":"Russia",
    "total_by_country":47,
    "city":"St. Petersburg",
    "ixpname":"PITER-IX St. Petersburg",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['31.44.186.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":96,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 83.76361,53.36056 ]
    },
    "properties": {
    "FIELD1":569,
    "country":"Russia",
    "total_by_country":47,
    "city":"Barnaul",
    "ixpname":"SFO-IX",
    "alternatenames":"['Milecom LLC, project SFO-IX']",
    "prefixes":"{'ipv4': ['91.221.180.0/23'], 'ipv6': ['2a0b:9fc0:1::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.milecom.ru",
    "participants_pch":121,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 37.61556,55.75222 ]
    },
    "properties": {
    "FIELD1":570,
    "country":"Russia",
    "total_by_country":47,
    "city":"Moscow",
    "ixpname":"SVAO-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['89.222.236.0/24'], 'ipv6': []}",
    "sources":"['pch', 'he']",
    "url":"http://www.svao-ix.ru/",
    "participants_pch":76,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 46.00861,51.54056 ]
    },
    "properties": {
    "FIELD1":571,
    "country":"Russia",
    "total_by_country":47,
    "city":"Saratov",
    "ixpname":"Saratov Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":2005,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 38.97603,45.04484 ]
    },
    "properties": {
    "FIELD1":572,
    "country":"Russia",
    "total_by_country":47,
    "city":"Krasnodar",
    "ixpname":"Sea-IX Internet exchange",
    "alternatenames":"['Sea-IX', 'South Russia IX']",
    "prefixes":"{'ipv4': ['91.240.225.0/24'], 'ipv6': ['2001:7f8:6f::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://sea-ix.ru/",
    "participants_pch":47,
    "peak_pch":"48G",
    "avg_pch":"28.5G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 92.86717,56.01839 ]
    },
    "properties": {
    "FIELD1":573,
    "country":"Russia",
    "total_by_country":47,
    "city":"Krasnoyarsk",
    "ixpname":"Sibir-IX",
    "alternatenames":"['Krasnoyarsk Internet Exchange']",
    "prefixes":"{'ipv4': ['91.230.210.0/23', '84.22.159.0/24'], 'ipv6': ['2001:7f8:ac:142::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.sibir-ix.ru/provider",
    "participants_pch":55,
    "peak_pch":"14.6G",
    "avg_pch":"10.4G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 48.38657,54.32824 ]
    },
    "properties": {
    "FIELD1":574,
    "country":"Russia",
    "total_by_country":47,
    "city":"Ulyanovsk",
    "ixpname":"Simbirsk Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 87.1099,53.7557 ]
    },
    "properties": {
    "FIELD1":575,
    "country":"Russia",
    "total_by_country":47,
    "city":"Novokuznetsk",
    "ixpname":"TN-IX.net",
    "alternatenames":"['TN-IX.net']",
    "prefixes":"{'ipv4': ['185.1.64.0/24'], 'ipv6': ['2001:7f8:5::/48']}",
    "sources":"['pdb', 'he']",
    "url":"http://tn-ix.net/",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 84.97437,56.49771 ]
    },
    "properties": {
    "FIELD1":576,
    "country":"Russia",
    "total_by_country":47,
    "city":"Tomsk",
    "ixpname":"Tomsk Internet eXchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['82.117.167.0/25'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":43,
    "peak_pch":"1.1G",
    "avg_pch":"800M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 48.38657,54.32824 ]
    },
    "properties": {
    "FIELD1":577,
    "country":"Russia",
    "total_by_country":47,
    "city":"Ulyanovsk",
    "ixpname":"Ulyanovsk Internet Exchange",
    "alternatenames":"['Ulyanovsk Internet eXchange']",
    "prefixes":"{'ipv4': ['185.1.19.0/24'], 'ipv6': ['2001:7f8:7d::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.uln-ix.ru/",
    "participants_pch":17,
    "peak_pch":"3.28G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 39.87368,57.62987 ]
    },
    "properties": {
    "FIELD1":578,
    "country":"Russia",
    "total_by_country":47,
    "city":"Yaroslavl",
    "ixpname":"Volga-IX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 37.61556,55.75222 ]
    },
    "properties": {
    "FIELD1":579,
    "country":"Russia",
    "total_by_country":47,
    "city":"Moscow",
    "ixpname":"W-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['193.106.112.0/23'], 'ipv6': ['2a00:1b30::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.w-ix.ru",
    "participants_pch":177,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 39.87368,57.62987 ]
    },
    "properties": {
    "FIELD1":580,
    "country":"Russia",
    "total_by_country":47,
    "city":"Yaroslavl",
    "ixpname":"Yaroslavl Internet Exchange",
    "alternatenames":"['YAR-IX']",
    "prefixes":"{'ipv4': ['91.203.127.0/24'], 'ipv6': ['2001:7f8:77::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://yar-ix.net",
    "participants_pch":9,
    "peak_pch":"295M",
    "avg_pch":"193M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 30.05885,-1.94995 ]
    },
    "properties": {
    "FIELD1":582,
    "country":"Rwanda",
    "total_by_country":1,
    "city":"Kigali",
    "ixpname":"Rwanda Internet exchange",
    "alternatenames":"['RINEX', 'Rwanda Internet Exchange']",
    "prefixes":"{'ipv4': ['196.223.12.128/25', '196.223.12.0/24', '196.49.7.0/24'], 'ipv6': ['2001:43f8:150::/64', '2001:43f8:150::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.rinex.org.rw",
    "participants_pch":9,
    "peak_pch":"2.28G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2003,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 46.72185,24.68773 ]
    },
    "properties": {
    "FIELD1":583,
    "country":"Saudi Arabia",
    "total_by_country":2,
    "city":"Riyadh",
    "ixpname":"Internet Exchange of Saudi Arabia",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Middle East & North Africa",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 46.72185,24.68773 ]
    },
    "properties": {
    "FIELD1":584,
    "country":"Saudi Arabia",
    "total_by_country":2,
    "city":"Riyadh",
    "ixpname":"Saudi Arabia Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['212.138.252.0/23', '212.26.66.0/23'], 'ipv6': ['2001:1490:104::/48']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":6,
    "peak_pch":"16G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Middle East & North Africa",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -17.44406,14.6937 ]
    },
    "properties": {
    "FIELD1":585,
    "country":"Senegal",
    "total_by_country":1,
    "city":"Dakar",
    "ixpname":"Senegal IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['196.60.40.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":3,
    "peak_pch":"28M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2017,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 20.46513,44.80401 ]
    },
    "properties": {
    "FIELD1":586,
    "country":"Serbia",
    "total_by_country":1,
    "city":"Belgrade",
    "ixpname":"Serbian Open Exchange",
    "alternatenames":"['Serbian Open eXchange', 'SOX Serbia']",
    "prefixes":"{'ipv4': ['185.1.27.0/24', '193.105.163.0/24'], 'ipv6': ['2001:7f8:1e::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.sox.rs",
    "participants_pch":40,
    "peak_pch":"100G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 103.7041652,1.3143394 ]
    },
    "properties": {
    "FIELD1":587,
    "country":"Singapore",
    "total_by_country":7,
    "city":"Singapore",
    "ixpname":"BBIX Singapore",
    "alternatenames":"['BroadBand Internet eXchange Singapore']",
    "prefixes":"{'ipv4': ['103.231.152.0/22'], 'ipv6': ['2001:df5:b800:bb00::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.bbix.net/en/",
    "participants_pch":47,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 103.7041652,1.3143394 ]
    },
    "properties": {
    "FIELD1":588,
    "country":"Singapore",
    "total_by_country":7,
    "city":"Singapore",
    "ixpname":"Equinix Singapore IBX",
    "alternatenames":"['Equinix Singapore', 'Equinix Singapore Exchange']",
    "prefixes":"{'ipv4': ['27.111.228.0/22'], 'ipv6': ['2001:de8:4::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.equinix.com",
    "participants_pch":156,
    "peak_pch":"650G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 103.7041652,1.3143394 ]
    },
    "properties": {
    "FIELD1":589,
    "country":"Singapore",
    "total_by_country":7,
    "city":"Singapore",
    "ixpname":"MegaPort IX Singapore",
    "alternatenames":"['Megaport MegaIX Singapore', 'MegaIX Singapore']",
    "prefixes":"{'ipv4': ['103.41.12.0/22'], 'ipv6': ['2001:ded::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://megaport.com",
    "participants_pch":26,
    "peak_pch":"30G",
    "avg_pch":"15G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 103.7041652,1.3143394 ]
    },
    "properties": {
    "FIELD1":590,
    "country":"Singapore",
    "total_by_country":7,
    "city":"Singapore",
    "ixpname":"Singapore Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['103.16.102.0/23'], 'ipv6': ['2001:de8:12:100::/56']}",
    "sources":"['he']",
    "url":"https://www.sgix.sg",
    "participants_pch":92,
    "peak_pch":"337G",
    "avg_pch":"250G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 103.7041652,1.3143394 ]
    },
    "properties": {
    "FIELD1":591,
    "country":"Singapore",
    "total_by_country":7,
    "city":"Singapore",
    "ixpname":"Singapore Open Exchange",
    "alternatenames":"['SOX', 'SOX Singapore']",
    "prefixes":"{'ipv4': ['198.32.141.0/24'], 'ipv6': ['2001:de8:d::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.sox.net.sg/",
    "participants_pch":27,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 103.7041652,1.3143394 ]
    },
    "properties": {
    "FIELD1":592,
    "country":"Singapore",
    "total_by_country":7,
    "city":"Singapore",
    "ixpname":"Singapore Telecom Internet Exchange - Singapore",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 103.7041652,1.3143394 ]
    },
    "properties": {
    "FIELD1":593,
    "country":"Singapore",
    "total_by_country":7,
    "city":"Singapore",
    "ixpname":"Thai-IX Singapore by CS Loxinfo",
    "alternatenames":"['Thai-IX Singapore by CS Loxinfo']",
    "prefixes":"{'ipv4': ['27.254.18.0/23'], 'ipv6': ['2404:b0:13:b::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.cslthai-ix.net",
    "participants_pch":10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 17.10674,48.14816 ]
    },
    "properties": {
    "FIELD1":594,
    "country":"Slovakia",
    "total_by_country":3,
    "city":"Bratislava",
    "ixpname":"NIX.SK - exSitelIX",
    "alternatenames":"['Neutral Internet eXchange Slovakia', 'NIX.SK']",
    "prefixes":"{'ipv4': ['194.30.187.0/24'], 'ipv6': ['2001:7f8:91::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.nix.sk/sk",
    "participants_pch":45,
    "peak_pch":"84G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2005,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 21.25808,48.71395 ]
    },
    "properties": {
    "FIELD1":595,
    "country":"Slovakia",
    "total_by_country":3,
    "city":"Kosice",
    "ixpname":"Slovak Internet Exchange Kosice",
    "alternatenames":"['SIX.SK Ko?ice']",
    "prefixes":"{'ipv4': ['192.108.145.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.six.sk",
    "participants_pch":4,
    "peak_pch":"823M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 17.10674,48.14816 ]
    },
    "properties": {
    "FIELD1":596,
    "country":"Slovakia",
    "total_by_country":3,
    "city":"Bratislava",
    "ixpname":"Slovak Internet eXchange Bratislava",
    "alternatenames":"['SIX.SK', 'Slovak Internet eXchange']",
    "prefixes":"{'ipv4': ['192.108.148.0/24'], 'ipv6': ['2001:7f8:2f::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.six.sk",
    "participants_pch":59,
    "peak_pch":"218G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 14.50513,46.05108 ]
    },
    "properties": {
    "FIELD1":597,
    "country":"Slovenia",
    "total_by_country":1,
    "city":"Ljubljana",
    "ixpname":"Slovenian Internet Exchange",
    "alternatenames":"['SIX SI']",
    "prefixes":"{'ipv4': ['193.2.141.0/24', '91.220.194.0/24'], 'ipv6': ['2001:7f8:46::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.arnes.si/infrastructure/six-slovenian-internet-exchange/",
    "participants_pch":27,
    "peak_pch":"68G",
    "avg_pch":"34G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1994,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 45.34375,2.03711 ]
    },
    "properties": {
    "FIELD1":598,
    "country":"Somalia",
    "total_by_country":1,
    "city":"Mogadishu",
    "ixpname":"Somali Internet Exchange Point",
    "alternatenames":"['SoIXP']",
    "prefixes":"{'ipv4': ['196.60.54.0/24'], 'ipv6': ['2001:43f8:11a1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://soixp.so",
    "participants_pch":6,
    "peak_pch":"132K",
    "avg_pch":"14K",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 18.42322,-33.92584 ]
    },
    "properties": {
    "FIELD1":599,
    "country":"South Africa",
    "total_by_country":6,
    "city":"Cape Town",
    "ixpname":"Cape Town Internet Exchange",
    "alternatenames":"['CINX']",
    "prefixes":"{'ipv4': ['196.223.22.0/24', '196.223.23.0/24'], 'ipv6': ['2001:43f8:1f1::/64', '2001:43f8:1f1:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.inx.net.za",
    "participants_pch":23,
    "peak_pch":"12G",
    "avg_pch":"9G",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 31.0292,-29.8579 ]
    },
    "properties": {
    "FIELD1":600,
    "country":"South Africa",
    "total_by_country":6,
    "city":"Durban",
    "ixpname":"Durban Internet eXchange",
    "alternatenames":"['Durban Internet Exchange', 'DINX']",
    "prefixes":"{'ipv4': ['196.223.30.0/24'], 'ipv6': ['2001:43f8:1f2::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.inx.net.za/",
    "participants_pch":39,
    "peak_pch":"5.2G",
    "avg_pch":"2G",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 28.04363,-26.20227 ]
    },
    "properties": {
    "FIELD1":601,
    "country":"South Africa",
    "total_by_country":6,
    "city":"Johannesburg",
    "ixpname":"Johannesburg Internet Exchange",
    "alternatenames":"['JINX']",
    "prefixes":"{'ipv4': ['196.223.14.0/24', '196.223.15.0/24'], 'ipv6': ['2001:43f8:1f0::/64', '2001:43f8:1f0:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.inx.net.za",
    "participants_pch":112,
    "peak_pch":"40G",
    "avg_pch":"35K",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 18.42322,-33.92584 ]
    },
    "properties": {
    "FIELD1":602,
    "country":"South Africa",
    "total_by_country":6,
    "city":"Cape Town",
    "ixpname":"NAPAfrica Cape Town",
    "alternatenames":"['NAPAfrica Cape Town']",
    "prefixes":"{'ipv4': ['196.10.140.0/24'], 'ipv6': ['2001:43f8:6d1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.teraco.co.za",
    "participants_pch":160,
    "peak_pch":"100G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 31.0292,-29.8579 ]
    },
    "properties": {
    "FIELD1":603,
    "country":"South Africa",
    "total_by_country":6,
    "city":"Durban",
    "ixpname":"NAPAfrica IX Durban",
    "alternatenames":"['NAPAfrica Durban']",
    "prefixes":"{'ipv4': ['196.10.141.0/24'], 'ipv6': ['2001:43f8:6d2::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.napafrica.net/napafrica-traffic/durban-internet-exchange/",
    "participants_pch":70,
    "peak_pch":"9.6G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 28.04363,-26.20227 ]
    },
    "properties": {
    "FIELD1":604,
    "country":"South Africa",
    "total_by_country":6,
    "city":"Johannesburg",
    "ixpname":"NAPAfrica IX Johannesburg",
    "alternatenames":"['NAPAfrica Johannesburg']",
    "prefixes":"{'ipv4': ['196.60.8.0/23'], 'ipv6': ['2001:43f8:6d0::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.napafrica.net",
    "participants_pch":308,
    "peak_pch":"800G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 2.15899,41.38879 ]
    },
    "properties": {
    "FIELD1":605,
    "country":"Spain",
    "total_by_country":9,
    "city":"Barcelona",
    "ixpname":"Catalunya Neutral Internet Exchange Point",
    "alternatenames":"['CATNIX', 'Catalunya Neutral Internet Exchange']",
    "prefixes":"{'ipv4': ['193.242.98.0/24'], 'ipv6': ['2001:7f8:2a::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.catnix.net",
    "participants_pch":43,
    "peak_pch":"52G",
    "avg_pch":"33G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1999,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -3.70256,40.4165 ]
    },
    "properties": {
    "FIELD1":606,
    "country":"Spain",
    "total_by_country":9,
    "city":"Madrid",
    "ixpname":"DE-CIX Madrid",
    "alternatenames":"['Deutscher Commercial Internet Exchange Madrid']",
    "prefixes":"{'ipv4': ['185.1.68.0/24'], 'ipv6': ['2001:7f8:a0::/48', '2001:7f8:a0::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://mad.de-cix.net",
    "participants_pch":135,
    "peak_pch":"394G",
    "avg_pch":"229G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -3.70256,40.4165 ]
    },
    "properties": {
    "FIELD1":607,
    "country":"Spain",
    "total_by_country":9,
    "city":"Madrid",
    "ixpname":"ESPANIX Madrid Lower LAN",
    "alternatenames":"['ESPANIX Lower LAN', 'Espana Internet Exchange Lower LAN']",
    "prefixes":"{'ipv4': ['193.149.1.0/24'], 'ipv6': ['2001:7f8:f::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.espanix.net",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -3.70256,40.4165 ]
    },
    "properties": {
    "FIELD1":608,
    "country":"Spain",
    "total_by_country":9,
    "city":"Madrid",
    "ixpname":"ESPANIX Madrid Upper LAN",
    "alternatenames":"['ESPANIX Upper LAN', 'Espana Internet Exchange Upper LAN']",
    "prefixes":"{'ipv4': ['185.79.175.0/24'], 'ipv6': ['2001:7f8:f:1::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.espanix.net",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 2.15899,41.38879 ]
    },
    "properties": {
    "FIELD1":609,
    "country":"Spain",
    "total_by_country":9,
    "city":"Barcelona",
    "ixpname":"Equinix Barcelona",
    "alternatenames":"['Equinix Internet Exchange Barcelona']",
    "prefixes":"{'ipv4': ['87.108.41.96/27', '185.1.143.0/24'], 'ipv6': ['2001:7f8:de::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.equinix.com/home/barcelona/",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -3.70256,40.4165 ]
    },
    "properties": {
    "FIELD1":610,
    "country":"Spain",
    "total_by_country":9,
    "city":"Madrid",
    "ixpname":"Equinix Madrid",
    "alternatenames":"['Equinix Internet Exchange Madrid']",
    "prefixes":"{'ipv4': ['185.1.22.0/24'], 'ipv6': ['2001:7f8:c6::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.equinix.com/home/madrid/",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -3.70256,40.4165 ]
    },
    "properties": {
    "FIELD1":611,
    "country":"Spain",
    "total_by_country":9,
    "city":"Madrid",
    "ixpname":"Madrid Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -0.37739,39.46975 ]
    },
    "properties": {
    "FIELD1":612,
    "country":"Spain",
    "total_by_country":9,
    "city":"Valencia",
    "ixpname":"Neutral Internet Exchange Valencia",
    "alternatenames":"['NIXVAL-ix', 'NIXVAL']",
    "prefixes":"{'ipv4': ['213.162.194.0/24'], 'ipv6': ['2a02:23a0:1111:9999::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ixp.nixval.com",
    "participants_pch":13,
    "peak_pch":"20.7G",
    "avg_pch":"10G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -3.70256,40.4165 ]
    },
    "properties": {
    "FIELD1":613,
    "country":"Spain",
    "total_by_country":9,
    "city":"Madrid",
    "ixpname":"Terremark NAP de las Americas - Madrid",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['193.227.132.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":2,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 79.84868,6.93548 ]
    },
    "properties": {
    "FIELD1":614,
    "country":"Sri Lanka",
    "total_by_country":1,
    "city":"Colombo",
    "ixpname":"Sri Lanka Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['203.143.4.0/27'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"South Asia",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -61.00614,13.9957 ]
    },
    "properties": {
    "FIELD1":615,
    "country":"St. Lucia",
    "total_by_country":1,
    "city":"Castries",
    "ixpname":"Saint Lucia IXP",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['208.169.85.248/29'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -61.2290382,13.1567684 ]
    },
    "properties": {
    "FIELD1":616,
    "country":"St. Vincent and the Grenadines",
    "total_by_country":1,
    "city":"Kingstown",
    "ixpname":"SVGIX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Latin America & Caribbean",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 32.53241,15.55177 ]
    },
    "properties": {
    "FIELD1":617,
    "country":"Sudan",
    "total_by_country":1,
    "city":"Khartoum",
    "ixpname":"Sudan Internet Exchange Point",
    "alternatenames":"['SIXP Sudan']",
    "prefixes":"{'ipv4': ['196.223.20.0/24'], 'ipv6': ['2001:43f8:7f0:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.sixp.sd",
    "participants_pch":7,
    "peak_pch":"16.4M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2011,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 12.9401,57.72101 ]
    },
    "properties": {
    "FIELD1":618,
    "country":"Sweden",
    "total_by_country":15,
    "city":"Boras",
    "ixpname":"Boras Internet Exchange",
    "alternatenames":"['Bor?s Internet Exchange']",
    "prefixes":"{'ipv4': ['195.60.81.0/26'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"http://www.bor-ix.se/index.php?page=info",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 18.06871,59.32938 ]
    },
    "properties": {
    "FIELD1":619,
    "country":"Sweden",
    "total_by_country":15,
    "city":"Stockholm",
    "ixpname":"Equinix Stockholm",
    "alternatenames":"['Equinix Internet Exchange Stockholm']",
    "prefixes":"{'ipv4': ['185.1.107.0/24'], 'ipv6': ['2001:7f8:c1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.equinix.se/services/interconnection-connectivity/internet-exchange/",
    "participants_pch":13,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 17.14174,60.67452 ]
    },
    "properties": {
    "FIELD1":620,
    "country":"Sweden",
    "total_by_country":15,
    "city":"Gavle",
    "ixpname":"G?strikland-H?lsingland Regional Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 11.96679,57.70716 ]
    },
    "properties": {
    "FIELD1":621,
    "country":"Sweden",
    "total_by_country":15,
    "city":"Gothenburg",
    "ixpname":"Gothenburg Internet Exchange",
    "alternatenames":"['GIX Gothenburg', 'GIX']",
    "prefixes":"{'ipv4': ['194.165.32.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.gix.se",
    "participants_pch":15,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2005,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 13.00073,55.60587 ]
    },
    "properties": {
    "FIELD1":622,
    "country":"Sweden",
    "total_by_country":15,
    "city":"Malmo",
    "ixpname":"Internet exchange point of the Oresund Region",
    "alternatenames":"['IXOR', 'MalmIX Malmo / IXOR', 'Internet eXchange point of the Oresund Region']",
    "prefixes":"{'ipv4': ['193.243.183.64/26'], 'ipv6': ['2001:7f8:53::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.ixor.se",
    "participants_pch":19,
    "peak_pch":"48M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 11.96679,57.70716 ]
    },
    "properties": {
    "FIELD1":623,
    "country":"Sweden",
    "total_by_country":15,
    "city":"Gothenburg",
    "ixpname":"Netnod Gothenburg",
    "alternatenames":"['Netnod Internet Exchange i Sverige AB']",
    "prefixes":"{'ipv4': ['194.68.130.0/24', '195.69.116.0/24'], 'ipv6': ['2001:7f8:d:100::/64', '2001:7f8:d:101::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.netnod.se",
    "participants_pch":13,
    "peak_pch":"12.8G",
    "avg_pch":"7.3G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1998,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 22.15465,65.58415 ]
    },
    "properties": {
    "FIELD1":624,
    "country":"Sweden",
    "total_by_country":15,
    "city":"Lulea",
    "ixpname":"Netnod Lulea",
    "alternatenames":"['Netnod Lule?', 'Netnod Internet Exchange i Sverige AB']",
    "prefixes":"{'ipv4': ['194.68.131.64/26', '194.68.131.0/24'], 'ipv6': ['2001:7f8:d:400::/64', '2001:7f8:d:401::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.netnod.se",
    "participants_pch":6,
    "peak_pch":"6M",
    "avg_pch":"2.5M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 18.06871,59.32938 ]
    },
    "properties": {
    "FIELD1":625,
    "country":"Sweden",
    "total_by_country":15,
    "city":"Stockholm",
    "ixpname":"Netnod Stockholm",
    "alternatenames":"['Netnod Internet Exchange i Sverige AB']",
    "prefixes":"{'ipv4': ['194.68.123.0/24', '194.68.128.0/24', '195.245.240.0/24', '195.69.119.0/24'], 'ipv6': ['2001:7f8:d:fb::/64', '2001:7f8:d:fc::/64', '2001:7f8:d:fe::/64', '2001:7f8:d:ff::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.netnod.se",
    "participants_pch":162,
    "peak_pch":"1.2T",
    "avg_pch":"820G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 17.3063,62.39129 ]
    },
    "properties": {
    "FIELD1":626,
    "country":"Sweden",
    "total_by_country":15,
    "city":"Sundsvall",
    "ixpname":"Netnod Sundsvall",
    "alternatenames":"['Netnod Internet Exchange i Sverige AB']",
    "prefixes":"{'ipv4': ['194.68.133.0/24', '194.68.135.0/24'], 'ipv6': ['2001:7f8:d:300::/64', '2001:7f8:d:301::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.netnod.se",
    "participants_pch":8,
    "peak_pch":"800M",
    "avg_pch":"350M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 20.25972,63.82842 ]
    },
    "properties": {
    "FIELD1":627,
    "country":"Sweden",
    "total_by_country":15,
    "city":"Umea",
    "ixpname":"NorrNod",
    "alternatenames":"['Norrnod Umea', 'NorrNod']",
    "prefixes":"{'ipv4': ['212.32.128.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.norrnod.se",
    "participants_pch":7,
    "peak_pch":"717M",
    "avg_pch":"160M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 22.15465,65.58415 ]
    },
    "properties": {
    "FIELD1":628,
    "country":"Sweden",
    "total_by_country":15,
    "city":"Lulea",
    "ixpname":"PolarIX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 18.06871,59.32938 ]
    },
    "properties": {
    "FIELD1":629,
    "country":"Sweden",
    "total_by_country":15,
    "city":"Stockholm",
    "ixpname":"SOLIX",
    "alternatenames":"['Stockholm Open Local Internet Exchange']",
    "prefixes":"{'ipv4': ['193.110.12.0/24', '193.110.13.0/24'], 'ipv6': ['2001:7f8:21:9::/64', '2001:7f8:21:10::/64', '2001:7f8:21:12::/64', '2001:7f8:21:11::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.sol-ix.net",
    "participants_pch":69,
    "peak_pch":"11.1G",
    "avg_pch":"7.8G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 11.96679,57.70716 ]
    },
    "properties": {
    "FIELD1":630,
    "country":"Sweden",
    "total_by_country":15,
    "city":"Gothenburg",
    "ixpname":"STHIX - Gothenburg",
    "alternatenames":"['STHIX Gothenburg']",
    "prefixes":"{'ipv4': ['185.1.82.0/24'], 'ipv6': ['2001:7f8:ad::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.sthix.net",
    "participants_pch":22,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 18.06871,59.32938 ]
    },
    "properties": {
    "FIELD1":632,
    "country":"Sweden",
    "total_by_country":15,
    "city":"Stockholm",
    "ixpname":"Stockholm Internet Exchange",
    "alternatenames":"['Stockholm Internet eXchange']",
    "prefixes":"{'ipv4': ['192.121.80.0/24'], 'ipv6': ['2001:7f8:3e::/64']}",
    "sources":"['pdb']",
    "url":"http://www.sthix.net/",
    "participants_pch":122,
    "peak_pch":"195G",
    "avg_pch":"121G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.55,47.36667 ]
    },
    "properties": {
    "FIELD1":633,
    "country":"Switzerland",
    "total_by_country":10,
    "city":"Zurich",
    "ixpname":"4b42 Internet Exchange Point",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.125.0/24'], 'ipv6': ['2a0c:3b80:415f::/48', '2001:7f8:d0:b901::/64', '2001:7f8:d0:4b42::/64', '2001:7f8:d0::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.4ixp.com",
    "participants_pch":6,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 6.14569,46.20222 ]
    },
    "properties": {
    "FIELD1":634,
    "country":"Switzerland",
    "total_by_country":10,
    "city":"Geneva",
    "ixpname":"CERN Internet Exchange Point",
    "alternatenames":"['CERN Internet eXchange Point', 'CIXP']",
    "prefixes":"{'ipv4': ['192.65.185.0/24'], 'ipv6': ['2001:7f8:1c:24a::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.cixp.net/",
    "participants_pch":44,
    "peak_pch":"11.2G",
    "avg_pch":"6.5G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1995,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.55,47.36667 ]
    },
    "properties": {
    "FIELD1":635,
    "country":"Switzerland",
    "total_by_country":10,
    "city":"Zurich",
    "ixpname":"Community-IX.ch",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.105.0/24'], 'ipv6': ['2001:7f8:bf:1::/64', '2001:7f8:bf::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.community-ix.ch/",
    "participants_pch":6,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.55,47.36667 ]
    },
    "properties": {
    "FIELD1":636,
    "country":"Switzerland",
    "total_by_country":10,
    "city":"Zurich",
    "ixpname":"Equinix Zurich",
    "alternatenames":"['Equinix Internet Exchange Zurich, formerly TIX']",
    "prefixes":"{'ipv4': ['194.42.48.0/24', '194.42.48.0/25'], 'ipv6': ['2001:7f8:c:8235:194:42:48:0/112', '2001:7f8:c:8235::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.equinix.ch/services/interconnection-connectivity/internet-exchange/",
    "participants_pch":45,
    "peak_pch":"4.6G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1999,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.55,47.36667 ]
    },
    "properties": {
    "FIELD1":637,
    "country":"Switzerland",
    "total_by_country":10,
    "city":"Zurich",
    "ixpname":"Global Internet Exchange & Peering Network",
    "alternatenames":"['Global Internet Exchange & Peering Network']",
    "prefixes":"{'ipv4': ['80.94.94.0/23'], 'ipv6': ['2a06:2340::/64', '2a06:2340:94::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.ge-cix.net/",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 6.63282,46.516 ]
    },
    "properties": {
    "FIELD1":638,
    "country":"Switzerland",
    "total_by_country":10,
    "city":"Lausanne",
    "ixpname":"RomandIX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.93.0/24'], 'ipv6': ['2001:7f8:b5::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.romandix.ch",
    "participants_pch":9,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.55,47.36667 ]
    },
    "properties": {
    "FIELD1":639,
    "country":"Switzerland",
    "total_by_country":10,
    "city":"Zurich",
    "ixpname":"SBIX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.135.0/24'], 'ipv6': ['2001:7f8:d9:5b::/64']}",
    "sources":"['pdb']",
    "url":"https://www.sbix.ch",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.55,47.36667 ]
    },
    "properties": {
    "FIELD1":640,
    "country":"Switzerland",
    "total_by_country":10,
    "city":"Zurich",
    "ixpname":"Securebit Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":4,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.55,47.36667 ]
    },
    "properties": {
    "FIELD1":641,
    "country":"Switzerland",
    "total_by_country":10,
    "city":"Zurich",
    "ixpname":"SwissIX",
    "alternatenames":"['SwissIX Internet Exchange']",
    "prefixes":"{'ipv4': ['91.206.52.0/23'], 'ipv6': ['2001:7f8:24::/48', '2001:7f8:24::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.swissix.ch/",
    "participants_pch":225,
    "peak_pch":"200G",
    "avg_pch":"114G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 8.55,47.36667 ]
    },
    "properties": {
    "FIELD1":642,
    "country":"Switzerland",
    "total_by_country":10,
    "city":"Zurich",
    "ixpname":"Telehouse Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":1999,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 121.3662937,25.0174719 ]
    },
    "properties": {
    "FIELD1":643,
    "country":"Taiwan, China",
    "total_by_country":7,
    "city":"Taipei",
    "ixpname":".",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 121.3662937,25.0174719 ]
    },
    "properties": {
    "FIELD1":644,
    "country":"Taiwan, China",
    "total_by_country":7,
    "city":"Changhua",
    "ixpname":"LSY.CN Changhua",
    "alternatenames":"['LSHIY Group Changhua Internet eXchange']",
    "prefixes":"{'ipv4': [], 'ipv6': ['2404:f4c0:4:9::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://ix.lsy.cn/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 121.3662937,25.0174719 ]
    },
    "properties": {
    "FIELD1":645,
    "country":"Taiwan, China",
    "total_by_country":7,
    "city":"Taipei",
    "ixpname":"Taipei Internet Exchange (TPIX)",
    "alternatenames":"['Taipei Internet Exchange', 'TPIX-TW']",
    "prefixes":"{'ipv4': ['203.163.222.0/24'], 'ipv6': ['2406:d400:1:133:203:163:222:0/112']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.tpix.net.tw/",
    "participants_pch":42,
    "peak_pch":"130G",
    "avg_pch":"75K",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 121.3662937,25.0174719 ]
    },
    "properties": {
    "FIELD1":646,
    "country":"Taiwan, China",
    "total_by_country":7,
    "city":"Taipei",
    "ixpname":"TaipeiGigaPoP",
    "alternatenames":"['Taipei GigaPoP Internet Exchange']",
    "prefixes":"{'ipv4': ['202.169.160.0/20', '103.130.252.0/22'], 'ipv6': ['2403:c240::/32']}",
    "sources":"['pdb']",
    "url":"https://its.sinica.edu.tw/",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 121.3662937,25.0174719 ]
    },
    "properties": {
    "FIELD1":647,
    "country":"Taiwan, China",
    "total_by_country":7,
    "city":"Taipei",
    "ixpname":"Taiwan Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['210.62.255.0/24'], 'ipv6': ['2001:7fa:1:7481::/64']}",
    "sources":"['he']",
    "url":"https://www.twix.net/index_e.html",
    "participants_pch":26,
    "peak_pch":"162G",
    "avg_pch":"105G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 121.3662937,25.0174719 ]
    },
    "properties": {
    "FIELD1":648,
    "country":"Taiwan, China",
    "total_by_country":7,
    "city":"Taipei",
    "ixpname":"Taiwan Network Access Point",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":16,
    "peak_pch":"1G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 121.3662937,25.0174719 ]
    },
    "properties": {
    "FIELD1":649,
    "country":"Taiwan, China",
    "total_by_country":7,
    "city":"Taipei",
    "ixpname":"TaiwanEP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 35.73947,-6.17221 ]
    },
    "properties": {
    "FIELD1":650,
    "country":"Tanzania",
    "total_by_country":6,
    "city":"Dodoma",
    "ixpname":"Dodoma Internet Exchange Point",
    "alternatenames":"['TIX Tanzania - Dodoma IXP', 'Dodoma Internet Exchange Point - DIXP', 'TIX Tanzania - Dodoma']",
    "prefixes":"{'ipv4': ['196.60.50.0/24'], 'ipv6': ['2001:43f8:0:400::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.tix.or.tz/dixp/",
    "participants_pch":4,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 32.9,-2.51667 ]
    },
    "properties": {
    "FIELD1":651,
    "country":"Tanzania",
    "total_by_country":6,
    "city":"Mwanza",
    "ixpname":"Mwanza Internet Exchange Point",
    "alternatenames":"['TIX Tanzania - Mwanza']",
    "prefixes":"{'ipv4': ['196.60.0.0/24'], 'ipv6': ['2001:43f8:0:200::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"",
    "participants_pch":12,
    "peak_pch":"2.2M",
    "avg_pch":"61K",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2016,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 36.68333,-3.36667 ]
    },
    "properties": {
    "FIELD1":652,
    "country":"Tanzania",
    "total_by_country":6,
    "city":"Arusha",
    "ixpname":"TIX Tanzania - Arusha",
    "alternatenames":"['Arusha Internet eXchange Point', 'AIXP']",
    "prefixes":"{'ipv4': ['196.223.6.0/25'], 'ipv6': ['2001:43f8:0:100::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.aixp.or.tz",
    "participants_pch":6,
    "peak_pch":"100M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2006,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 39.26951,-6.82349 ]
    },
    "properties": {
    "FIELD1":653,
    "country":"Tanzania",
    "total_by_country":6,
    "city":"Dar es Salaam",
    "ixpname":"TIX Tanzania - Dar es Salaam",
    "alternatenames":"['Tanzania Internet eXchange']",
    "prefixes":"{'ipv4': ['196.223.5.0/24'], 'ipv6': ['2001:43f8::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://tix.or.tz/",
    "participants_pch":42,
    "peak_pch":"10G",
    "avg_pch":"6.6G",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2003,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 32.9,-2.51667 ]
    },
    "properties": {
    "FIELD1":654,
    "country":"Tanzania",
    "total_by_country":6,
    "city":"Mwanza",
    "ixpname":"TIX Tanzania Mwanza",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['he']",
    "url":"",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Sub-Saharan Africa",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 39.19793,-6.16394 ]
    },
    "properties": {
    "FIELD1":655,
    "country":"Tanzania",
    "total_by_country":6,
    "city":"Zanzibar",
    "ixpname":"Zanzibar Internet Exchange Point",
    "alternatenames":"['TIX Tanzania - Zanzibar', 'TIX Tanzania - Zanzibar IXP']",
    "prefixes":"{'ipv4': ['196.60.48.0/24'], 'ipv6': ['2001:43f8:0:300::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.tix.or.tz/zixp/",
    "participants_pch":3,
    "peak_pch":"7.6M",
    "avg_pch":"1.3M",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 100.50144,13.75398 ]
    },
    "properties": {
    "FIELD1":656,
    "country":"Thailand",
    "total_by_country":5,
    "city":"Bangkok",
    "ixpname":"BBIX Thailand",
    "alternatenames":"['BBIX (Thailand) Company Limited']",
    "prefixes":"{'ipv4': ['103.127.88.0/23'], 'ipv6': ['2001:df7:6500:1::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.bbix.net/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"East Asia & Pacific",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 100.50144,13.75398 ]
    },
    "properties": {
    "FIELD1":657,
    "country":"Thailand",
    "total_by_country":5,
    "city":"Bangkok",
    "ixpname":"Bangkok Neutral Internet Exchange",
    "alternatenames":"['BKNIX']",
    "prefixes":"{'ipv4': ['203.159.68.0/23'], 'ipv6': ['2001:deb:0:68::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://bknix.co.th",
    "participants_pch":19,
    "peak_pch":"20G",
    "avg_pch":"14.1G",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 100.50144,13.75398 ]
    },
    "properties": {
    "FIELD1":658,
    "country":"Thailand",
    "total_by_country":5,
    "city":"Bangkok",
    "ixpname":"CAT National Internet Exchange",
    "alternatenames":"['THailand Internet eXchange', 'TH-IX']",
    "prefixes":"{'ipv4': ['61.19.60.0/23'], 'ipv6': ['2001:c38:8000::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.cattelecom.com",
    "participants_pch":20,
    "peak_pch":"1.7G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 100.50144,13.75398 ]
    },
    "properties": {
    "FIELD1":659,
    "country":"Thailand",
    "total_by_country":5,
    "city":"Bangkok",
    "ixpname":"Thai-IX Bangkok by CS Loxinfo",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['27.254.16.0/23'], 'ipv6': ['2404:b0:13::/48']}",
    "sources":"['he']",
    "url":"https://www.cslthai-ix.net",
    "participants_pch":10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 100.50144,13.75398 ]
    },
    "properties": {
    "FIELD1":660,
    "country":"Thailand",
    "total_by_country":5,
    "city":"Bangkok",
    "ixpname":"ThaiSarn Public Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"East Asia & Pacific",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 125.57361,-8.55861 ]
    },
    "properties": {
    "FIELD1":661,
    "country":"Timor-Leste",
    "total_by_country":1,
    "city":"Dili",
    "ixpname":"Timor-Leste Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2016,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 1.22154,6.12874 ]
    },
    "properties": {
    "FIELD1":662,
    "country":"Togo",
    "total_by_country":1,
    "city":"Lome",
    "ixpname":"Togo Internet Exchange Point",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['196.60.42.0/24'], 'ipv6': ['2001:43f8:d11::/64']}",
    "sources":"['he']",
    "url":"http://www.tgix.tg",
    "participants_pch":6,
    "peak_pch":"56.4M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2017,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -61.37103,10.27184 ]
    },
    "properties": {
    "FIELD1":663,
    "country":"Trinidad and Tobago",
    "total_by_country":2,
    "city":"Princes Town",
    "ixpname":"TTIX2",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['131.72.77.240/28'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.tt",
    "participants_pch":8,
    "peak_pch":"2.7G",
    "avg_pch":"2.6G",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -61.45996,10.64717 ]
    },
    "properties": {
    "FIELD1":664,
    "country":"Trinidad and Tobago",
    "total_by_country":2,
    "city":"Barataria",
    "ixpname":"Trinidad and Tobago Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['181.188.0.0/24'], 'ipv6': []}",
    "sources":"['he']",
    "url":"https://ix.tt",
    "participants_pch":8,
    "peak_pch":"460M",
    "avg_pch":"400M",
    "status_pch":"active",
    "only_in":"",
    "region":"Latin America & Caribbean",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 10.38083,36.13528 ]
    },
    "properties": {
    "FIELD1":665,
    "country":"Tunisia",
    "total_by_country":2,
    "city":"Enfidha",
    "ixpname":"Enfidha Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['41.231.34.0/26'], 'ipv6': ['2001:4350:3001::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":2,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Middle East & North Africa",
    "year":2013,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 10.16579,36.81897 ]
    },
    "properties": {
    "FIELD1":666,
    "country":"Tunisia",
    "total_by_country":2,
    "city":"Tunis",
    "ixpname":"Tunisian Internet Exchange Point",
    "alternatenames":"['Tunisia Internet Exchange Point', 'TunIXP']",
    "prefixes":"{'ipv4': ['41.231.21.0/24'], 'ipv6': ['2001:4350:3000:1::/64', '2001:4350:3000::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.ati.tn/TunIXP/",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Middle East & North Africa",
    "year":2011,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 28.94966,41.01384 ]
    },
    "properties": {
    "FIELD1":667,
    "country":"Turkey",
    "total_by_country":1,
    "city":"Istanbul",
    "ixpname":"DE-CIX Istanbul",
    "alternatenames":"['Deutscher Commercial Internet Exchange Istanbul']",
    "prefixes":"{'ipv4': ['185.1.48.0/24'], 'ipv6': ['2001:7f8:3f::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.de-cix.net/locations/turkey/istanbul",
    "participants_pch":30,
    "peak_pch":"91G",
    "avg_pch":"56G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 32.58219,0.31628 ]
    },
    "properties": {
    "FIELD1":668,
    "country":"Uganda",
    "total_by_country":1,
    "city":"Kampala",
    "ixpname":"Uganda Internet Exchange",
    "alternatenames":"['UIXP']",
    "prefixes":"{'ipv4': ['196.223.25.0/25'], 'ipv6': ['2001:43f8:130::/112']}",
    "sources":"['pch', 'he']",
    "url":"https://uixp.co.ug/",
    "participants_pch":26,
    "peak_pch":"6.4G",
    "avg_pch":"4G",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2003,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 36.25272,49.98081 ]
    },
    "properties": {
    "FIELD1":669,
    "country":"Ukraine",
    "total_by_country":15,
    "city":"Kharkov",
    "ixpname":"CLOUD-IX KHA",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['31.28.26.0/24'], 'ipv6': ['2a00:13c0:3:4::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.cloud-ix.net/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 30.5238,50.45466 ]
    },
    "properties": {
    "FIELD1":670,
    "country":"Ukraine",
    "total_by_country":15,
    "city":"Kiev",
    "ixpname":"CLOUD-IX KIEV",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['31.28.16.0/24'], 'ipv6': ['2a00:13c0:3:3::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.cloud-ix.net/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 34.11079,44.95719 ]
    },
    "properties": {
    "FIELD1":671,
    "country":"Ukraine",
    "total_by_country":15,
    "city":"Simferopol",
    "ixpname":"Crimea Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":53,
    "peak_pch":"70G",
    "avg_pch":"40.4G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2006,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 30.5238,50.45466 ]
    },
    "properties": {
    "FIELD1":672,
    "country":"Ukraine",
    "total_by_country":15,
    "city":"Kiev",
    "ixpname":"Digital Telecom Internet Exchange",
    "alternatenames":"['DTEL-IX']",
    "prefixes":"{'ipv4': ['193.25.180.0/23'], 'ipv6': ['2001:7f8:63::/48', '2001:7f8:63::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://dtel-ix.net/en/",
    "participants_pch":140,
    "peak_pch":"1.32T",
    "avg_pch":"767G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2009,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 37.80224,48.023 ]
    },
    "properties": {
    "FIELD1":673,
    "country":"Ukraine",
    "total_by_country":15,
    "city":"Donetsk",
    "ixpname":"Donetsk Internet Exchange",
    "alternatenames":"['Donetsk Internet eXchange']",
    "prefixes":"{'ipv4': ['193.34.203.0/25'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://ix.dn.ua",
    "participants_pch":12,
    "peak_pch":"1.3G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2001,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 30.5238,50.45466 ]
    },
    "properties": {
    "FIELD1":674,
    "country":"Ukraine",
    "total_by_country":15,
    "city":"Kiev",
    "ixpname":"Giganet Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.62.0/23'], 'ipv6': ['2001:7f8:6c::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":103,
    "peak_pch":"1.4T",
    "avg_pch":"840G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2012,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 32.61458,46.63695 ]
    },
    "properties": {
    "FIELD1":675,
    "country":"Ukraine",
    "total_by_country":15,
    "city":"Kherson",
    "ixpname":"Kherson Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['185.1.39.0/24'], 'ipv6': ['2001:7f8:80::/64']}",
    "sources":"['pdb']",
    "url":"http://ix.ks.ua",
    "participants_pch":14,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2008,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 49.5195806,25.8947537 ]
    },
    "properties": {
    "FIELD1":676,
    "country":"Ukraine",
    "total_by_country":15,
    "city":"Khmelnytskyi",
    "ixpname":"Khmelnytsky Internet exchange point",
    "alternatenames":"['KM-IX']",
    "prefixes":"{'ipv4': ['193.201.116.128/26'], 'ipv6': ['2001:67c:5e8::/48']}",
    "sources":"['pch', 'he']",
    "url":"http://ix.km.ua/",
    "participants_pch":3,
    "peak_pch":"215M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2003,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 24.02324,49.83826 ]
    },
    "properties": {
    "FIELD1":678,
    "country":"Ukraine",
    "total_by_country":15,
    "city":"Lviv",
    "ixpname":"Lviv Internet Exchange",
    "alternatenames":"['Lviv Internet Exchange']",
    "prefixes":"{'ipv4': ['185.1.134.0/24'], 'ipv6': ['2001:7f8:d8::/48']}",
    "sources":"['pdb', 'he']",
    "url":"http://ix.lviv.ua",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 37.54131,47.09514 ]
    },
    "properties": {
    "FIELD1":679,
    "country":"Ukraine",
    "total_by_country":15,
    "city":"Mariupol",
    "ixpname":"MRPL-IX",
    "alternatenames":"['MESH-IX']",
    "prefixes":"{'ipv4': ['185.1.99.0/24'], 'ipv6': ['2001:7f8:ba::/48']}",
    "sources":"['pdb', 'he']",
    "url":"http://ix.meshroom.net",
    "participants_pch":7,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 30.74383,46.48572 ]
    },
    "properties": {
    "FIELD1":680,
    "country":"Ukraine",
    "total_by_country":15,
    "city":"Odessa",
    "ixpname":"Odessa Internet Exchange",
    "alternatenames":"['Od-IX']",
    "prefixes":"{'ipv4': ['194.107.117.0/24'], 'ipv6': []}",
    "sources":"['pch', 'he']",
    "url":"http://od-ix.net/",
    "participants_pch":25,
    "peak_pch":"28.7M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2007,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 30.5238,50.45466 ]
    },
    "properties": {
    "FIELD1":681,
    "country":"Ukraine",
    "total_by_country":15,
    "city":"Kiev",
    "ixpname":"SerinIX IX",
    "alternatenames":"['SerinIX Internet Exchange']",
    "prefixes":"{'ipv4': ['195.135.199.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"http://www.serinix.com",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 30.5238,50.45466 ]
    },
    "properties": {
    "FIELD1":682,
    "country":"Ukraine",
    "total_by_country":15,
    "city":"Kiev",
    "ixpname":"Ukrainian Internet Exchange",
    "alternatenames":"['UA-IX']",
    "prefixes":"{'ipv4': ['195.35.65.0/24', '185.1.50.0/23'], 'ipv6': ['2001:7f8:5d::/116']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.ua-ix.net.ua/en",
    "participants_pch":180,
    "peak_pch":"523G",
    "avg_pch":"169K",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2000,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 34.93457,47.82809 ]
    },
    "properties": {
    "FIELD1":683,
    "country":"Ukraine",
    "total_by_country":15,
    "city":"Zaporozhye",
    "ixpname":"Zaporozhye Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":2008,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 56.34141,25.11641 ]
    },
    "properties": {
    "FIELD1":684,
    "country":"United Arab Emirates",
    "total_by_country":2,
    "city":"Fujairah",
    "ixpname":"SMARTHUB Internet Exchange",
    "alternatenames":"['SH-IX']",
    "prefixes":"{'ipv4': ['185.1.15.0/24'], 'ipv6': ['2001:7f8:7a::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.smarthubix.ae/",
    "participants_pch":13,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Middle East & North Africa",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 55.30927,25.07725 ]
    },
    "properties": {
    "FIELD1":685,
    "country":"United Arab Emirates",
    "total_by_country":2,
    "city":"Dubai",
    "ixpname":"UAE-IX by DE-CIX",
    "alternatenames":"['UAE-IX powered by DE-CIX', 'UAE-IX']",
    "prefixes":"{'ipv4': ['185.1.8.0/24'], 'ipv6': ['2001:7f8:73::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.uae-ix.net",
    "participants_pch":70,
    "peak_pch":"137G",
    "avg_pch":"101G",
    "status_pch":"active",
    "only_in":"",
    "region":"Middle East & North Africa",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -2.39049,52.03278 ]
    },
    "properties": {
    "FIELD1":686,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"Eastnor",
    "ixpname":"EMF-IX",
    "alternatenames":"['Electromagnetic Field 2018 Popup IX']",
    "prefixes":"{'ipv4': ['185.230.223.192/26'], 'ipv6': []}",
    "sources":"['pdb', 'he']",
    "url":"https://emf-ix.benjojo.co.uk",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -0.12574,51.50853 ]
    },
    "properties": {
    "FIELD1":687,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"London",
    "ixpname":"Equinix London",
    "alternatenames":"['Equinix Internet Exchange London']",
    "prefixes":"{'ipv4': ['185.1.104.0/24'], 'ipv6': ['2001:7f8:be::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.equinix.co.uk/services/interconnection-connectivity/internet-exchange/",
    "participants_pch":50,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -2.23743,53.48095 ]
    },
    "properties": {
    "FIELD1":688,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"Manchester",
    "ixpname":"Equinix Manchester",
    "alternatenames":"['Equinix Internet Exchange Manchester']",
    "prefixes":"{'ipv4': ['185.1.101.0/24'], 'ipv6': ['2001:7f8:bc::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.equinix.co.uk/services/interconnection-connectivity/internet-exchange/",
    "participants_pch":13,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -0.13947,50.82838 ]
    },
    "properties": {
    "FIELD1":689,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"Brighton",
    "ixpname":"IX Brighton",
    "alternatenames":"['Brighton Internet Exchange']",
    "prefixes":"{'ipv4': ['185.1.33.0/24'], 'ipv6': ['2001:7f8:90::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.ixbrighton.com",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -2.97794,53.41058 ]
    },
    "properties": {
    "FIELD1":690,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"Liverpool",
    "ixpname":"IX Liverpool",
    "alternatenames":"['Liverpool Internet Exchange']",
    "prefixes":"{'ipv4': ['185.1.71.0/25', '185.1.71.128/25'], 'ipv6': ['2001:7f8:a2::/50', '2001:7f8:a2:4000::/50', '2001:7f8:a2:8000::/50', '2001:7f8:a2::/49', '2001:7f8:a2:8000::/49']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.ixliverpool.net",
    "participants_pch":7,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -3.18,51.48 ]
    },
    "properties": {
    "FIELD1":691,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"Cardiff",
    "ixpname":"IXCardiff by LINX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":26,
    "peak_pch":"458M",
    "avg_pch":"29M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -2.23743,53.48095 ]
    },
    "properties": {
    "FIELD1":692,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"Manchester",
    "ixpname":"IXManchester powered by LINX",
    "alternatenames":"['LINX Manchester', 'IXManchester']",
    "prefixes":"{'ipv4': ['195.66.244.0/24'], 'ipv6': ['2001:7f8:4:2::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.linx.net",
    "participants_pch":89,
    "peak_pch":"64G",
    "avg_pch":"45G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -0.12574,51.50853 ]
    },
    "properties": {
    "FIELD1":693,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"London",
    "ixpname":"IXP LON",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': ['2a0c:3b80:4040:4742::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.ixp.cat",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -3.19648,55.95206 ]
    },
    "properties": {
    "FIELD1":694,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"Edinburgh",
    "ixpname":"IXScotland powered by LINX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['195.66.246.0/24'], 'ipv6': ['2001:7f8:4:3::/128']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":26,
    "peak_pch":"1G",
    "avg_pch":"434M",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -3.18,51.48 ]
    },
    "properties": {
    "FIELD1":695,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"Cardiff",
    "ixpname":"LINX Cardiff",
    "alternatenames":"['IXCardiff']",
    "prefixes":"{'ipv4': ['195.66.228.0/24'], 'ipv6': ['2001:7f8:4:4::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.linx.net/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -0.12574,51.50853 ]
    },
    "properties": {
    "FIELD1":696,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"London",
    "ixpname":"LINX Extreme LAN",
    "alternatenames":"['London Internet Exchange Ltd.', 'LINX LON2']",
    "prefixes":"{'ipv4': ['195.66.236.0/22'], 'ipv6': ['2001:7f8:4:1::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.linx.net/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -0.12574,51.50853 ]
    },
    "properties": {
    "FIELD1":697,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"London",
    "ixpname":"LINX Juniper LAN",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['195.66.224.0/22', '195.66.230.0/24'], 'ipv6': ['2001:7f8:4::/64']}",
    "sources":"['he']",
    "url":"https://www.linx.net/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -0.12574,51.50853 ]
    },
    "properties": {
    "FIELD1":698,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"London",
    "ixpname":"LINX LON1",
    "alternatenames":"['London Internet Exchange Ltd.']",
    "prefixes":"{'ipv4': ['195.66.224.0/22', '195.66.230.0/26'], 'ipv6': ['2001:7f8:4::/64']}",
    "sources":"['pdb']",
    "url":"https://www.linx.net/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -4.25763,55.86515 ]
    },
    "properties": {
    "FIELD1":699,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"Scotland",
    "ixpname":"LINX Scotland",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['195.66.246.0/24'], 'ipv6': ['2001:7f8:4:3::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.linx.net",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"Europe & Central Asia",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -1.54785,53.79648 ]
    },
    "properties": {
    "FIELD1":700,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"Leeds",
    "ixpname":"Leeds Internet Exchange",
    "alternatenames":"['IX Leeds']",
    "prefixes":"{'ipv4': ['91.234.18.0/24', '91.217.231.0/24'], 'ipv6': ['2001:7f8:67::/64', '2001:7f8:67:9::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ixleeds.net",
    "participants_pch":21,
    "peak_pch":"4.2G",
    "avg_pch":"2.4G",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2010,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -0.12574,51.50853 ]
    },
    "properties": {
    "FIELD1":701,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"London",
    "ixpname":"London Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['195.66.224.0/22', '195.66.236.0/22'], 'ipv6': ['2001:7f8:4::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":770,
    "peak_pch":"4.22T",
    "avg_pch":"2.7T",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1994,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -0.12574,51.50853 ]
    },
    "properties": {
    "FIELD1":702,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"London",
    "ixpname":"London Network Access Point",
    "alternatenames":"['LONAP', 'LoNAP']",
    "prefixes":"{'ipv4': ['5.57.80.0/22', '195.35.120.0/24'], 'ipv6': ['2001:7f8:17::/48', '2001:7f8:17::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.lonap.net/",
    "participants_pch":185,
    "peak_pch":"431G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":1998,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -2.23743,53.48095 ]
    },
    "properties": {
    "FIELD1":703,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"Manchester",
    "ixpname":"Manchester Commercial Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -2.23743,53.48095 ]
    },
    "properties": {
    "FIELD1":704,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"Manchester",
    "ixpname":"Manchester Network Access Point",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -3.19648,55.95206 ]
    },
    "properties": {
    "FIELD1":705,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"Edinburgh",
    "ixpname":"UNION IXP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -0.12574,51.50853 ]
    },
    "properties": {
    "FIELD1":706,
    "country":"United Kingdom",
    "total_by_country":21,
    "city":"London",
    "ixpname":"XchangePoint London IPP",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['217.79.160.0/23'], 'ipv6': ['2001:7f8:1:1::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":166,
    "peak_pch":"5.3G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -118.24368,34.05223 ]
    },
    "properties": {
    "FIELD1":707,
    "country":"United States",
    "total_by_country":168,
    "city":"Los Angeles",
    "ixpname":"6IIX - Los Angeles",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.00597,40.71427 ]
    },
    "properties": {
    "FIELD1":708,
    "country":"United States",
    "total_by_country":168,
    "city":"New York",
    "ixpname":"6IIX - New York",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -121.95524,37.35411 ]
    },
    "properties": {
    "FIELD1":709,
    "country":"United States",
    "total_by_country":168,
    "city":"Santa Clara",
    "ixpname":"6IIX - Santa Clara",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.41942,37.77493 ]
    },
    "properties": {
    "FIELD1":710,
    "country":"United States",
    "total_by_country":168,
    "city":"San Francisco",
    "ixpname":"AMS-IX Bay Area",
    "alternatenames":"['AMS-IX BA']",
    "prefixes":"{'ipv4': ['206.41.106.0/24'], 'ipv6': ['2001:504:3d:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://bay.ams-ix.net",
    "participants_pch":25,
    "peak_pch":"21.2G",
    "avg_pch":"14.3G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -87.65005,41.85003 ]
    },
    "properties": {
    "FIELD1":711,
    "country":"United States",
    "total_by_country":168,
    "city":"Chicago",
    "ixpname":"AMS-IX Chicago",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.108.115.0/24'], 'ipv6': ['2001:504:38:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://chi.ams-ix.net",
    "participants_pch":23,
    "peak_pch":"109G",
    "avg_pch":"71.5G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -112.07404,33.44838 ]
    },
    "properties": {
    "FIELD1":712,
    "country":"United States",
    "total_by_country":168,
    "city":"Phoenix",
    "ixpname":"AZIX",
    "alternatenames":"['Arizona Internet Exchange']",
    "prefixes":"{'ipv4': ['206.223.120.0/24'], 'ipv6': ['2001:504:18::/48']}",
    "sources":"['pdb']",
    "url":"",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -157.85833,21.30694 ]
    },
    "properties": {
    "FIELD1":713,
    "country":"United States",
    "total_by_country":168,
    "city":"Honolulu",
    "ixpname":"Aloha-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.53.207.0/25', '206.53.207.128/25'], 'ipv6': ['2001:504:65::/64', '2001:504:65:1::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.aloha-ix.net",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -149.90028,61.21806 ]
    },
    "properties": {
    "FIELD1":714,
    "country":"United States",
    "total_by_country":168,
    "city":"Anchorage",
    "ixpname":"Anchorage Metropolitan Access Point",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -118.24368,34.05223 ]
    },
    "properties": {
    "FIELD1":715,
    "country":"United States",
    "total_by_country":168,
    "city":"Los Angeles",
    "ixpname":"Any2 California",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.72.210.0/23', '206.223.143.0/24'], 'ipv6': ['2001:504:13::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":449,
    "peak_pch":"68G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2005,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -84.38798,33.749 ]
    },
    "properties": {
    "FIELD1":716,
    "country":"United States",
    "total_by_country":168,
    "city":"Atlanta",
    "ixpname":"Atlanta NAP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -76.61219,39.29038 ]
    },
    "properties": {
    "FIELD1":717,
    "country":"United States",
    "total_by_country":168,
    "city":"Baltimore",
    "ixpname":"Baltimore-NAP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.00597,40.71427 ]
    },
    "properties": {
    "FIELD1":718,
    "country":"United States",
    "total_by_country":168,
    "city":"New York",
    "ixpname":"Big Apple Peering Exchange",
    "alternatenames":"['BigApe', 'The Big Apple Peering Exchange', 'Big APE']",
    "prefixes":"{'ipv4': ['198.32.238.0/24'], 'ipv6': ['2001:458:26:2::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.bigape.us",
    "participants_pch":14,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -104.82025,41.13998 ]
    },
    "properties": {
    "FIELD1":719,
    "country":"United States",
    "total_by_country":168,
    "city":"Cheyenne",
    "ixpname":"Big Horn Fiber",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":12,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -71.05977,42.35843 ]
    },
    "properties": {
    "FIELD1":720,
    "country":"United States",
    "total_by_country":168,
    "city":"Boston",
    "ixpname":"Boston Internet Exchange",
    "alternatenames":"['Boston IX']",
    "prefixes":"{'ipv4': ['206.108.236.0/24'], 'ipv6': ['2001:504:24:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.bostonix.net/",
    "participants_pch":61,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -78.87837,42.88645 ]
    },
    "properties": {
    "FIELD1":721,
    "country":"United States",
    "total_by_country":168,
    "city":"Buffalo",
    "ixpname":"Buffalo Niagara International Internet Exchange",
    "alternatenames":"['BNIIX']",
    "prefixes":"{'ipv4': ['206.130.61.0/24'], 'ipv6': ['2001:504:20:81::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.bniix.net",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -118.24368,34.05223 ]
    },
    "properties": {
    "FIELD1":722,
    "country":"United States",
    "total_by_country":168,
    "city":"Los Angeles",
    "ixpname":"CENIC International Internet eXchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['198.32.146.0/24'], 'ipv6': ['2001:504:a::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":6,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.27275,37.87159 ]
    },
    "properties": {
    "FIELD1":723,
    "country":"United States",
    "total_by_country":168,
    "city":"Berkeley",
    "ixpname":"Calren2 North",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -118.24368,34.05223 ]
    },
    "properties": {
    "FIELD1":724,
    "country":"United States",
    "total_by_country":168,
    "city":"Los Angeles",
    "ixpname":"Calren2 South",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -81.37924,28.53834 ]
    },
    "properties": {
    "FIELD1":725,
    "country":"United States",
    "total_by_country":168,
    "city":"Orlando",
    "ixpname":"Central Florida IX",
    "alternatenames":"['Central Florida IX', 'Central Florida Internet Exchange']",
    "prefixes":"{'ipv4': ['206.80.235.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.cflix.org",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -86.25001,41.68338 ]
    },
    "properties": {
    "FIELD1":726,
    "country":"United States",
    "total_by_country":168,
    "city":"Bend",
    "ixpname":"Central Oregon Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -86.25001,41.68338 ]
    },
    "properties": {
    "FIELD1":727,
    "country":"United States",
    "total_by_country":168,
    "city":"Bend",
    "ixpname":"Central Oregon Internet eXchange",
    "alternatenames":"['COIX']",
    "prefixes":"{'ipv4': ['206.197.131.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.centraloregonix.org",
    "participants_pch":4,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -64.9307,18.3419 ]
    },
    "properties": {
    "FIELD1":728,
    "country":"United States",
    "total_by_country":168,
    "city":"Charlotte",
    "ixpname":"Charlotte-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.71.143.0/24'], 'ipv6': ['2001:504:78::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.charlotte-ix.net",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -87.65005,41.85003 ]
    },
    "properties": {
    "FIELD1":729,
    "country":"United States",
    "total_by_country":168,
    "city":"Chicago",
    "ixpname":"Chicago Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -82.99879,39.96118 ]
    },
    "properties": {
    "FIELD1":730,
    "country":"United States",
    "total_by_country":168,
    "city":"Columbus",
    "ixpname":"Columbus Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -84.38798,33.749 ]
    },
    "properties": {
    "FIELD1":731,
    "country":"United States",
    "total_by_country":168,
    "city":"Atlanta",
    "ixpname":"Community IX - Atlanta",
    "alternatenames":"['Community IX - Atlanta']",
    "prefixes":"{'ipv4': ['206.71.12.0/24'], 'ipv6': ['2001:504:40:12::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.communityix.org",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -118.24368,34.05223 ]
    },
    "properties": {
    "FIELD1":732,
    "country":"United States",
    "total_by_country":168,
    "city":"Los Angeles",
    "ixpname":"CoreSite - Any2 California",
    "alternatenames":"['Any2 Los Angeles', 'CoreSite - Any2 Los Angeles']",
    "prefixes":"{'ipv4': ['206.72.210.0/23'], 'ipv6': ['2001:504:13::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.coresite.com",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -71.05977,42.35843 ]
    },
    "properties": {
    "FIELD1":733,
    "country":"United States",
    "total_by_country":168,
    "city":"Boston",
    "ixpname":"Coresite - Any 2 Boston",
    "alternatenames":"['Coresite - Any 2', 'Any2 Boston']",
    "prefixes":"{'ipv4': ['206.51.42.0/24'], 'ipv6': ['2001:504:13:7::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.coresite.com",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -87.65005,41.85003 ]
    },
    "properties": {
    "FIELD1":734,
    "country":"United States",
    "total_by_country":168,
    "city":"Chicago",
    "ixpname":"Coresite - Any 2 Chicago",
    "alternatenames":"['Any2 Chicago', 'CoreSite - Any2']",
    "prefixes":"{'ipv4': ['206.51.43.0/24'], 'ipv6': ['2001:504:13:4::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.coresite.com",
    "participants_pch":10,
    "peak_pch":"5G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -104.9847,39.73915 ]
    },
    "properties": {
    "FIELD1":735,
    "country":"United States",
    "total_by_country":168,
    "city":"Denver",
    "ixpname":"Coresite - Any 2 Denver",
    "alternatenames":"['Any2 Denver', 'Coresite - Any 2', 'CoreSite - Any2 Denver / Formerly RMIX']",
    "prefixes":"{'ipv4': ['206.51.46.0/24'], 'ipv6': ['2605:6c00:303:303::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.coresite.com",
    "participants_pch":45,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -80.19366,25.77427 ]
    },
    "properties": {
    "FIELD1":736,
    "country":"United States",
    "total_by_country":168,
    "city":"Miami",
    "ixpname":"Coresite - Any 2 Miami",
    "alternatenames":"['Any2 Miami', 'Coresite - Any 2']",
    "prefixes":"{'ipv4': ['206.51.44.0/24'], 'ipv6': ['2001:504:13:5::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.coresite.com",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.00597,40.71427 ]
    },
    "properties": {
    "FIELD1":737,
    "country":"United States",
    "total_by_country":168,
    "city":"New York",
    "ixpname":"Coresite - Any 2 New York",
    "alternatenames":"['Coresite - Any 2', 'Any2 New York']",
    "prefixes":"{'ipv4': ['206.51.45.0/24'], 'ipv6': ['2001:504:13:6::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.coresite.com",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -77.3411,38.96872 ]
    },
    "properties": {
    "FIELD1":738,
    "country":"United States",
    "total_by_country":168,
    "city":"Reston",
    "ixpname":"Coresite - Any 2 NorthEast",
    "alternatenames":"['Any2 NorthEast', 'CoreSite - Any2 NorthEast']",
    "prefixes":"{'ipv4': ['206.51.40.0/24'], 'ipv6': ['2001:504:13:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.coresite.com",
    "participants_pch":23,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -121.9233903,37.2966279 ]
    },
    "properties": {
    "FIELD1":739,
    "country":"United States",
    "total_by_country":168,
    "city":"San Jose",
    "ixpname":"Coresite - Any 2 Northern California",
    "alternatenames":"['Any2 Northern California', 'CoreSite - Any2 Silicon Valley']",
    "prefixes":"{'ipv4': ['206.51.41.0/24'], 'ipv6': ['2001:504:13:3::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.coresite.com",
    "participants_pch":24,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -96.89028,32.95373 ]
    },
    "properties": {
    "FIELD1":740,
    "country":"United States",
    "total_by_country":168,
    "city":"Carrollton",
    "ixpname":"CyrusOne",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -97.74306,30.26715 ]
    },
    "properties": {
    "FIELD1":741,
    "country":"United States",
    "total_by_country":168,
    "city":"Austin",
    "ixpname":"CyrusOne IX Austin",
    "alternatenames":"['CyrusOne Internet Exchange']",
    "prefixes":"{'ipv4': ['198.32.145.0/24'], 'ipv6': ['2001:478:145::/64']}",
    "sources":"['pdb']",
    "url":"http://www.cyrusone.com",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -87.65005,41.85003 ]
    },
    "properties": {
    "FIELD1":742,
    "country":"United States",
    "total_by_country":168,
    "city":"Chicago",
    "ixpname":"CyrusOne IX Chicago",
    "alternatenames":"['CyrusOne Internet Exchange']",
    "prefixes":"{'ipv4': ['198.32.165.0/24'], 'ipv6': ['2001:478:165::/64']}",
    "sources":"['pdb']",
    "url":"http://www.cyrusone.com",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -96.80667,32.78306 ]
    },
    "properties": {
    "FIELD1":743,
    "country":"United States",
    "total_by_country":168,
    "city":"Dallas",
    "ixpname":"CyrusOne IX Dallas",
    "alternatenames":"['CyrusOne Internet Exchange']",
    "prefixes":"{'ipv4': ['198.32.130.0/24'], 'ipv6': ['2001:478:130::/64']}",
    "sources":"['pdb']",
    "url":"http://www.cyrusone.com",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -95.36327,29.76328 ]
    },
    "properties": {
    "FIELD1":744,
    "country":"United States",
    "total_by_country":168,
    "city":"Houston",
    "ixpname":"CyrusOne IX Houston",
    "alternatenames":"['CyrusOne Internet Exchange']",
    "prefixes":"{'ipv4': ['198.32.96.0/23'], 'ipv6': ['2001:478:96::/64']}",
    "sources":"['pdb']",
    "url":"http://www.cyrusone.com",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -112.07404,33.44838 ]
    },
    "properties": {
    "FIELD1":745,
    "country":"United States",
    "total_by_country":168,
    "city":"Phoenix",
    "ixpname":"CyrusOne IX Phoenix",
    "alternatenames":"['CyrusOne Internet Exchange']",
    "prefixes":"{'ipv4': ['198.32.98.0/24'], 'ipv6': ['2001:478:98::/64']}",
    "sources":"['pdb']",
    "url":"http://www.cyrusone.com",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -98.49363,29.42412 ]
    },
    "properties": {
    "FIELD1":746,
    "country":"United States",
    "total_by_country":168,
    "city":"San Antonio",
    "ixpname":"CyrusOne IX San Antonio",
    "alternatenames":"['CyrusOne Internet Exchange']",
    "prefixes":"{'ipv4': ['198.32.164.0/24'], 'ipv6': ['2001:478:164::/64']}",
    "sources":"['pdb']",
    "url":"http://www.cyrusone.com",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -83.0302,42.58031 ]
    },
    "properties": {
    "FIELD1":747,
    "country":"United States",
    "total_by_country":168,
    "city":"Sterling",
    "ixpname":"CyrusOne IX Sterling",
    "alternatenames":"['CyrusOne Internet Exchange']",
    "prefixes":"{'ipv4': ['198.32.166.0/23'], 'ipv6': ['2001:478:166::/64']}",
    "sources":"['pdb']",
    "url":"http://www.cyrusone.com",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -76.61219,39.29038 ]
    },
    "properties": {
    "FIELD1":748,
    "country":"United States",
    "total_by_country":168,
    "city":"Baltimore",
    "ixpname":"DACS-IX East",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.83.44.0/24'], 'ipv6': ['2602:ffa9:e:12:1::/116']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.dacs-ix.com",
    "participants_pch":4,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -96.80667,32.78306 ]
    },
    "properties": {
    "FIELD1":749,
    "country":"United States",
    "total_by_country":168,
    "city":"Dallas",
    "ixpname":"DE-CIX Dallas",
    "alternatenames":"['Deutscher Commercial Internet Exchange Dallas']",
    "prefixes":"{'ipv4': ['206.53.202.0/24'], 'ipv6': ['2001:504:61::/48', '2001:504:61::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.de-cix.net/en/locations/united-states/dallas",
    "participants_pch":20,
    "peak_pch":"132G",
    "avg_pch":"78G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.00597,40.71427 ]
    },
    "properties": {
    "FIELD1":750,
    "country":"United States",
    "total_by_country":168,
    "city":"New York",
    "ixpname":"DE-CIX New York",
    "alternatenames":"['Deutscher Commercial Internet Exchange New York']",
    "prefixes":"{'ipv4': ['206.130.10.0/24', '206.82.104.0/22'], 'ipv6': ['2001:504:36::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.de-cix.net/locations/united-states/new-york",
    "participants_pch":145,
    "peak_pch":"587G",
    "avg_pch":"447G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -83.04575,42.33143 ]
    },
    "properties": {
    "FIELD1":751,
    "country":"United States",
    "total_by_country":168,
    "city":"Detroit",
    "ixpname":"DET-IX",
    "alternatenames":"['Detroit Internet Exchange']",
    "prefixes":"{'ipv4': ['209.124.52.0/24', '209.124.52.0/23'], 'ipv6': ['2067:f790:100::/64', '2607:f790:100::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.detroitix.com",
    "participants_pch":41,
    "peak_pch":"132G",
    "avg_pch":"93.5G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -157.85833,21.30694 ]
    },
    "properties": {
    "FIELD1":752,
    "country":"United States",
    "total_by_country":168,
    "city":"Honolulu",
    "ixpname":"DRFxchange",
    "alternatenames":"['DRFortress Exchange']",
    "prefixes":"{'ipv4': ['206.197.210.0/25'], 'ipv6': ['2606:7c80:3375:50::/64']}",
    "sources":"['pdb']",
    "url":"http://www.drfortress.com",
    "participants_pch":13,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -96.80667,32.78306 ]
    },
    "properties": {
    "FIELD1":753,
    "country":"United States",
    "total_by_country":168,
    "city":"Dallas",
    "ixpname":"Dallas-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.71.139.0/24'], 'ipv6': ['2001:504:75::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.dallas-ix.net",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -96.80667,32.78306 ]
    },
    "properties": {
    "FIELD1":754,
    "country":"United States",
    "total_by_country":168,
    "city":"Dallas",
    "ixpname":"Dallas/Fort Worth Metropolitan Access Point",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -84.19161,39.75895 ]
    },
    "properties": {
    "FIELD1":755,
    "country":"United States",
    "total_by_country":168,
    "city":"Dayton",
    "ixpname":"Dayton Metro Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -84.38798,33.749 ]
    },
    "properties": {
    "FIELD1":756,
    "country":"United States",
    "total_by_country":168,
    "city":"Atlanta",
    "ixpname":"Digital Realty Atlanta Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['198.32.132.0/24'], 'ipv6': ['2001:478:132::/64']}",
    "sources":"['he']",
    "url":"https://ix.digitalrealty.com",
    "participants_pch":136,
    "peak_pch":"900G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -96.80667,32.78306 ]
    },
    "properties": {
    "FIELD1":757,
    "country":"United States",
    "total_by_country":168,
    "city":"Dallas",
    "ixpname":"Digital Realty Dallas Internet Exchange",
    "alternatenames":"['Digital Realty | Telx Dallas', 'Digital Realty Dallas']",
    "prefixes":"{'ipv4': ['206.126.114.0/24'], 'ipv6': ['2001:504:17:114::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.digitalrealty.com",
    "participants_pch":9,
    "peak_pch":"4M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2007,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.00597,40.71427 ]
    },
    "properties": {
    "FIELD1":758,
    "country":"United States",
    "total_by_country":168,
    "city":"New York",
    "ixpname":"Digital Realty New York Internet Exchange",
    "alternatenames":"['Digital Realty New York', 'Digital Realty | Telx New York']",
    "prefixes":"{'ipv4': ['206.126.115.0/24'], 'ipv6': ['2001:504:17:115::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.digitalrealty.com",
    "participants_pch":68,
    "peak_pch":"100G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2009,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -112.07404,33.44838 ]
    },
    "properties": {
    "FIELD1":759,
    "country":"United States",
    "total_by_country":168,
    "city":"Phoenix",
    "ixpname":"Digital Realty Phoenix Internet Exchange",
    "alternatenames":"['Digital Realty Phoenix', 'Digital Realty | Telx Phoenix']",
    "prefixes":"{'ipv4': ['198.32.186.0/24'], 'ipv6': ['2001:478:186::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ix.digitalrealty.com",
    "participants_pch":9,
    "peak_pch":"1.2G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -117.42908,47.65966 ]
    },
    "properties": {
    "FIELD1":760,
    "country":"United States",
    "total_by_country":168,
    "city":"Spokane",
    "ixpname":"Eastern Washington Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -84.38798,33.749 ]
    },
    "properties": {
    "FIELD1":761,
    "country":"United States",
    "total_by_country":168,
    "city":"Atlanta",
    "ixpname":"Equinix Atlanta",
    "alternatenames":"['Equinix Internet Exchange Atlanta']",
    "prefixes":"{'ipv4': ['198.32.181.0/24', '198.32.182.0/24', '198.32.183.0/24'], 'ipv6': ['2001:504:10::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.equinix.com",
    "participants_pch":23,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -87.65005,41.85003 ]
    },
    "properties": {
    "FIELD1":762,
    "country":"United States",
    "total_by_country":168,
    "city":"Chicago",
    "ixpname":"Equinix Chicago IBX",
    "alternatenames":"['Equinix Chicago Exchange', 'Equinix Chicago']",
    "prefixes":"{'ipv4': ['208.115.136.0/23'], 'ipv6': ['2001:504:0:4::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.equinix.com",
    "participants_pch":129,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -96.80667,32.78306 ]
    },
    "properties": {
    "FIELD1":763,
    "country":"United States",
    "total_by_country":168,
    "city":"Dallas",
    "ixpname":"Equinix Dallas(former PAIX)",
    "alternatenames":"['Equinix Dallas Exchange']",
    "prefixes":"{'ipv4': ['206.223.118.0/23'], 'ipv6': ['2001:504:0:5::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://ix.equinix.com",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":1999,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -77.48749,39.04372 ]
    },
    "properties": {
    "FIELD1":764,
    "country":"United States",
    "total_by_country":168,
    "city":"Ashburn",
    "ixpname":"Equinix IBX Ashburn",
    "alternatenames":"['Equinix Ashburn', 'Equinix Ashburn Exchange']",
    "prefixes":"{'ipv4': ['206.126.236.0/22'], 'ipv6': ['2001:504:0:2::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.equinix.com",
    "participants_pch":208,
    "peak_pch":"610G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -96.80667,32.78306 ]
    },
    "properties": {
    "FIELD1":765,
    "country":"United States",
    "total_by_country":168,
    "city":"Dallas",
    "ixpname":"Equinix IBX Dallas",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.223.118.0/24'], 'ipv6': ['2001:504:0:5::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":143,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -121.9233903,37.2966279 ]
    },
    "properties": {
    "FIELD1":766,
    "country":"United States",
    "total_by_country":168,
    "city":"San Jose",
    "ixpname":"Equinix IBX San Jose",
    "alternatenames":"['Equinix San Jose']",
    "prefixes":"{'ipv4': ['206.223.116.0/24'], 'ipv6': ['2001:504:0:1::/64']}",
    "sources":"['pch', 'he']",
    "url":"https://ix.equinix.com",
    "participants_pch":212,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.05653,40.78955 ]
    },
    "properties": {
    "FIELD1":767,
    "country":"United States",
    "total_by_country":168,
    "city":"Secaucus",
    "ixpname":"Equinix IBX Secaucus",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.223.117.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -95.36327,29.76328 ]
    },
    "properties": {
    "FIELD1":768,
    "country":"United States",
    "total_by_country":168,
    "city":"Houston",
    "ixpname":"Equinix Internet Exchange Houston",
    "alternatenames":"['Equinix Internet Exchange Houston']",
    "prefixes":"{'ipv4': ['198.32.135.0/24'], 'ipv6': ['2001:504:0:9::/64']}",
    "sources":"['pdb']",
    "url":"https://www.equinix.com",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -118.24368,34.05223 ]
    },
    "properties": {
    "FIELD1":769,
    "country":"United States",
    "total_by_country":168,
    "city":"Los Angeles",
    "ixpname":"Equinix Los Angeles IBX",
    "alternatenames":"['Equinix Los Angeles', 'Equinix Los Angeles Exchange']",
    "prefixes":"{'ipv4': ['206.223.123.0/24'], 'ipv6': ['2001:504:0:3::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.equinix.com",
    "participants_pch":72,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"North America",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.00597,40.71427 ]
    },
    "properties": {
    "FIELD1":770,
    "country":"United States",
    "total_by_country":168,
    "city":"New York",
    "ixpname":"Equinix New York IBX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.223.131.0/24', '206.197.169.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":66,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.14302,37.44188 ]
    },
    "properties": {
    "FIELD1":771,
    "country":"United States",
    "total_by_country":168,
    "city":"Palo Alto",
    "ixpname":"Equinix Palo Alto",
    "alternatenames":"['Equinix Internet Exchange Palo Alto']",
    "prefixes":"{'ipv4': ['198.32.175.0/24', '198.32.177.0/24', '198.32.176.0/24'], 'ipv6': ['2001:504:d::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.equinix.com",
    "participants_pch":92,
    "peak_pch":"41G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":1994,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.41942,37.77493 ]
    },
    "properties": {
    "FIELD1":772,
    "country":"United States",
    "total_by_country":168,
    "city":"San Francisco",
    "ixpname":"Equinix San Francisco",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -71.05977,42.35843 ]
    },
    "properties": {
    "FIELD1":773,
    "country":"United States",
    "total_by_country":168,
    "city":"Boston",
    "ixpname":"Equinix-Boston",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['198.32.111.0/24', '198.32.112.0/24', '198.32.113.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -80.19366,25.77427 ]
    },
    "properties": {
    "FIELD1":774,
    "country":"United States",
    "total_by_country":168,
    "city":"Miami",
    "ixpname":"Equinix-Miami",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['198.32.124.0/23', '198.32.242.0/23'], 'ipv6': ['2001:504:0:6::/64', '2001:478:124::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.equinix.com",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.00597,40.71427 ]
    },
    "properties": {
    "FIELD1":775,
    "country":"United States",
    "total_by_country":168,
    "city":"New York",
    "ixpname":"Equinix-NY(former Paix)",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['198.32.117.0/24', '198.32.118.0/24', '198.32.119.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":80,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.33207,47.60621 ]
    },
    "properties": {
    "FIELD1":776,
    "country":"United States",
    "total_by_country":168,
    "city":"Seattle",
    "ixpname":"Equinix-Seattle",
    "alternatenames":"['Equinix Internet Exchange Seattle', 'Equinix-Seattle']",
    "prefixes":"{'ipv4': ['198.32.133.0/24', '198.32.134.0/24', '198.32.135.0/24'], 'ipv6': ['2001:504:12::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.equinix.com",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -77.26526,38.90122 ]
    },
    "properties": {
    "FIELD1":777,
    "country":"United States",
    "total_by_country":168,
    "city":"Vienna",
    "ixpname":"Equinix-VA",
    "alternatenames":"['Equinix Internet Exchange Vienna, VA', 'Equinix-VA']",
    "prefixes":"{'ipv4': ['198.32.190.0/24', '198.32.191.0/24', '198.32.192.0/24'], 'ipv6': ['2001:504:e::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix.equinix.com",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -96.80667,32.78306 ]
    },
    "properties": {
    "FIELD1":778,
    "country":"United States",
    "total_by_country":168,
    "city":"Dallas",
    "ixpname":"Excel Telecom NAP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -80.19366,25.77427 ]
    },
    "properties": {
    "FIELD1":779,
    "country":"United States",
    "total_by_country":168,
    "city":"Miami",
    "ixpname":"FL-IX - The Florida Internet Exchange / Community IX - Florida",
    "alternatenames":"['FL-IX - The Florida Internet Exchange / Community IX - Florida']",
    "prefixes":"{'ipv4': ['206.41.108.0/24'], 'ipv6': ['2001:504:40:108::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.communityix.org/index.php/about-fl-ix/",
    "participants_pch":111,
    "peak_pch":"520G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -82.99879,39.96118 ]
    },
    "properties": {
    "FIELD1":780,
    "country":"United States",
    "total_by_country":168,
    "city":"Columbus",
    "ixpname":"FiberNAP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -121.98857,37.54827 ]
    },
    "properties": {
    "FIELD1":781,
    "country":"United States",
    "total_by_country":168,
    "city":"Fremont",
    "ixpname":"Fremont Cabal Internet Exchange",
    "alternatenames":"['FCIX']",
    "prefixes":"{'ipv4': ['206.80.238.0/24'], 'ipv6': ['2001:504:91::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://fcix.net/",
    "participants_pch":39,
    "peak_pch":"4.2G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.00597,40.71427 ]
    },
    "properties": {
    "FIELD1":782,
    "country":"United States",
    "total_by_country":168,
    "city":"New York",
    "ixpname":"GPIEX",
    "alternatenames":"['Global Peering Managed Services Provider']",
    "prefixes":"{'ipv4': ['23.156.192.0/24'], 'ipv6': ['2604:8440::/32']}",
    "sources":"['pdb', 'he']",
    "url":"http://gpiex.net/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -77.48749,39.04372 ]
    },
    "properties": {
    "FIELD1":783,
    "country":"United States",
    "total_by_country":168,
    "city":"Ashburn",
    "ixpname":"Gig IX Ashburn",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":4,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"North America",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -87.65005,41.85003 ]
    },
    "properties": {
    "FIELD1":784,
    "country":"United States",
    "total_by_country":168,
    "city":"Chicago",
    "ixpname":"Greater Chicago International Internet Exchange",
    "alternatenames":"['GCIIX']",
    "prefixes":"{'ipv4': ['206.123.30.0/24'], 'ipv6': ['2001:504:22:30::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.gciix.net",
    "participants_pch":2,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -157.85833,21.30694 ]
    },
    "properties": {
    "FIELD1":785,
    "country":"United States",
    "total_by_country":168,
    "city":"Honolulu",
    "ixpname":"Hawaii Internet Exchange",
    "alternatenames":"['HIX', 'Hawai`i Internet Exchange']",
    "prefixes":"{'ipv4': ['205.166.205.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.hawaii-ix.org/",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":1995,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -95.36327,29.76328 ]
    },
    "properties": {
    "FIELD1":786,
    "country":"United States",
    "total_by_country":168,
    "city":"Houston",
    "ixpname":"Houston MAGIE",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -95.36327,29.76328 ]
    },
    "properties": {
    "FIELD1":787,
    "country":"United States",
    "total_by_country":168,
    "city":"Houston",
    "ixpname":"Houston Metropolitan Access Point",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -95.36327,29.76328 ]
    },
    "properties": {
    "FIELD1":788,
    "country":"United States",
    "total_by_country":168,
    "city":"Houston",
    "ixpname":"Houston-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.71.138.0/24'], 'ipv6': ['2001:504:74::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.housoin-ix.net",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -106.65114,35.08449 ]
    },
    "properties": {
    "FIELD1":789,
    "country":"United States",
    "total_by_country":168,
    "city":"Albuquerque",
    "ixpname":"IXNM",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -86.15804,39.76838 ]
    },
    "properties": {
    "FIELD1":790,
    "country":"United States",
    "total_by_country":168,
    "city":"Indianapolis",
    "ixpname":"Indianapolis Data Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -104.9847,39.73915 ]
    },
    "properties": {
    "FIELD1":791,
    "country":"United States",
    "total_by_country":168,
    "city":"Denver",
    "ixpname":"Interconnection eXchange Denver",
    "alternatenames":"['IX-Denver']",
    "prefixes":"{'ipv4': ['206.53.175.0/24'], 'ipv6': ['2001:504:58::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://ix-denver.org",
    "participants_pch":30,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -97.51643,35.46756 ]
    },
    "properties": {
    "FIELD1":792,
    "country":"United States",
    "total_by_country":168,
    "city":"Oklahoma City",
    "ixpname":"Internet Exchange Oklahoma City",
    "alternatenames":"['Internet Exchange Oklahoma City']",
    "prefixes":"{'ipv4': ['206.81.109.0/24'], 'ipv6': ['2001:504:92::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.iX-OKC.net",
    "participants_pch":7,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -81.65565,30.33218 ]
    },
    "properties": {
    "FIELD1":793,
    "country":"United States",
    "total_by_country":168,
    "city":"Jacksonville",
    "ixpname":"Jacksonville Internet Exchange",
    "alternatenames":"['JXIX']",
    "prefixes":"{'ipv4': ['206.123.7.0/24'], 'ipv6': ['2001:504:95::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://jxix.org",
    "participants_pch":10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -94.57857,39.09973 ]
    },
    "properties": {
    "FIELD1":794,
    "country":"United States",
    "total_by_country":168,
    "city":"Kansas City",
    "ixpname":"Kansas City Internet Exchange",
    "alternatenames":"['Kansas City Internet eXchange', 'KCIX']",
    "prefixes":"{'ipv4': ['206.51.7.0/25'], 'ipv6': ['2001:504:1b:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.kcix.net/",
    "participants_pch":72,
    "peak_pch":"45G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2006,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -77.3411,38.96872 ]
    },
    "properties": {
    "FIELD1":795,
    "country":"United States",
    "total_by_country":168,
    "city":"Reston",
    "ixpname":"LINX NoVa",
    "alternatenames":"['LINX Northern Virginia, Ashburn, Reston and Manassas', 'LINX NoVa']",
    "prefixes":"{'ipv4': ['206.55.196.0/23'], 'ipv6': ['2001:504:31::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.linx.net/linx-nova",
    "participants_pch":45,
    "peak_pch":"17G",
    "avg_pch":"14G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -118.24368,34.05223 ]
    },
    "properties": {
    "FIELD1":796,
    "country":"United States",
    "total_by_country":168,
    "city":"Los Angeles",
    "ixpname":"LSY.CN Los Angeles",
    "alternatenames":"['LSHIY Group Los Angeles Internet eXchange']",
    "prefixes":"{'ipv4': [], 'ipv6': ['2404:f4c0:4:3::/64', '2404:f4c0:4:d20::/64', '2403:5180:25:d20::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://ix.lsy.cn/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -118.24368,34.05223 ]
    },
    "properties": {
    "FIELD1":797,
    "country":"United States",
    "total_by_country":168,
    "city":"Los Angeles",
    "ixpname":"Los Angeles International Internet Exchange",
    "alternatenames":"['NYIIX Los Angeles', 'New York International Internet eXchange - Los Angeles']",
    "prefixes":"{'ipv4': ['198.32.146.0/24'], 'ipv6': ['2001:504:a::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.nyiix.net/locations/nyiix-la/",
    "participants_pch":32,
    "peak_pch":"9.2G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -85.75941,38.25424 ]
    },
    "properties": {
    "FIELD1":798,
    "country":"United States",
    "total_by_country":168,
    "city":"Louisville",
    "ixpname":"Louisville NAP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.07764,40.72816 ]
    },
    "properties": {
    "FIELD1":799,
    "country":"United States",
    "total_by_country":168,
    "city":"New Jersey",
    "ixpname":"MAGPI Gigapop",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['198.32.42.0/24', '198.32.224.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2006,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -98.23001,26.20341 ]
    },
    "properties": {
    "FIELD1":800,
    "country":"United States",
    "total_by_country":168,
    "city":"McAllen",
    "ixpname":"MEX-IX McAllen",
    "alternatenames":"['MEX-IX']",
    "prefixes":"{'ipv4': ['206.71.142.0/24'], 'ipv6': ['2620:3b:6000::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.mdcdatacenters.com",
    "participants_pch":2,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -89.40123,43.07305 ]
    },
    "properties": {
    "FIELD1":801,
    "country":"United States",
    "total_by_country":168,
    "city":"Madison",
    "ixpname":"Madison Internet Exchange",
    "alternatenames":"['MadIX']",
    "prefixes":"{'ipv4': ['144.92.233.224/28', '144.92.233.224/27'], 'ipv6': ['2607:f388:0:2200::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://kb.wisc.edu/ns/page.php?id=6636",
    "participants_pch":22,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2000,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.67621,45.52345 ]
    },
    "properties": {
    "FIELD1":802,
    "country":"United States",
    "total_by_country":168,
    "city":"Portland",
    "ixpname":"MaineXchangePoint",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -71.05977,42.35843 ]
    },
    "properties": {
    "FIELD1":803,
    "country":"United States",
    "total_by_country":168,
    "city":"Boston",
    "ixpname":"Massachusetts Internet Exchange",
    "alternatenames":"['MASS IX, Boston/Massachusetts Internet Exchange', 'MASS-IX', 'Mass-IX']",
    "prefixes":"{'ipv4': ['206.53.143.0/24'], 'ipv6': ['2001:504:47::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.mass-ix.net",
    "participants_pch":43,
    "peak_pch":"68G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -96.80667,32.78306 ]
    },
    "properties": {
    "FIELD1":804,
    "country":"United States",
    "total_by_country":168,
    "city":"Dallas",
    "ixpname":"Megaport Dallas",
    "alternatenames":"['MegaIX Dallas', 'Megaport MegaIX Dallas']",
    "prefixes":"{'ipv4': ['206.53.174.0/24'], 'ipv6': ['2606:a980:0:7::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://megaport.com",
    "participants_pch":13,
    "peak_pch":"11.4G",
    "avg_pch":"8G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -77.48749,39.04372 ]
    },
    "properties": {
    "FIELD1":805,
    "country":"United States",
    "total_by_country":168,
    "city":"Ashburn",
    "ixpname":"Megaport IX Ashburn",
    "alternatenames":"['Megaport MegaIX Ashburn', 'MegaIX Ashburn']",
    "prefixes":"{'ipv4': ['206.53.170.0/24'], 'ipv6': ['2606:a980:0:3::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.megaport.com",
    "participants_pch":16,
    "peak_pch":"18G",
    "avg_pch":"10.4G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -118.24368,34.05223 ]
    },
    "properties": {
    "FIELD1":806,
    "country":"United States",
    "total_by_country":168,
    "city":"Los Angeles",
    "ixpname":"Megaport IX Los Angeles",
    "alternatenames":"['MegaIX Los Angeles', 'Megaport MegaIX Los Angeles']",
    "prefixes":"{'ipv4': ['206.53.172.0/24'], 'ipv6': ['2606:a980:0:5::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://megaport.com",
    "participants_pch":20,
    "peak_pch":"7.6G",
    "avg_pch":"6.97G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.33207,47.60621 ]
    },
    "properties": {
    "FIELD1":807,
    "country":"United States",
    "total_by_country":168,
    "city":"Seattle",
    "ixpname":"Megaport Seattle",
    "alternatenames":"['MegaIX Seattle', 'Megaport MegaIX Seattle']",
    "prefixes":"{'ipv4': ['206.53.171.0/24'], 'ipv6': ['2606:a980:0:4::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://megaport.com",
    "participants_pch":10,
    "peak_pch":"1.5G",
    "avg_pch":"1.1G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.00597,40.71427 ]
    },
    "properties": {
    "FIELD1":808,
    "country":"United States",
    "total_by_country":168,
    "city":"New York",
    "ixpname":"MetroIX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -80.19366,25.77427 ]
    },
    "properties": {
    "FIELD1":809,
    "country":"United States",
    "total_by_country":168,
    "city":"Miami",
    "ixpname":"MiamiIX",
    "alternatenames":"['Miami Internet Exchange']",
    "prefixes":"{'ipv4': ['198.78.5.0/24'], 'ipv6': ['2607:fe60:aaaa::/64']}",
    "sources":"['pdb']",
    "url":"http://www.miamiix.net",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -90.19789,38.62727 ]
    },
    "properties": {
    "FIELD1":810,
    "country":"United States",
    "total_by_country":168,
    "city":"St. Louis",
    "ixpname":"MidWest-IX - St. Louis",
    "alternatenames":"['St. Louis Regional Internet Exchange']",
    "prefixes":"{'ipv4': ['206.71.10.0/24'], 'ipv6': ['2001:504:45:10::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.midwest-ix.com",
    "participants_pch":18,
    "peak_pch":"5.3G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -93.26384,44.97997 ]
    },
    "properties": {
    "FIELD1":811,
    "country":"United States",
    "total_by_country":168,
    "city":"Minneapolis",
    "ixpname":"Midwest Internet Cooperative Exchange",
    "alternatenames":"['MICE']",
    "prefixes":"{'ipv4': ['206.108.255.0/24'], 'ipv6': ['2001:504:27::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.micemn.net",
    "participants_pch":94,
    "peak_pch":"323G",
    "avg_pch":"1K",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -86.15804,39.76838 ]
    },
    "properties": {
    "FIELD1":812,
    "country":"United States",
    "total_by_country":168,
    "city":"Indianapolis",
    "ixpname":"Midwest-IX Indy",
    "alternatenames":"['Midwest-IX', 'Midwest Internet Exchange Indy']",
    "prefixes":"{'ipv4': ['206.53.139.0/24'], 'ipv6': ['2001:504:45:f3e8::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.midwest-ix.com",
    "participants_pch":25,
    "peak_pch":"28G",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"pch",
    "region":"North America",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -87.90647,43.0389 ]
    },
    "properties": {
    "FIELD1":813,
    "country":"United States",
    "total_by_country":168,
    "city":"Milwaukee",
    "ixpname":"Milwaukee Internet Exchange",
    "alternatenames":"['MKE-IX', 'The Milwaukee IX']",
    "prefixes":"{'ipv4': ['204.107.122.0/25'], 'ipv6': ['2001:19e0:ffff::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.mkeix.net",
    "participants_pch":17,
    "peak_pch":"2.5G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2011,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.41942,37.77493 ]
    },
    "properties": {
    "FIELD1":814,
    "country":"United States",
    "total_by_country":168,
    "city":"San Francisco",
    "ixpname":"MoeIX San Francisco",
    "alternatenames":"['MoeQing Internet Exchange - San Francisco']",
    "prefixes":"{'ipv4': [], 'ipv6': ['2a0c:b641:70:cccc::/64']}",
    "sources":"['pdb']",
    "url":"https://www.moeix.online",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.41942,37.77493 ]
    },
    "properties": {
    "FIELD1":815,
    "country":"United States",
    "total_by_country":168,
    "city":"San Francisco",
    "ixpname":"MoeIX-FMT",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': ['2a0c:5440:ffff:a233::/64', '2a0c:b641:70:cccc::/64']}",
    "sources":"['he']",
    "url":"https://www.moeix.online",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -86.29997,32.36681 ]
    },
    "properties": {
    "FIELD1":816,
    "country":"United States",
    "total_by_country":168,
    "city":"Montgomery",
    "ixpname":"Montgomery Internet Exchange",
    "alternatenames":"['MGMix Montgomery', 'MGMix']",
    "prefixes":"{'ipv4': ['206.53.200.0/24'], 'ipv6': ['2001:504:59::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.mgmix.net",
    "participants_pch":17,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -80.19366,25.77427 ]
    },
    "properties": {
    "FIELD1":817,
    "country":"United States",
    "total_by_country":168,
    "city":"Miami",
    "ixpname":"NAP of the Americas",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['198.32.124.0/23'], 'ipv6': ['2001:478:124::/48']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":87,
    "peak_pch":"250G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -93.61994,42.03471 ]
    },
    "properties": {
    "FIELD1":818,
    "country":"United States",
    "total_by_country":168,
    "city":"Ames",
    "ixpname":"NASA-AIX",
    "alternatenames":"['NASA Ames Internet eXchange']",
    "prefixes":"{'ipv4': ['198.9.201.0/24', '198.9.202.0/24', '198.32.136.0/24', '198.32.153.0/24'], 'ipv6': ['2001:478:6663:100::/64', '2001:478:6663:200::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.nasa.gov/centers/ames",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.33207,47.60621 ]
    },
    "properties": {
    "FIELD1":820,
    "country":"United States",
    "total_by_country":168,
    "city":"Seattle",
    "ixpname":"NWnet Gigapop",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.00597,40.71427 ]
    },
    "properties": {
    "FIELD1":821,
    "country":"United States",
    "total_by_country":168,
    "city":"New York",
    "ixpname":"NY-RIX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.00597,40.71427 ]
    },
    "properties": {
    "FIELD1":822,
    "country":"United States",
    "total_by_country":168,
    "city":"New York",
    "ixpname":"NYCX",
    "alternatenames":"['Free NYIIX Alternative']",
    "prefixes":"{'ipv4': ['198.32.229.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.nycx.net/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -75.16379,39.95233 ]
    },
    "properties": {
    "FIELD1":823,
    "country":"United States",
    "total_by_country":168,
    "city":"Philadelphia",
    "ixpname":"NYIIX Philadelphia",
    "alternatenames":"['New York International Internet eXchange - Philadelphia']",
    "prefixes":"{'ipv4': ['206.51.30.0/24'], 'ipv6': ['2001:504:1:9::/64']}",
    "sources":"['pdb', 'he']",
    "url":"https://www.nyiix.net/locations/nyiix-philadelphia/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -86.78444,36.16589 ]
    },
    "properties": {
    "FIELD1":824,
    "country":"United States",
    "total_by_country":168,
    "city":"Nashville",
    "ixpname":"NashIX",
    "alternatenames":"['Nashville Internet Exchange']",
    "prefixes":"{'ipv4': ['209.141.110.0/24'], 'ipv6': ['2607:f778:1:fe00::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://nashix.net",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -86.78444,36.16589 ]
    },
    "properties": {
    "FIELD1":825,
    "country":"United States",
    "total_by_country":168,
    "city":"Nashville",
    "ixpname":"Nashville City Net",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -86.78444,36.16589 ]
    },
    "properties": {
    "FIELD1":826,
    "country":"United States",
    "total_by_country":168,
    "city":"Nashville",
    "ixpname":"Nashville NAP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -106.65114,35.08449 ]
    },
    "properties": {
    "FIELD1":827,
    "country":"United States",
    "total_by_country":168,
    "city":"Albuquerque",
    "ixpname":"New Mexico Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2008,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.00597,40.71427 ]
    },
    "properties": {
    "FIELD1":828,
    "country":"United States",
    "total_by_country":168,
    "city":"New York",
    "ixpname":"New York City Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.00597,40.71427 ]
    },
    "properties": {
    "FIELD1":829,
    "country":"United States",
    "total_by_country":168,
    "city":"New York",
    "ixpname":"New York International Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['198.32.160.0/24'], 'ipv6': ['2001:504:1::/64']}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":174,
    "peak_pch":"642G",
    "avg_pch":"541G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.67621,45.52345 ]
    },
    "properties": {
    "FIELD1":830,
    "country":"United States",
    "total_by_country":168,
    "city":"Portland",
    "ixpname":"Northern New England Neutral Internet Exchange",
    "alternatenames":"['NNENIX']",
    "prefixes":"{'ipv4': ['206.71.140.0/24'], 'ipv6': ['2001:504:76::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.nnenix.net",
    "participants_pch":4,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.67621,45.52345 ]
    },
    "properties": {
    "FIELD1":831,
    "country":"United States",
    "total_by_country":168,
    "city":"Portland",
    "ixpname":"Northwest Access Exchange",
    "alternatenames":"['NWAX', 'Northwest Access Exchange, Inc.']",
    "prefixes":"{'ipv4': ['198.32.195.0/24'], 'ipv6': ['2001:478:195::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.nwax.net",
    "participants_pch":89,
    "peak_pch":"80G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2002,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -112.03611,46.59271 ]
    },
    "properties": {
    "FIELD1":832,
    "country":"United States",
    "total_by_country":168,
    "city":"Helena",
    "ixpname":"Northwest Internet Exchange-Helena",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['69.51.84.0/25'], 'ipv6': []}",
    "sources":"['he']",
    "url":"http://www.nwix.org",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"North America",
    "year":2006,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -113.994,46.87215 ]
    },
    "properties": {
    "FIELD1":833,
    "country":"United States",
    "total_by_country":168,
    "city":"Missoula",
    "ixpname":"Northwest Internet Exchange-Missoula",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['69.51.84.128/25'], 'ipv6': []}",
    "sources":"['he']",
    "url":"http://www.nwix.org",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"North America",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -82.99879,39.96118 ]
    },
    "properties": {
    "FIELD1":834,
    "country":"United States",
    "total_by_country":168,
    "city":"Columbus",
    "ixpname":"Ohio IX",
    "alternatenames":"['OhioIX']",
    "prefixes":"{'ipv4': ['206.53.204.0/24'], 'ipv6': ['2001:504:64:100::/64', '2001:504:64::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://ohioix.net",
    "participants_pch":26,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -95.94043,41.25626 ]
    },
    "properties": {
    "FIELD1":835,
    "country":"United States",
    "total_by_country":168,
    "city":"Omaha",
    "ixpname":"OmahaIX",
    "alternatenames":"['Omaha Internet Exchange']",
    "prefixes":"{'ipv4': ['206.126.235.0/26'], 'ipv6': ['2001:504:33::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.omahaix.com",
    "participants_pch":20,
    "peak_pch":"96G",
    "avg_pch":"73G",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -123.08675,44.05207 ]
    },
    "properties": {
    "FIELD1":836,
    "country":"United States",
    "total_by_country":168,
    "city":"Eugene",
    "ixpname":"Oregon Internet Exchange",
    "alternatenames":"['Oregon-IX']",
    "prefixes":"{'ipv4': ['198.32.162.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.oregon-ix.net/",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -74.00597,40.71427 ]
    },
    "properties": {
    "FIELD1":837,
    "country":"United States",
    "total_by_country":168,
    "city":"New York",
    "ixpname":"Peer 1 Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.223.127.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2004,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -75.16379,39.95233 ]
    },
    "properties": {
    "FIELD1":838,
    "country":"United States",
    "total_by_country":168,
    "city":"Philadelphia",
    "ixpname":"Philadelphia Internet Exchange",
    "alternatenames":"['PhillyIX']",
    "prefixes":"{'ipv4': ['206.80.234.0/24'], 'ipv6': ['2001:504:90::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://phillyix.net",
    "participants_pch":4,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"North America",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -112.07404,33.44838 ]
    },
    "properties": {
    "FIELD1":839,
    "country":"United States",
    "total_by_country":168,
    "city":"Phoenix",
    "ixpname":"Phoenix Internet Exchange",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -112.07404,33.44838 ]
    },
    "properties": {
    "FIELD1":840,
    "country":"United States",
    "total_by_country":168,
    "city":"Phoenix",
    "ixpname":"Phoenix-IX",
    "alternatenames":"['Phoenix-IX']",
    "prefixes":"{'ipv4': ['206.41.105.0/24'], 'ipv6': ['2001:504:3b::/64', '2001:504:3b:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.phoenix-ix.net",
    "participants_pch":64,
    "peak_pch":"16.9G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -79.99589,40.44062 ]
    },
    "properties": {
    "FIELD1":841,
    "country":"United States",
    "total_by_country":168,
    "city":"Pittsburgh",
    "ixpname":"Pittsburgh Exchange Point",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -79.99589,40.44062 ]
    },
    "properties": {
    "FIELD1":842,
    "country":"United States",
    "total_by_country":168,
    "city":"Pittsburgh",
    "ixpname":"Pittsburgh Internet Exchange",
    "alternatenames":"['PIT-IX']",
    "prefixes":"{'ipv4': ['206.71.141.0/24'], 'ipv6': ['2001:504:77::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://pit-ix.net",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -77.46026,37.55376 ]
    },
    "properties": {
    "FIELD1":843,
    "country":"United States",
    "total_by_country":168,
    "city":"Richmond",
    "ixpname":"Richmond Virginia Internet Exchange",
    "alternatenames":"['RVA-IX']",
    "prefixes":"{'ipv4': ['206.53.137.0/24'], 'ipv6': ['2001:504:44::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://rva-ix.net",
    "participants_pch":12,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -77.46026,37.55376 ]
    },
    "properties": {
    "FIELD1":844,
    "country":"United States",
    "total_by_country":168,
    "city":"Richmond",
    "ixpname":"Richmond-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.71.9.0/25'], 'ipv6': ['2001:504:67::/64', '2001:504:67:1::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.richmond-ix.net",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.41942,37.77493 ]
    },
    "properties": {
    "FIELD1":845,
    "country":"United States",
    "total_by_country":168,
    "city":"San Francisco",
    "ixpname":"SFIX",
    "alternatenames":"['San Francisco Internet Exchange']",
    "prefixes":"{'ipv4': ['198.32.129.0/24'], 'ipv6': []}",
    "sources":"['pdb']",
    "url":"http://www.sfix.org/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.33207,47.60621 ]
    },
    "properties": {
    "FIELD1":846,
    "country":"United States",
    "total_by_country":168,
    "city":"Seattle",
    "ixpname":"SIX Seattle (Jumbo)",
    "alternatenames":"['Seattle Internet Exchange (MTU 9000)']",
    "prefixes":"{'ipv4': ['206.81.82.0/23'], 'ipv6': ['2001:504:16:1::/64']}",
    "sources":"['pdb']",
    "url":"https://www.seattleix.net/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -84.38798,33.749 ]
    },
    "properties": {
    "FIELD1":847,
    "country":"United States",
    "total_by_country":168,
    "city":"Atlanta",
    "ixpname":"SNAP",
    "alternatenames":"['Southeast Network Access Point']",
    "prefixes":"{'ipv4': ['206.123.24.0/24'], 'ipv6': ['2001:504:28::/48']}",
    "sources":"['pdb']",
    "url":"http://www.southeastnap.com/",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -87.65005,41.85003 ]
    },
    "properties": {
    "FIELD1":848,
    "country":"United States",
    "total_by_country":168,
    "city":"Chicago",
    "ixpname":"STAR TAP",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":1998,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -121.4944,38.58157 ]
    },
    "properties": {
    "FIELD1":849,
    "country":"United States",
    "total_by_country":168,
    "city":"Sacramento",
    "ixpname":"Sacramento-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.71.13.0/24'], 'ipv6': ['2001:504:70::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.sacramento-ix.net",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2017,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -90.19789,38.62727 ]
    },
    "properties": {
    "FIELD1":850,
    "country":"United States",
    "total_by_country":168,
    "city":"St. Louis",
    "ixpname":"Saint Louis Internet Exchange",
    "alternatenames":"['STLIX']",
    "prefixes":"{'ipv4': ['206.83.12.0/24'], 'ipv6': ['2001:504:98::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://www.stlix.net",
    "participants_pch":23,
    "peak_pch":"8G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2019,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -111.89105,40.76078 ]
    },
    "properties": {
    "FIELD1":851,
    "country":"United States",
    "total_by_country":168,
    "city":"Salt Lake City",
    "ixpname":"Salt Lake Internet Exchange",
    "alternatenames":"['SLIX', 'Salt Lake Internet Exchange']",
    "prefixes":"{'ipv4': ['204.228.158.0/24'], 'ipv6': ['2607:fa18:1:f00::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://slix.net",
    "participants_pch":18,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -98.49363,29.42412 ]
    },
    "properties": {
    "FIELD1":852,
    "country":"United States",
    "total_by_country":168,
    "city":"San Antonio",
    "ixpname":"San Antonio Metro Access Point",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -117.16472,32.71571 ]
    },
    "properties": {
    "FIELD1":853,
    "country":"United States",
    "total_by_country":168,
    "city":"San Diego",
    "ixpname":"San Diego Network Access Point",
    "alternatenames":"['San Diego NAP', 'SD-NAP']",
    "prefixes":"{'ipv4': ['198.17.46.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.sdsc.edu/sdnap/",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":1998,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.41942,37.77493 ]
    },
    "properties": {
    "FIELD1":854,
    "country":"United States",
    "total_by_country":168,
    "city":"San Francisco",
    "ixpname":"San Francisco Metropolitan Internet Exchange",
    "alternatenames":"['SFMIX']",
    "prefixes":"{'ipv4': ['206.197.187.0/24'], 'ipv6': ['2001:504:30::/64', '2001:504:30::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.sfmix.org/",
    "participants_pch":50,
    "peak_pch":"40G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2006,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.33207,47.60621 ]
    },
    "properties": {
    "FIELD1":855,
    "country":"United States",
    "total_by_country":168,
    "city":"Seattle",
    "ixpname":"Seattle Internet Exchange",
    "alternatenames":"['Seattle Internet Exchange (MTU 1500)', 'SIX Seattle']",
    "prefixes":"{'ipv4': ['206.81.80.0/23'], 'ipv6': ['2001:504:16::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"https://www.seattleix.net/",
    "participants_pch":271,
    "peak_pch":"1.35T",
    "avg_pch":"1T",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -84.38798,33.749 ]
    },
    "properties": {
    "FIELD1":856,
    "country":"United States",
    "total_by_country":168,
    "city":"Atlanta",
    "ixpname":"South East Network Access Point",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":7,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -80.19366,25.77427 ]
    },
    "properties": {
    "FIELD1":857,
    "country":"United States",
    "total_by_country":168,
    "city":"Miami",
    "ixpname":"South Florida Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":101,
    "peak_pch":"216G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -95.36327,29.76328 ]
    },
    "properties": {
    "FIELD1":858,
    "country":"United States",
    "total_by_country":168,
    "city":"Houston",
    "ixpname":"Southeast Texas GigaPOP",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['198.32.236.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":11,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":1997,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -122.87559,42.32652 ]
    },
    "properties": {
    "FIELD1":859,
    "country":"United States",
    "total_by_country":168,
    "city":"Medford",
    "ixpname":"Southern Oregon Access Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":6,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2013,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -113.58412,37.10415 ]
    },
    "properties": {
    "FIELD1":860,
    "country":"United States",
    "total_by_country":168,
    "city":"St. George",
    "ixpname":"Southern Utah Peering Regional Network",
    "alternatenames":"['SUPRnet']",
    "prefixes":"{'ipv4': ['206.53.201.0/24'], 'ipv6': ['2001:504:60::/64', '2001:504:60::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://suprnet.net",
    "participants_pch":18,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2006,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -90.19789,38.62727 ]
    },
    "properties": {
    "FIELD1":861,
    "country":"United States",
    "total_by_country":168,
    "city":"St. Louis",
    "ixpname":"St. Louis Internet Access Consortium",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -87.65005,41.85003 ]
    },
    "properties": {
    "FIELD1":862,
    "country":"United States",
    "total_by_country":168,
    "city":"Chicago",
    "ixpname":"StarLight",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.220.241.0/24'], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":15,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2001,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -82.45843,27.94752 ]
    },
    "properties": {
    "FIELD1":863,
    "country":"United States",
    "total_by_country":168,
    "city":"Tampa",
    "ixpname":"TPA-IX",
    "alternatenames":"['TPAIX', 'Tampa Internet Exchange']",
    "prefixes":"{'ipv4': ['206.108.114.0/24'], 'ipv6': ['2001:504:3c::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.tpaix.net",
    "participants_pch":-10,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"",
    "only_in":"caida",
    "region":"North America",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -119.8138,39.52963 ]
    },
    "properties": {
    "FIELD1":864,
    "country":"United States",
    "total_by_country":168,
    "city":"Reno",
    "ixpname":"Tahoe Internet Exchange",
    "alternatenames":"['TahoeIX']",
    "prefixes":"{'ipv4': ['206.41.109.0/24'], 'ipv6': ['2001:504:3f::/64']}",
    "sources":"['pch', 'he']",
    "url":"http://www.tahoeix.org",
    "participants_pch":14,
    "peak_pch":"19.2M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -82.45843,27.94752 ]
    },
    "properties": {
    "FIELD1":865,
    "country":"United States",
    "total_by_country":168,
    "city":"Tampa",
    "ixpname":"Tampa Internet Exchange",
    "alternatenames":"['TampaIX']",
    "prefixes":"{'ipv4': ['206.108.114.0/24', '198.32.198.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"http://tampaix.net",
    "participants_pch":12,
    "peak_pch":"12G",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"",
    "region":"North America",
    "year":2015,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -76.61219,39.29038 ]
    },
    "properties": {
    "FIELD1":866,
    "country":"United States",
    "total_by_country":168,
    "city":"Baltimore",
    "ixpname":"The Baltimore Internet Exchange",
    "alternatenames":"['Baltimore Internet Exchange', 'Baltimore IX']",
    "prefixes":"{'ipv4': ['206.81.105.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://baltimoreix.net",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2018,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -79.99589,40.44062 ]
    },
    "properties": {
    "FIELD1":867,
    "country":"United States",
    "total_by_country":168,
    "city":"Pittsburgh",
    "ixpname":"Three Rivers Optical Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -110.92648,32.22174 ]
    },
    "properties": {
    "FIELD1":868,
    "country":"United States",
    "total_by_country":168,
    "city":"Tucson",
    "ixpname":"Tucson Interconnect",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -110.92648,32.22174 ]
    },
    "properties": {
    "FIELD1":869,
    "country":"United States",
    "total_by_country":168,
    "city":"Tucson",
    "ixpname":"Tucson Network Access Point",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":0,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -92.10658,46.78327 ]
    },
    "properties": {
    "FIELD1":870,
    "country":"United States",
    "total_by_country":168,
    "city":"Duluth",
    "ixpname":"Twin Ports Internet Exchange",
    "alternatenames":"['TP-IX']",
    "prefixes":"{'ipv4': ['206.223.125.0/24', '206.223.125.0/25', '206.223.125.128/25'], 'ipv6': ['2001:504:29::/48', '2001:504:29::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://tp-ix.net",
    "participants_pch":2,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2012,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -87.65005,41.85003 ]
    },
    "properties": {
    "FIELD1":871,
    "country":"United States",
    "total_by_country":168,
    "city":"Chicago",
    "ixpname":"United IX Chicago",
    "alternatenames":"['Chicago Internet Exchange', 'ChIX']",
    "prefixes":"{'ipv4': ['206.41.110.0/24'], 'ipv6': ['2001:504:41:110::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://unitedix.net/location/chicago",
    "participants_pch":40,
    "peak_pch":"48G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2014,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -111.89105,40.76078 ]
    },
    "properties": {
    "FIELD1":872,
    "country":"United States",
    "total_by_country":168,
    "city":"Salt Lake City",
    "ixpname":"Utah Regional Exchange Point",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":0,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"unknown",
    "only_in":"pch",
    "region":"North America",
    "year":1996,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -115.13722,36.17497 ]
    },
    "properties": {
    "FIELD1":873,
    "country":"United States",
    "total_by_country":168,
    "city":"Las Vegas",
    "ixpname":"Vegas-IX",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': ['206.71.8.0/25', '206.71.8.128/25'], 'ipv6': ['2001:504:68::/64', '2001:504:68:1::/64']}",
    "sources":"['pdb', 'he']",
    "url":"http://www.vegas-ix.net",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2016,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ -108.50069,45.78329 ]
    },
    "properties": {
    "FIELD1":874,
    "country":"United States",
    "total_by_country":168,
    "city":"Billings",
    "ixpname":"Yellowstone Regional Internet Exchange",
    "alternatenames":"['YRIX', 'Yellowstone Regional Internet eXchange']",
    "prefixes":"{'ipv4': ['206.126.116.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.yrix.org/",
    "participants_pch":8,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"North America",
    "year":2003,
    "lmic":"0"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 69.21627,41.26465 ]
    },
    "properties": {
    "FIELD1":875,
    "country":"Uzbekistan",
    "total_by_country":2,
    "city":"Tashkent",
    "ixpname":"ITI-IX",
    "alternatenames":"",
    "prefixes":"",
    "sources":"",
    "url":"",
    "participants_pch":5,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"pch",
    "region":"Europe & Central Asia",
    "year":0,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 69.21627,41.26465 ]
    },
    "properties": {
    "FIELD1":876,
    "country":"Uzbekistan",
    "total_by_country":2,
    "city":"Tashkent",
    "ixpname":"Uzbekistan Internet Exchange",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":42,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Europe & Central Asia",
    "year":2004,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 168.31366,-17.73648 ]
    },
    "properties": {
    "FIELD1":877,
    "country":"Vanuatu",
    "total_by_country":1,
    "city":"Port Vila",
    "ixpname":"Vanuatu Internet Exchange",
    "alternatenames":"['VIX.VU']",
    "prefixes":"{'ipv4': ['103.25.228.0/24'], 'ipv6': ['2001:dec:0:1::/64']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"http://vix.vu",
    "participants_pch":6,
    "peak_pch":"81.9M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2013,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 106.62965,10.82302 ]
    },
    "properties": {
    "FIELD1":878,
    "country":"Vietnam",
    "total_by_country":3,
    "city":"Ho Chi Minh City",
    "ixpname":"Viet Nam Internet Exchange",
    "alternatenames":"['VNIX-HCM']",
    "prefixes":"{'ipv4': ['218.100.14.0/24'], 'ipv6': ['2001:de8:a::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.vnix.vn",
    "participants_pch":15,
    "peak_pch":"160M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2004,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 108.1988643,16.0491701 ]
    },
    "properties": {
    "FIELD1":879,
    "country":"Vietnam",
    "total_by_country":3,
    "city":"Da Nang city",
    "ixpname":"Vietnam National Internet Exchange - Da Nang",
    "alternatenames":"[]",
    "prefixes":"{'ipv4': [], 'ipv6': []}",
    "sources":"['pch']",
    "url":"",
    "participants_pch":3,
    "peak_pch":"",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2005,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 105.84117,21.0245 ]
    },
    "properties": {
    "FIELD1":880,
    "country":"Vietnam",
    "total_by_country":3,
    "city":"Hanoi",
    "ixpname":"Vietnam National Internet Exchange - Hanoi",
    "alternatenames":"['VNIX-HN']",
    "prefixes":"{'ipv4': ['218.100.10.0/24'], 'ipv6': ['2001:7fa:6::/48']}",
    "sources":"['pdb', 'pch', 'he']",
    "url":"https://www.vnix.vn/",
    "participants_pch":10,
    "peak_pch":"24.5G",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"East Asia & Pacific",
    "year":2003,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 31.9034905,35.2013183 ]
    },
    "properties": {
    "FIELD1":881,
    "country":"West Bank and Gaza",
    "total_by_country":1,
    "city":"Ramallah",
    "ixpname":"Palestinian Internet Exchange",
    "alternatenames":"['PIX Palestine', 'Palestine Internet Exchange Point']",
    "prefixes":"{'ipv4': ['185.1.1.0/24'], 'ipv6': []}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.pix.ps",
    "participants_pch":5,
    "peak_pch":"27.3M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Middle East & North Africa",
    "year":2012,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 28.28713,-15.40669 ]
    },
    "properties": {
    "FIELD1":882,
    "country":"Zambia",
    "total_by_country":1,
    "city":"Lusaka",
    "ixpname":"Zambia Internet Exchange Point",
    "alternatenames":"['Lusaka Internet Exchange Point', 'LuIXP']",
    "prefixes":"{'ipv4': ['196.223.2.0/24'], 'ipv6': ['2001:43f8:140::/64']}",
    "sources":"['pdb', 'pch']",
    "url":"http://www.ispa.org.zm",
    "participants_pch":13,
    "peak_pch":"103M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2006,
    "lmic":"1"
    }
  },
  {
    "type": "Feature",
    "geometry": {
       "type": "Point",
       "coordinates":  [ 31.05337,-17.82772 ]
    },
    "properties": {
    "FIELD1":883,
    "country":"Zimbabwe",
    "total_by_country":1,
    "city":"Harare",
    "ixpname":"Harare Internet Exchange",
    "alternatenames":"['Harare Internet eXchange Point']",
    "prefixes":"{'ipv4': ['196.60.44.0/24'], 'ipv6': ['2001:43f8:310::/64']}",
    "sources":"['pdb']",
    "url":"http://www.hix.org.zw/",
    "participants_pch":7,
    "peak_pch":"200M",
    "avg_pch":"",
    "status_pch":"active",
    "only_in":"",
    "region":"Sub-Saharan Africa",
    "year":2017,
    "lmic":"1"
    }
  }
]
}
    